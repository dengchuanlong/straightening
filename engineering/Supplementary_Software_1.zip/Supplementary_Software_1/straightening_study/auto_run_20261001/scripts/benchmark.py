"""Exploratory 2D contact model, retained for reproducibility of failed attempts.

This script is not the accepted public bending baseline. Use benchmark_3d.py
for formal runs: 2D V1-V3 exhibited contact convergence failures, all archived.

Half length symmetry, measured full width as plane-stress thickness. This is a
declared reduction, not a claim to reproduce the paper's 3-D custom material.
Reaction is doubled for the two inner rollers. Tiny vertical gauge spring is
reported and checked in sensitivity runs; it prevents free-flight singularity.
"""
import argparse,csv,json,hashlib
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mapdl_utils import ROOT,run_mapdl,candidate_commands
from calibrate import csv_write

def read_experiment(sid):
    p=ROOT.parent/'01_raw'/'dataset'/'Part_1_bending'/'initial_bending'/f'specimen_{sid}'/'common.csv'
    with p.open(encoding='utf-8-sig') as f: rows=list(csv.reader(f,delimiter=';'))
    time=np.array([float(v.removesuffix(' s')) for v in rows[0][4:]])
    chan={row[0]:np.array([float(v) if v else np.nan for v in row[4:]]) for row in rows[1:]}
    out=np.c_[time,-chan['Weg.DIM'],-chan['Kraft.DIM'],-chan['Durchbiegung']]
    csv_write(ROOT/'processed'/f'bending_{sid}_machine.csv',['time_s','tool_relative_displacement_mm','force_N','reported_deflection_mm'],out)
    return out

def build(sid,ny,dx,weak,friction,step_factor,material=None,elastic=False,limit=None):
    dat=read_experiment(sid)
    h,b=(8.11,34.93) if sid=='0007' else (8.0,35.0)
    nx=round(135/dx);dx=135/nx;dy=h/ny
    x=np.linspace(0,135,nx+1);y=np.linspace(-h/2,h/2,ny+1)
    node=lambda i,j: 1+i*(ny+1)+j
    mat=candidate_commands() if material is None else Path(material).read_text()
    if elastic:mat='mp,ex,1,204401\nmp,prxy,1,.253\n'
    text='/batch\n/prep7\net,1,182\nkeyopt,1,1,2\nkeyopt,1,3,3\n'+mat
    text+=f'r,1,{b:.9g}\ntype,1\nmat,1\nreal,1\n'
    for i,xx in enumerate(x):
        for j,yy in enumerate(y):text+=f'n,{node(i,j)},{xx:.12g},{yy:.12g},0\n'
    for i in range(nx):
        for j in range(ny): text+=f'e,{node(i,j)},{node(i+1,j)},{node(i+1,j+1)},{node(i,j+1)}\n'
    text+='cm,beam_elements,elem\nnsel,s,loc,x,0\nd,all,ux,0\nallsel,all\n'
    text+=f'et,2,169\nkeyopt,2,2,1\net,3,171\nkeyopt,3,2,1\nkeyopt,3,4,2\nkeyopt,3,10,2\nmp,mu,2,{friction}\n'
    # Full circles with pilot nodes; radius belongs to the contact real set.
    for real,pilot,xx,yy,face,xlo,xhi in [(2,100001,50,h/2+10,h/2,25,90),(3,100002,130,-h/2-10,-h/2,95,135)]:
        text+=f'''r,{real},10,,0.1,0.005
type,2
real,{real}
mat,2
n,{pilot},{xx},{yy:.12g},0
tshap,circ
e,{pilot}
tshap,pilo
e,{pilot}
d,{pilot},ux,0
d,{pilot},uy,0
d,{pilot},rotz,0
cmsel,s,beam_elements
nsle,s
nsel,r,loc,y,{face:.12g}
nsel,r,loc,x,{xlo},{xhi}
type,3
esurf
allsel,all
'''
    center=node(0,ny//2)
    gauge=node(round(130/dx),0)
    text+=f'''et,4,14
keyopt,4,2,2
r,4,{weak:.12g}
type,4
real,4
n,100003,{x[round(130/dx)]:.12g},{-h/2:.12g},0
e,{gauge},100003
d,100003,all,0
d,{gauge},uy,0
allsel,all
finish
/solu
antype,static
nlgeom,on
autots,on
nropt,unsym
neqit,75
cnvtol,f,,0.001,2,1
cnvtol,m,,0.001,2,1
outres,all,last
time,0.1
d,100001,uy,-0.0001
nsubst,2,200,2
solve
ddele,{gauge},uy
time,0.2
nsubst,2,200,2
solve
'''
    kept=sorted(set([0,len(dat)-1,int(np.argmax(dat[:,1])),int(np.argmax(dat[:,2]))]+list(range(0,len(dat),8))))
    # The first data row is zero; loading starts at the next selected frame.
    loads=[(float(dat[i,0]),float(dat[i,1]),int(i)) for i in kept[1:]]
    if limit is not None:loads=[v for v in loads if v[1]<=limit][:20]
    loads.append((float(dat[-1,0]+1),-1.0,-1)) # extra tool withdrawal, not experimental data
    previous=0.0001
    for k,(_,disp,_) in enumerate(loads,1):
        sub=max(2,int(np.ceil(abs(disp-previous)/0.15))*step_factor)
        text+=f'time,{k}\nd,100001,uy,{-disp:.12g}\nnsubst,{sub},{max(500,sub*10)},{sub}\nsolve\n'
        previous=disp
    text+='finish\n/post1\n*cfopen,history,txt\n'
    for k,(time,disp,row) in enumerate(loads,3):
        text+=f'''set,{k},last
*get,fy,node,100001,rf,fy
*get,uyc,node,{center},u,y
*get,uys,node,{node(round(130/dx),ny//2)},u,y
*get,uyg,node,{gauge},u,y
*vwrite,{k},{time:.12g},{disp:.12g},fy,uyc,uys,uyg
(7(E24.16,1X))
'''
    text+='*cfclos\n'
    peak_step=min(range(len(loads)),key=lambda j:abs(loads[j][1]-max(dat[:,1])))+3
    sample_nodes=[(node(i,j),float(x[i]),float(y[j])) for i in range(nx+1) if x[i]<=45 for j in range(ny+1)]
    force_peak_step=min(range(len(loads)),key=lambda j:abs(loads[j][0]-dat[np.argmax(dat[:,2]),0]))+3
    for label,k in [('peak',peak_step),('force_peak',force_peak_step),('residual',len(loads)+2)]:
        text+=f'set,{k},last\nrsys,0\n*cfopen,{label}_field,txt\n'
        for n,xx,yy in sample_nodes:
            text+=f'''*get,sx,node,{n},s,x
*get,ex,node,{n},epel,x
*get,px,node,{n},eppl,x
*get,ux,node,{n},u,x
*get,uy,node,{n},u,y
*vwrite,{n},{xx:.12g},{yy:.12g},sx,ex,px,ux,uy
(8(E24.16,1X))
'''
        text+='*cfclos\n'
    text+='finish\nsave,model,db\n/exit,nosave\n'
    config={'version':'V3 penalty contact elastic seating','specimen':sid,'dimension':'2D plane stress half length','h_mm':h,'b_mm':b,'nx':nx,'ny':ny,'dx_mm':dx,
            'material_sha256':hashlib.sha256(mat.encode()).hexdigest(),'elastic_only':elastic,'limit_mm':limit,
            'friction':friction,'gauge_spring_N_per_mm':weak,'gauge_node':gauge,'reaction_multiplier':2,'step_factor':step_factor,'loads':loads}
    return text,config,dat

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--specimen',default='0007');ap.add_argument('--ny',type=int,default=12);ap.add_argument('--dx',type=float,default=1.0)
    ap.add_argument('--weak',type=float,default=0.01);ap.add_argument('--friction',type=float,default=0.15);ap.add_argument('--step-factor',type=int,default=1)
    ap.add_argument('--material');ap.add_argument('--elastic',action='store_true');ap.add_argument('--limit',type=float)
    args=ap.parse_args(); text,config,dat=build(args.specimen,args.ny,args.dx,args.weak,args.friction,args.step_factor,args.material,args.elastic,args.limit)
    name=f"BEND_V3_{args.specimen}_N{args.ny}_X{args.dx:g}_K{args.weak:g}_MU{args.friction:g}_S{args.step_factor}_{config['material_sha256'][:8]}"+('_debug' if args.limit else '')
    run=ROOT/'benchmark'/name;run.mkdir(exist_ok=True)
    (run/'config.json').write_text(json.dumps(config,indent=2),encoding='utf-8')
    status=run_mapdl(run,text,['history.txt','peak_field.txt','residual_field.txt','solve.rst'],timeout=2400)
    hist=np.loadtxt(run/'history.txt'); force=-2*hist[:,3]
    expforce=np.interp(hist[:-1,1],dat[:,0],dat[:,2]); error=force[:-1]-expforce
    metrics={'force_rmse_N':float(np.sqrt(np.mean(error**2))),'force_nrmse':float(np.sqrt(np.mean(error**2))/max(dat[:,2])),
             'peak_force_N':float(max(force)),'experiment_peak_force_N':float(max(dat[:,2])),
             'final_contact_force_N':float(force[-1]),'final_center_relative_deflection_mm':float(-(hist[-1,4]-hist[-1,5])),
             'max_gauge_force_N':float(max(abs(hist[:,6]*args.weak))),'seconds':status['seconds']}
    (run/'metrics.json').write_text(json.dumps(metrics,indent=2),encoding='utf-8')
    csv_write(run/'force_displacement.csv',['experiment_time_s','tool_displacement_mm','force_MAPDL_N','center_UY_mm','support_axis_UY_mm'],np.c_[hist[:,1:3],force,hist[:,4:6]])
    fig,ax=plt.subplots(figsize=(7,5),layout='constrained');ax.plot(dat[:,1],dat[:,2]/1000,'k-',label='Public experiment');ax.plot(hist[:-1,2],force[:-1]/1000,'-',color='#187fba',label='MAPDL candidate')
    ax.set(xlabel='Relative tool displacement (mm)',ylabel='Total force (kN)',title=f'Four-point bending, specimen {args.specimen}');ax.legend();ax.grid(alpha=.2)
    fig.savefig(run/'force_displacement.png',dpi=180);plt.close(fig);print(json.dumps(metrics),flush=True)

if __name__=='__main__':main()
