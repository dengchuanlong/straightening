"""3D public four-point contact model, half length and half width symmetry.

The two symmetry planes retain Poisson contraction and width curvature; z=b/2
is a free face where the DIC comparisons are taken. SOLID185 enhanced strain,
primitive cylindrical rigid rollers, CONTA174 nodal-to-target detection.
Contact initialization holds ONE outer tangent node vertically at 0 for a
1e-4 mm elastic seating step, then releases it at unchanged tool position.
Both steps are retained in the result history, not erased.
"""
import argparse,json,hashlib
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mapdl_utils import ROOT,run_mapdl,candidate_commands
from benchmark import read_experiment
from calibrate import csv_write

def build(sid,ny,nz,dx,weak,friction,step_factor,material=None,elastic=False,limit=None,fkn=.1,graded=False):
    dat=read_experiment(sid);h,b=(8.11,34.93) if sid=='0007' else (8.0,35.0)
    # All requested dx must divide 50 and 130; add the final overhang endpoint.
    if not (np.isclose(50/dx,round(50/dx)) and np.isclose(130/dx,round(130/dx))):
        raise ValueError('dx must include x=50 and130 tangent locations')
    x=np.unique(np.r_[np.arange(0,135,dx),135]);y=(h/2*np.sin(np.linspace(-np.pi/2,np.pi/2,ny+1))) if graded else np.linspace(-h/2,h/2,ny+1);z=np.linspace(0,b/2,nz+1)
    node=lambda i,j,k: 1+(i*(ny+1)+j)*(nz+1)+k
    mat=candidate_commands() if material is None else material.read_text()
    if elastic:mat='mp,ex,1,204401\nmp,prxy,1,.253\n'
    text='/batch\n/prep7\net,1,185\nkeyopt,1,2,2\n'+mat+'\ntype,1\nmat,1\n'
    for i,xx in enumerate(x):
        for j,yy in enumerate(y):
            for k,zz in enumerate(z):text+=f'n,{node(i,j,k)},{xx:.12g},{yy:.12g},{zz:.12g}\n'
    for i in range(len(x)-1):
        for j in range(ny):
            for k in range(nz):
                ns=[node(i,j,k),node(i+1,j,k),node(i+1,j+1,k),node(i,j+1,k),node(i,j,k+1),node(i+1,j,k+1),node(i+1,j+1,k+1),node(i,j+1,k+1)]
                text+='e,'+','.join(map(str,ns))+'\n'
    text+='cm,beam_elements,elem\nnsel,s,loc,x,0\nd,all,ux,0\nallsel,all\nnsel,s,loc,z,0\nd,all,uz,0\nallsel,all\n'
    text+=f'et,2,170\net,3,174\nkeyopt,3,2,1\nkeyopt,3,4,2\nkeyopt,3,10,2\nmp,mu,2,{friction}\n'
    for real,pilot,xx,yy,face,xlo,xhi in [(2,100001,50,h/2+10,h/2,25,90),(3,100002,130,-h/2-10,-h/2,95,135)]:
        text+=f'''r,{real},10,,{fkn:.12g},0.005
type,2
real,{real}
mat,2
n,{pilot},{xx},{yy:.12g},0
n,{pilot+10},{xx},{yy:.12g},-5
n,{pilot+20},{xx},{yy:.12g},{b/2+5:.12g}
tshap,cyli
e,{pilot+10},{pilot+20}
tshap,pilo
e,{pilot}
d,{pilot},all,0
cmsel,s,beam_elements
nsle,s
nsel,r,loc,y,{face:.12g}
nsel,r,loc,x,{xlo},{xhi}
type,3
esurf
allsel,all
'''
    ii=int(np.where(np.isclose(x,130))[0][0]);gauge=node(ii,0,0);center=node(0,ny//2,0)
    text+=f'''et,4,14
keyopt,4,2,2
r,4,{weak:.12g}
type,4
real,4
n,100003,130,{-h/2:.12g},0
e,{gauge},100003
d,100003,all,0
d,{gauge},uy,0
allsel,all
finish
/solu
antype,static
nlgeom,on
autots,on
nropt,unsym
neqit,60
cnvtol,f,,0.001,2,1
cnvtol,m,,0.001,2,1
outres,all,last
time,0.1
d,100001,uy,-0.0001
nsubst,2,200,2
solve
ddele,{gauge},uy
time,0.2
nsubst,2,200,2
solve
'''
    kept=sorted(set([0,len(dat)-1,int(np.argmax(dat[:,1])),int(np.argmax(dat[:,2]))]+list(range(0,len(dat),8))))
    loads=[(float(dat[i,0]),float(dat[i,1]),int(i)) for i in kept[1:]]
    if limit is not None:loads=[v for v in loads if v[1]<=limit][:20]
    loads.append((float(dat[-1,0]+1),-1.0,-1))
    previous=.0001
    for k,(_,disp,_) in enumerate(loads,1):
        sub=max(2,int(np.ceil(abs(disp-previous)/0.15))*step_factor)
        text+=f'time,{k}\nd,100001,uy,{-disp:.12g}\nnsubst,{sub},{max(500,sub*10)},{sub}\nsolve\n';previous=disp
    text+='finish\n/post1\n*cfopen,seating_history,txt\n'
    for k in [1,2]:
        text+=f'set,{k},last\n*get,fy,node,100001,rf,fy\n*get,uyg,node,{gauge},u,y\n*vwrite,{k},fy,uyg\n(3(E24.16,1X))\n'
    text+='*cfclos\n*cfopen,history,txt\n'
    for k,(time,disp,row) in enumerate(loads,3):
        text+=f'''set,{k},last
*get,fy,node,100001,rf,fy
*get,uyc,node,{center},u,y
*get,uys,node,{node(ii,ny//2,0)},u,y
*get,uyg,node,{gauge},u,y
*vwrite,{k},{time:.12g},{disp:.12g},fy,uyc,uys,uyg
(7(E24.16,1X))
'''
    text+='*cfclos\n'
    text+='*cfopen,contact_quality,txt\n'
    for k in range(3,len(loads)+3):
        text+=f'''set,{k},last
esel,s,type,,3
etable,erase
etable,pen,cont,pene
*get,ne,elem,0,count
*get,eid,elem,0,num,min
maxpen=0
*do,jj,1,ne
*get,peni,elem,eid,etab,pen
maxpen=max(maxpen,peni)
eid=elnext(eid)
*enddo
*vwrite,{k},maxpen
(2(E24.16,1X))
allsel,all
'''
    text+='*cfclos\n'
    peak=max(range(len(loads)-1),key=lambda j:loads[j][1])+3
    fp=min(range(len(loads)-1),key=lambda j:abs(loads[j][0]-dat[np.argmax(dat[:,2]),0]))+3
    for label,k in [('peak',peak),('force_peak',fp),('residual',len(loads)+2)]:
        text+=f'set,{k},last\nrsys,0\n*cfopen,{label}_field,txt\n'
        for i,xx in enumerate(x):
            if xx>45:continue
            for j,yy in enumerate(y):
                for iz in [0,nz]:
                    n=node(i,j,iz);zz=z[iz]
                    pget='px=0' if elastic else f'*get,px,node,{n},eppl,x'
                    text+=f'''*get,sx,node,{n},s,x
*get,ex,node,{n},epel,x
{pget}
*get,ux,node,{n},u,x
*get,uy,node,{n},u,y
*vwrite,{n},{xx:.12g},{yy:.12g},sx,ex,px,ux,uy,{zz:.12g}
(9(E24.16,1X))
'''
        text+='*cfclos\n'
    text+='finish\nsave,model,db\n/exit,nosave\n'
    cfg={'version':'3D V3 penalty contact elastic seating','specimen':sid,'dimension':'3D half length half width','h_mm':h,'b_mm':b,'ny':ny,'nz':nz,'dx_mm':dx,
        'weak_spring_N_per_mm':weak,'friction':friction,'FKN_factor':fkn,'graded_y':graded,'y_layers_mm':y.tolist(),'reaction_multiplier':4,'material_sha256':hashlib.sha256(mat.encode()).hexdigest(),'elastic_only':elastic,'limit_mm':limit,'step_factor':step_factor,'loads':loads}
    return text,cfg,dat

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--specimen',default='0007');ap.add_argument('--ny',type=int,default=8);ap.add_argument('--nz',type=int,default=4);ap.add_argument('--dx',type=float,default=2)
    ap.add_argument('--weak',type=float,default=.01);ap.add_argument('--friction',type=float,default=.15);ap.add_argument('--step-factor',type=int,default=1);ap.add_argument('--material');ap.add_argument('--elastic',action='store_true');ap.add_argument('--limit',type=float)
    ap.add_argument('--fkn',type=float,default=.1)
    ap.add_argument('--graded',action='store_true')
    args=ap.parse_args();text,cfg,dat=build(args.specimen,args.ny,args.nz,args.dx,args.weak,args.friction,args.step_factor,None if not args.material else __import__('pathlib').Path(args.material),args.elastic,args.limit,args.fkn,args.graded)
    name=f"BEND_3D_V3_{args.specimen}_Y{args.ny}_Z{args.nz}_X{args.dx:g}_K{args.weak:g}_MU{args.friction:g}_FKN{args.fkn:g}_S{args.step_factor}_{cfg['material_sha256'][:8]}"+('_graded' if args.graded else '')+('_debug' if args.limit else '')
    run=ROOT/'benchmark'/name;run.mkdir(exist_ok=True);(run/'config.json').write_text(json.dumps(cfg,indent=2),encoding='utf-8')
    status=run_mapdl(run,text,['history.txt','force_peak_field.txt','residual_field.txt','contact_quality.txt','solve.rst'],timeout=3600)
    hist=np.loadtxt(run/'history.txt');force=-4*hist[:,3];expforce=np.interp(hist[:-1,1],dat[:,0],dat[:,2]);err=force[:-1]-expforce
    metrics={'force_rmse_N':float(np.sqrt(np.mean(err**2))),'force_nrmse':float(np.sqrt(np.mean(err**2))/max(dat[:,2])),
        'peak_force_N':float(max(force)),'experiment_peak_force_N':float(max(dat[:,2])),'final_contact_force_N':float(force[-1]),
        'final_center_relative_deflection_mm':float(-(hist[-1,4]-hist[-1,5])),'max_weak_force_N':float(max(abs(hist[:,6]*args.weak))),
        'seconds':status['seconds'],'elastic_debug':args.elastic,'seating_history':np.loadtxt(run/'seating_history.txt').tolist(),
        'max_contact_penetration_mm':float(max(np.loadtxt(run/'contact_quality.txt')[:,1]))}
    (run/'metrics.json').write_text(json.dumps(metrics,indent=2),encoding='utf-8');csv_write(run/'force_displacement.csv',['experiment_time_s','tool_displacement_mm','force_MAPDL_N','center_UY_mm','support_axis_UY_mm'],np.c_[hist[:,1:3],force,hist[:,4:6]])
    fig,ax=plt.subplots(figsize=(7,5),layout='constrained');ax.plot(dat[:,1],dat[:,2]/1000,'k-',label='Public experiment');ax.plot(hist[:-1,2],force[:-1]/1000,label='3D MAPDL')
    ax.set(xlabel='Relative tool displacement (mm)',ylabel='Total force (kN)',title=f'Four-point bending {args.specimen}');ax.legend();ax.grid(alpha=.2);fig.savefig(run/'force_displacement.png',dpi=180);plt.close(fig)
    print(json.dumps(metrics),flush=True)

if __name__=='__main__':main()
