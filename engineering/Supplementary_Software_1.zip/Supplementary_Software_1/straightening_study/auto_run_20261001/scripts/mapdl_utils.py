from pathlib import Path
import hashlib,json,subprocess,time,shutil,os
import msvcrt
import psutil

ROOT=Path(__file__).resolve().parents[1]
MAPDL=Path(r'G:\Program Files\ANSYS Inc\ANSYS Student\v261\ansys\bin\winx64\ANSYS261.exe')

def _process_guard_path():
    return ROOT/'logs'/'MAPDL_process_guard.json'

def _write_process_guard(record):
    """A stale/blocked guard prevents another solver even after an OS unlock."""
    path=_process_guard_path();path.parent.mkdir(exist_ok=True)
    temporary=path.with_name(f'.{path.name}.{os.getpid()}.tmp')
    temporary.write_text(json.dumps(record,indent=2),encoding='utf-8')
    temporary.replace(path)

def _raise_if_process_guard():
    path=_process_guard_path()
    if path.exists():
        raise RuntimeError(f'Solver queue blocked by an unresolved process guard: {path}; '
                           'inspect its recorded PID/create_time identities before clearing it.')

class _OwnedProcessTree:
    """Track only the launched process and descendants discovered from it.

    Process objects carry PID/create_time identity. No process-name searches or
    global process enumeration are used to find termination targets. Polling
    starts immediately and continues after launcher exit for captured children.
    """
    def __init__(self,proc):
        self.proc=proc;self.known={};self.identity_errors=[]
        try:self._remember(psutil.Process(proc.pid))
        except psutil.NoSuchProcess:pass
        except psutil.Error as error:self._error('initial_identity',proc.pid,error)

    def _error(self,operation,pid,error):
        value={'operation':operation,'pid':pid,'error':repr(error)}
        if value not in self.identity_errors:self.identity_errors.append(value)

    def _remember(self,process):
        identity=(process.pid,process.create_time())
        self.known.setdefault(identity,process)

    def _same_alive(self,identity,process):
        try:
            # is_running checks PID reuse; fresh create_time is an additional
            # explicit identity check before any targeted termination action.
            return process.is_running() and psutil.Process(process.pid).create_time()==identity[1]
        except psutil.NoSuchProcess:return False
        except psutil.Error as error:
            self._error('check_identity',identity[0],error);return None

    def capture(self):
        for identity,process in list(self.known.items()):
            if self._same_alive(identity,process) is not True:continue
            try:
                for child in process.children(recursive=True):
                    try:self._remember(child)
                    except psutil.NoSuchProcess:pass
                    except psutil.Error as error:self._error('child_identity',child.pid,error)
            except psutil.NoSuchProcess:pass
            except psutil.Error as error:self._error('capture_children',identity[0],error)

    def live(self):
        return [(identity,process) for identity,process in self.known.items()
                if self._same_alive(identity,process) is not False]

    def evidence(self):
        return {'identities':[{'pid':pid,'create_time':created} for pid,created in self.known],
                'live_identities':[{'pid':identity[0],'create_time':identity[1]}
                                   for identity,_ in self.live()],
                'identity_errors':self.identity_errors.copy(),
                'tracking_interval_seconds':0.1}

def _wait_owned_tree(proc,tree,timeout):
    deadline=time.monotonic()+timeout
    while True:
        tree.capture()
        if tree.identity_errors:raise RuntimeError('Cannot verify own process-tree identities')
        returncode=proc.poll()
        if returncode is not None and not tree.live():return returncode
        remaining=deadline-time.monotonic()
        if remaining<=0:raise subprocess.TimeoutExpired(proc.args,timeout)
        interval=min(.1,remaining)
        if returncode is None:
            try:proc.wait(timeout=interval)
            except subprocess.TimeoutExpired:pass
        else:time.sleep(interval)

def _terminate_owned_tree(proc,tree,stream,timeout=10):
    # Capture descendants BEFORE taskkill/fallback can break the parent chain.
    tree.capture();attempts=[]
    root=[(identity,process) for identity,process in tree.live()
          if identity[0]==proc.pid and tree._same_alive(identity,process) is True]
    if root:
        try:
            killed=subprocess.run(['taskkill','/PID',str(proc.pid),'/T','/F'],
                                  stdout=stream,stderr=subprocess.STDOUT,
                                  creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0),timeout=timeout)
            attempts.append({'method':'taskkill_own_tree','pid':proc.pid,'returncode':killed.returncode})
        except (subprocess.TimeoutExpired,OSError) as error:
            attempts.append({'method':'taskkill_own_tree','pid':proc.pid,'error':repr(error)})
    # A nonzero taskkill or an already-exited launcher cannot orphan the known
    # children: psutil objects captured above remain valid PID/time identities.
    deadline=time.monotonic()+timeout
    while True:
        tree.capture();live=tree.live()
        if not live:break
        for identity,process in reversed(live):
            if tree._same_alive(identity,process) is not True:continue
            try:
                process.kill()  # psutil also preemptively checks PID reuse.
                attempts.append({'method':'kill_captured_identity','pid':identity[0],
                                 'create_time':identity[1]})
            except psutil.NoSuchProcess:pass
            except psutil.Error as error:
                attempts.append({'method':'kill_captured_identity','pid':identity[0],
                                 'create_time':identity[1],'error':repr(error)})
        if time.monotonic()>=deadline:break
        time.sleep(.1)
    try:proc.wait(timeout=1)
    except subprocess.TimeoutExpired:
        attempts.append({'method':'wait_launcher','error':'launcher still alive'})
    evidence=tree.evidence()
    return {**evidence,'termination_attempts':attempts,
            'tree_exit_confirmed':not evidence['live_identities'] and not evidence['identity_errors']}

def _run_mapdl(folder, input_text, expected, timeout=1800, cores=2,initial_files=None):
    _raise_if_process_guard()
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    signature=hashlib.sha256(input_text.encode('ascii')).hexdigest()
    state=folder/'status.json'
    if state.exists():
        previous=json.loads(state.read_text())
        if previous.get('input_sha256')==signature and previous.get('accepted_exit') and all((folder/p).exists() for p in expected):
            return previous
        # Keep the complete evidence when a script or setting changes in-place.
        archive=folder/'previous_attempts'/time.strftime('%Y%m%d_%H%M%S')
        archive.mkdir(parents=True,exist_ok=False)
        for item in list(folder.iterdir()):
            if item.name=='previous_attempts': continue
            shutil.move(str(item),str(archive/item.name))
    for source in initial_files or []:
        source=Path(source);shutil.copy2(source,folder/source.name)
    (folder/'input.inp').write_text(input_text,encoding='ascii')
    cmd=[str(MAPDL),'-b','-smp','-np',str(cores),'-m','2048','-db','512','-p','ansys',
         '-j','solve','-dir',str(folder),'-i',str(folder/'input.inp'),'-o',str(folder/'solve.out')]
    (folder/'command.json').write_text(json.dumps(cmd,indent=2),encoding='utf-8')
    begin=time.time()
    timed_out=False
    process_exception=None;proc=None;tree=None
    cleanup={'tree_exit_confirmed':False,'identities':[],'live_identities':[],'identity_errors':[]}
    # Created before Popen: abnormal Python exit leaves a persistent guard,
    # rather than silently releasing the OS lock and permitting a new solver.
    guard={'phase':'launching','folder':str(folder),'input_sha256':signature,
           'owner_python_pid':os.getpid(),'created_epoch':time.time()}
    _write_process_guard(guard)
    with (folder/'launcher.log').open('w',encoding='utf-8') as stream:
        try:
            proc=subprocess.Popen(cmd,cwd=folder,stdout=stream,stderr=subprocess.STDOUT,
                                  creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
            tree=_OwnedProcessTree(proc);tree.capture()
            _write_process_guard({**guard,'phase':'running',**tree.evidence()})
            returncode=_wait_owned_tree(proc,tree,timeout)
            evidence=tree.evidence()
            cleanup={**evidence,'termination_attempts':[],
                     'tree_exit_confirmed':not evidence['live_identities'] and not evidence['identity_errors']}
        except subprocess.TimeoutExpired:
            timed_out=True
            returncode=-999
        except BaseException as error:
            process_exception=repr(error);returncode=-998
        finally:
            if proc is None:
                # Popen failed; no launcher was created by this call.
                cleanup={'tree_exit_confirmed':True,'identities':[],'live_identities':[],
                         'identity_errors':[],'termination_attempts':[]}
            elif not cleanup['tree_exit_confirmed']:
                try:
                    if tree is None:tree=_OwnedProcessTree(proc)
                    cleanup=_terminate_owned_tree(proc,tree,stream)
                except BaseException as error:
                    cleanup={**cleanup,'cleanup_exception':repr(error),'tree_exit_confirmed':False}
            if cleanup['tree_exit_confirmed']:
                _process_guard_path().unlink()
            else:
                _write_process_guard({**guard,'phase':'blocked','timed_out':timed_out,
                                      'process_exception':process_exception,'cleanup':cleanup})
    output=(folder/'solve.out').read_text(errors='replace') if (folder/'solve.out').exists() else ''
    errors=output.count('*** ERROR ***')
    result={'input_sha256':signature,'returncode':returncode,'seconds':time.time()-begin,'timed_out':timed_out,
            'process_exception':process_exception,'process_tree_cleanup':cleanup,
            'queue_blocked':_process_guard_path().exists(),
            'error_count':errors,'warning_count':output.count('*** WARNING ***'),
            'expected_files':{p:(folder/p).exists() for p in expected},
            'accepted_exit':returncode==0 and errors==0 and cleanup['tree_exit_confirmed'] and all((folder/p).exists() for p in expected)}
    state.write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps({'run':str(folder.relative_to(ROOT)),**result}),flush=True)
    if not result['accepted_exit']: raise RuntimeError(f'MAPDL run failed: {folder}; see solve.out and launcher.log')
    return result

def run_mapdl(folder,input_text,expected,timeout=1800,cores=2,initial_files=None):
    """Student permits one active solver; the OS releases this lock on exit."""
    lockfile=ROOT/'logs'/'MAPDL_serial.lock'
    lockfile.parent.mkdir(exist_ok=True)
    with lockfile.open('a+b') as lock:
        if lock.tell()==0:lock.write(b'0');lock.flush()
        announced=False
        while True:
            lock.seek(0)
            try:msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1);break
            except OSError:
                if not announced:print('Waiting for the active Student solver to finish.',flush=True);announced=True
                time.sleep(.5)
        try:return _run_mapdl(folder,input_text,expected,timeout,cores,initial_files)
        finally:lock.seek(0);msvcrt.locking(lock.fileno(),msvcrt.LK_UNLCK,1)

def active_material():
    reference=ROOT/'protocol'/'active_material.json'
    if reference.exists():return json.loads(reference.read_text(encoding='utf-8'))
    return {'version':'v001','parameter_file':'material/candidate_material.json','command_file':'material/candidate_material.inp'}

def candidate_commands():
    return (ROOT/active_material()['command_file']).read_text()

def candidate_parameters():
    return json.loads((ROOT/active_material()['parameter_file']).read_text(encoding='utf-8'))
