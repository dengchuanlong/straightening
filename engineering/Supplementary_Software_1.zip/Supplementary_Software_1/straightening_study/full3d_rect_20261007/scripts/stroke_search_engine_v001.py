"""Actual-FE search with an explicit execution backend. No solve on import.

This first version keeps the existing seven-point screening and actual-J
midpoint refinement. A restart record remains a restart record; a cold-plan
SHA is never substituted for its executed input SHA. No formal table is written.
"""
from pathlib import Path
from decimal import Decimal, ROUND_FLOOR
import hashlib
import json
import math
import re
import time
import traceback

import numpy as np
import search_cases as rules
from solver_runner import ROOT, write_json

VERSION = 'EXPLICIT_BACKEND_SEARCH_V001'
MODES = {'cold_full_history', 'warm_multiframe_continuation'}
COMMON_SOURCE = Path(rules.__file__)
MODEL_SOURCE = Path(__file__).with_name('rect_model.py')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def json_sha(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
                                    allow_nan=False).encode('utf-8')).hexdigest()


def digest(value):
    return isinstance(value, str) and re.fullmatch(r'[0-9a-f]{64}', value) is not None


def finite_number(value):
    return type(value) in (int, float) and math.isfinite(value)


def validate_plan(plan, mode, stroke):
    if mode not in MODES or plan.get('execution_mode') != mode:
        raise ValueError('An explicit real FE execution mode is required.')
    if not digest(plan.get('executed_input_sha256')):
        raise ValueError('The actual planned solver input SHA is required.')
    if not finite_number(plan.get('stroke_mm')) or not finite_number(stroke) or plan['stroke_mm'] != stroke:
        raise ValueError('Planned candidate stroke differs from the evaluated stroke.')
    if mode == 'warm_multiframe_continuation':
        if not digest(plan.get('base_executed_input_sha256')) or not digest(plan.get('normalized_full_cold_plan_sha256')):
            raise ValueError('Independent C0 and plan-only cold identities are required.')
        if plan.get('normalized_full_cold_plan_is_execution_evidence') is not False:
            raise ValueError('A normalized cold plan is not an actual cold solve.')


def validate_record(item, plan, mode, case_id, model_sha):
    # Verify identity even for rejected solver records. Physical admissibility
    # is checked separately by the unchanged declared common rules.
    if item.get('software_mock') or item.get('solver_status', {}).get('software_mock'):
        raise ValueError('Software fixtures cannot enter an actual FE search.')
    if item.get('execution_mode') != mode or item.get('case_id') != case_id:
        raise ValueError('Actual execution mode/case differs from the search.')
    if item.get('input_sha256') != plan['executed_input_sha256'] or item.get('model_source_sha256') != model_sha:
        raise ValueError('Actual input/model identity differs from the frozen plan.')
    if not finite_number(item.get('stroke_mm')) or item['stroke_mm'] != plan['stroke_mm']:
        raise ValueError('Actual candidate stroke differs from the planned stroke.')
    if type(item.get('accepted_solver')) is not bool or type(item.get('parsed')) is not bool:
        raise ValueError('Solver/parser acceptance must be explicit booleans, not truthy claims.')
    if item['parsed'] and not item['accepted_solver']:
        raise ValueError('Parsed physics cannot qualify a rejected physical solve.')
    status = item.get('solver_status', {})
    if item.get('accepted_solver') is True:
        tree = status.get('process_tree', {})
        identities = tree.get('identities', [])
        if (status.get('accepted_exit') is not True or status.get('input_sha256') != item['input_sha256']
                or type(status.get('returncode')) is not int or status['returncode'] != 0
                or type(status.get('error_count')) is not int or status['error_count'] != 0
                or status.get('timed_out') is not False or status.get('exception') is not None
                or tree.get('tree_exit_confirmed') is not True or not identities
                or tree.get('live_identities') != [] or tree.get('identity_errors') != []):
            raise ValueError('Accepted FE candidate lacks actual owned solver completion.')
        for identity in identities:
            pid, ctime = identity.get('pid'), identity.get('create_time')
            if type(pid) is not int or pid <= 0 or type(ctime) not in (int, float) or not math.isfinite(ctime) or ctime <= 0:
                raise ValueError('Accepted FE candidate has invalid actual process identity.')
    if mode == 'warm_multiframe_continuation':
        for key in ('base_executed_input_sha256', 'normalized_full_cold_plan_sha256'):
            if item.get(key) != plan[key]:
                raise ValueError('Actual restart/cold-plan lineage changed.')
        if item.get('normalized_full_cold_plan_is_execution_evidence') is not False:
            raise ValueError('A cold plan was misrepresented as execution evidence.')
    if item['parsed']:
        metrics = item.get('metrics', {})
        required = ('initial_error_mm', 'final_error_mm', 'max_ip_accumulated_plastic_strain',
                    'max_abs_ip_axial_total_strain', 'final_press_force_N', 'peak_press_force_N',
                    'max_contact_penetration_mm', 'final_max_tool_force_vector_bound_N')
        if any(not finite_number(metrics.get(key)) for key in required):
            raise ValueError('Parsed physical quantities must be finite numbers, not boolean/missing claims.')
        final = metrics.get('states', {}).get('D', {})
        if any(not finite_number(final.get(key)) for key in
               ('punch_force_N', 'support_force_N', 'prebend_head_force_N', 'prebend_support_force_N')):
            raise ValueError('Final unloaded tool reactions must be explicit finite numbers.')


def search(config, *, plan_candidate, evaluate_candidate, check_sources,
           execution_mode, output_folder, upper=None, resolution=.02,
           max_trials=44, timeout=7200, screening_n=7):
    """Plan/evaluate callbacks use (config, stroke[, timeout]) and actual records.

    check_sources() raises on shared source/C0 changes. Such errors stop the
    search; they are never treated as an isolated failed physical candidate.
    All outputs stay in one fresh caller-selected folder beneath warm_cases.
    """
    if execution_mode not in MODES:
        raise ValueError('Explicit cold or independent multiframe execution required.')
    cfg = dict(config)
    case_id = str(cfg.get('case_id', ''))
    if not re.fullmatch(r'[A-Za-z0-9_-]{1,100}', case_id):
        raise ValueError('Use a new simple case identity.')
    folder = Path(output_folder).resolve()
    if not folder.is_relative_to((ROOT / 'warm_cases').resolve()) or folder.exists():
        raise FileExistsError('Use a fresh folder under warm_cases; existing search decisions are preserved.')
    if upper is not None and not finite_number(upper):
        raise ValueError('Search upper limit must be an explicit finite number.')
    if not finite_number(cfg.get('prebend_tool_stroke_mm')):
        raise ValueError('Prebend stroke must be an explicit finite number.')
    requested = float(upper if upper is not None else max(8., 1.6 * cfg['prebend_tool_stroke_mm']))
    if not math.isfinite(requested):
        raise ValueError('Finite search upper limit required.')
    bound = float(Decimal(str(requested)).quantize(Decimal('0.000001'), rounding=ROUND_FLOOR))
    if (type(max_trials) is not int or type(screening_n) is not int or screening_n < 7 or max_trials < screening_n
            or type(resolution) not in (float, int) or not math.isfinite(resolution) or resolution < 2e-6
            or type(timeout) not in (float, int) or not math.isfinite(timeout) or timeout <= 0 or bound <= 0):
        raise ValueError('Finite positive settings and an adequate integer FE budget are required.')
    sources = {str(p): sha(p) for p in (Path(__file__), COMMON_SOURCE, MODEL_SOURCE)}
    model_sha = sources[str(MODEL_SOURCE)]
    settings = dict(version=VERSION, execution_mode=execution_mode, requested_upper_mm=requested,
                    upper_mm=bound, resolution_mm=float(resolution), max_trials=max_trials,
                    timeout_s=float(timeout), screening_n=screening_n, tie_error_mm=0., screening_noise_mm=0.)
    result = dict(case_id=case_id, config=cfg, case_config_sha256=json_sha(cfg), search_version=VERSION,
                  execution_mode=execution_mode, search_settings=settings, search_settings_sha256=json_sha(settings),
                  implementation_sources=sources, trials=[], candidate_plans=[], label=None, diagnostic_label=None,
                  complete=False, search_acceptance_passed=False, qualified_for_formal_dataset=False,
                  formal_generation_unlocked=False, global_optimum_proven=False, machine_learning_run=False,
                  backup_created=False, incompletion_reasons=[])
    cache = {}
    folder.mkdir(parents=True)

    def intact():
        for path, expected in sources.items():
            if sha(path) != expected:
                raise RuntimeError('Shared implementation changed during the search: ' + path)
        check_sources()

    def save():
        write_json(folder / 'search_result.json', result)
        rows = []
        for item in result['trials']:
            valid, reason = rules.admissibility(item)
            rows.append({**item, **item.get('metrics', {}), 'admissible': valid,
                         'exclusion_reason': reason, 'seconds': item.get('solver_status', {}).get('seconds'),
                         'record_origin': execution_mode})
        rules.csv_dump(folder / 'candidate_curve.csv', rules.TRIAL_FIELDS, rows)

    def sample(value):
        stroke = round(float(value), 6)
        if not math.isfinite(stroke) or not 0 <= stroke <= bound:
            raise ValueError('Candidate outside the frozen physical interval.')
        if stroke in cache or len(cache) >= max_trials:
            return False
        intact()
        plan = plan_candidate(cfg, stroke)
        validate_plan(plan, execution_mode, stroke)
        result['candidate_plans'].append(plan)
        save()  # Save planned API attempt before a potentially failing solver.
        start = time.monotonic()
        try:
            item = evaluate_candidate(cfg, stroke, timeout)
        except Exception as error:
            # No synthetic force, J, material value or owned process is created.
            item = dict(case_id=case_id, stroke_mm=stroke, execution_mode=execution_mode,
                        input_sha256=plan['executed_input_sha256'], model_source_sha256=model_sha,
                        accepted_solver=False, parsed=False, directory='', exception=repr(error),
                        traceback=traceback.format_exc(), wall_seconds=time.monotonic() - start,
                        cause='Unknown unless the backend preserved a more specific failure receipt.',
                        impact='Candidate rejected; no interpolated label or fabricated solver acceptance.')
            for key in ('base_executed_input_sha256', 'normalized_full_cold_plan_sha256',
                        'normalized_full_cold_plan_is_execution_evidence'):
                if key in plan: item[key] = plan[key]
        intact()
        validate_record(item, plan, execution_mode, case_id, model_sha)
        cache[stroke] = item
        result['trials'].append(item)
        save()
        return True

    try:
        intact()
        coarse = np.round(np.linspace(0., bound, screening_n), 6)
        for value in coarse: sample(value)
        result['coarse_screening_strokes_mm'] = coarse.tolist()
        result['coarse_screening_exclusions'] = [dict(stroke_mm=float(s), reason=rules.admissibility(cache[float(s)])[1])
                                                for s in coarse if not rules.admissibility(cache[float(s)])[0]]
        valleys = rules._valleys(coarse, cache, 0.)
        result['identified_screening_valleys'] = valleys
        while True:
            statuses = [rules._valley_status(v, cache, resolution) for v in valleys]
            usable, raw, selected, raw_near, selected_near = rules._selection(cache, resolution, 0.)
            if not usable or len(cache) >= max_trials: break
            if statuses and all(v['resolved'] for v in statuses) and raw_near['resolved'] and selected_near['resolved']: break
            created = False
            for status in statuses:
                if not status['resolved']:
                    for proposal in status.get('proposals', []): created = sample(proposal) or created
            for near in (raw_near, selected_near):
                if not near['resolved']:
                    for proposal in near.get('proposals', []): created = sample(proposal) or created
            if not created: break
        statuses = [rules._valley_status(v, cache, resolution) for v in valleys]
        usable, raw, selected, raw_near, selected_near = rules._selection(cache, resolution, 0.)
        reasons = []
        if not usable: reasons.append('no admissible actual FE candidates')
        if not statuses: reasons.append('no interior actual coarse-screening valley')
        if statuses and not all(v['resolved'] for v in statuses): reasons.append('unresolved identified valley')
        if selected is not None:
            if raw_near['boundary'] or selected_near['boundary']: reasons.append('actual sampled/admissible boundary minimum')
            if not raw_near['resolved'] or not selected_near['resolved']: reasons.append('actual two-sided total width exceeds the declared resolution')
        if reasons and len(cache) >= max_trials: reasons.append('actual candidate budget exhausted')
        result.update(refined_valleys=statuses, raw_best_neighborhood=raw_near, selected_neighborhood=selected_near,
                      all_identified_valleys_resolved=bool(statuses) and all(v['resolved'] for v in statuses),
                      bracket_resolution_met=bool(selected is not None and raw_near['resolved'] and selected_near['resolved']),
                      search_boundary=bool(selected is not None and (raw_near['boundary'] or selected_near['boundary'])),
                      incompletion_reasons=reasons)
        if selected is not None:
            label = rules._label(cfg, selected, raw, selected_near, result, cache)
            label.update(search_version=VERSION, execution_mode=execution_mode,
                         executed_candidate_input_sha256=selected['input_sha256'],
                         formal_qualification_pending_new_execution_mode_reader=True,
                         qualified_for_formal_dataset=False)
            if execution_mode == 'warm_multiframe_continuation':
                for key in ('base_executed_input_sha256', 'normalized_full_cold_plan_sha256',
                            'normalized_full_cold_plan_is_execution_evidence'):
                    label[key] = selected[key]
            if reasons: result['diagnostic_label'] = label
            else: result.update(label=label, complete=True, search_acceptance_passed=True)
        intact()
    except Exception as error:
        result.update(exception=repr(error), traceback=traceback.format_exc(), complete=False,
                      search_acceptance_passed=False, label=None)
        result['incompletion_reasons'].append('search/source integrity exception; no complete label')
    save()
    return result
