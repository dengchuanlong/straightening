"""Independent RECT3D004 C0 multiframe-restart preparation and audit.

No solve occurs on import or preparation. Only explicit run() uses the project's
single solver lock. This prototype does not unlock formal generation or clean
any file. Branch copies are writable computational inputs, never shared links.
"""
from pathlib import Path
import argparse
import hashlib
import json
import math
import re
import shutil

import numpy as np
import rect_model
from solver_runner import ROOT, EXE, run_solver, write_json

VERSION='C0_MULTIFRAME_RECT004_V001'
CORE=Path(rect_model.__file__)
IMPORTED_CORE_SHA=hashlib.sha256(CORE.read_bytes()).hexdigest()
DOC_ROOT='https://ansyshelp.ansys.com/public/Views/Secured/corp/v261/en/'
OFFICIAL={name:DOC_ROOT+path for name,path in {
 'multiframe':'ans_bas/Hlp_G_BAS3_12.html',
 'RESCONTROL':'ans_cmd/Hlp_C_RESCONTROL.html',
 'ANTYPE':'ans_cmd/Hlp_C_ANTYPE.html',
 'PARSAV':'ans_cmd/Hlp_C_PARSAV.html',
 'PARRES':'ans_cmd/Hlp_C_PARRES.html',
 'GET':'ans_cmd/Hlp_C_GET.html'}.items()}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _number(value):
    return format(float(value),'.17g')


def _folder(path):
    result=Path(path).resolve()
    if not result.is_relative_to(ROOT.resolve()):
        raise ValueError('Warm calculation folder must lie inside this new project.')
    return result


def _name(value):
    if not re.fullmatch(r'[A-Za-z0-9_-]{1,100}',value):
        raise ValueError('Use a new simple ASCII calculation name.')
    return value


def _core(config):
    if rect_model.VERSION!='RECT3D004' or sha(CORE)!=IMPORTED_CORE_SHA:
        raise ValueError('Reload and review the frozen RECT3D004 source before preparation.')
    text,meta=rect_model.build(config)
    if sha(CORE)!=IMPORTED_CORE_SHA:
        raise ValueError('Core changed during preparation.')
    if not meta['config']['save_full_strain_trajectory']:
        raise ValueError('Warm validation requires actual full-path strain output.')
    return text,meta


def _parts(text,meta):
    # The actual core-generated LS1..6 and LS7..11 are reused byte-for-byte.
    seventh='time,7\n'
    post='finish\n/post1\n'
    if text.count(seventh)!=1 or text.count(post)!=1:
        raise ValueError('Core solution boundaries are not uniquely recognized.')
    p7=text.index(seventh); pp=text.index(post,p7)
    header_end=text.index(f"set,1,last\nallsel,all\n*dim,UA,array,{meta['mesh_count']['work_nodes']},3\n",pp)
    end=text.index('*cfopen,complete,txt\n',header_end)
    positions=[]
    for state,step in meta['state_stages'].items():
        marker=f"set,{step},last\nallsel,all\n*dim,U{state},array,{meta['mesh_count']['work_nodes']},3\n"
        positions.append((state,text.index(marker,header_end)))
    blocks={state:text[start:(positions[i+1][1] if i+1<len(positions) else end)]
            for i,(state,start) in enumerate(positions)}
    return text[:p7],text[p7:pp],text[pp:header_end],blocks,text[end:]


def _set_identities():
    return '\n'.join(['allsel,all','set,last','*get,wrns,active,0,set,nset',
      '*cfopen,set_identity,txt','*do,wri,1,wrns','set,,,,,,,wri',
      '*get,wrls,active,0,set,lstp','*get,wrss,active,0,set,sbst',
      '*get,wrtm,active,0,set,time','*vwrite,wri,wrls,wrss,wrtm',
      '(4(E24.16,1X))','*enddo','*cfclos','allsel,all'])+'\n'


def _metadata(mode,text,core):
    return {'warm_version':VERSION,'mode':mode,'input_sha256':hashlib.sha256(text.encode('ascii')).hexdigest(),
      'core_metadata':core,'core_source_sha256':sha(CORE),'warm_source_sha256':sha(__file__),
      'solver_executable':str(EXE),'solver_executable_sha256':sha(EXE),'solver_release':'2026 R1 / 261',
      'solver_cores':4,'jobname':'solve','official_v261_sources':OFFICIAL,
      'formal_restart_enabled':False,'restart_equivalence_passed':False,'solver_started':False,
      'retention':'All preparation, source files, inputs, logs and outputs remain; this prototype performs no cleanup.',
      'parameter_precision':'PARSAV/PARRES may truncate decimals. Restore with PARRES NEW, export restored values, then reassert only SUPUY/PUNUY from the original 17-digit touch output as explicit numeric literals; the material/contact restart state is not reconstructed from these scalars.'}


def build_base(config=None):
    cfg={**(config or {}),'stroke_mm':0.,'save_full_strain_trajectory':True}
    full,core=_core(cfg)
    physical,_,post_header,blocks,footer=_parts(full,core)
    if physical.count('time,1\n')!=1:
        raise ValueError('Cannot insert controls before the first core solution.')
    physical=physical.replace('time,1\n','rescontrol,define,all,last,0\ntime,1\n',1)
    checkpoint='\n'.join(['parsav,all,c0_parameters,parm',
      '*cfopen,c0_parameters_original,txt','*vwrite,supcy,puncy,supuy,punuy,supn,punn',
      '(6(E24.16,1X))','*cfclos','/output,restart_file_summary,txt',
      'rescontrol,file_summary','/output'])+'\n'
    text=physical+checkpoint+post_header+_set_identities()+''.join(blocks[k] for k in ('A','B','C0'))+footer
    meta=_metadata('base',text,core)
    meta['expected_files']=[p for p in core['expected_files'] if not p.startswith(('state_C_','state_D_'))]
    meta['expected_files']+=['solve.rdb','solve.ldhi','c0_parameters.parm','c0_parameters_original.txt','restart_file_summary.txt','set_identity.txt']
    meta['physical_prefix_sha256']=hashlib.sha256(_parts(full,core)[0].encode('ascii')).hexdigest()
    meta['base_state_stages']={'A':1,'B':5,'C0':6}
    meta['actual_restart_frame_status']='Awaiting actual FILE_SUMMARY and SET identities; no r001 assumption.'
    return text,meta


def _save_preparation(folder,text,meta):
    folder=_folder(folder)
    if folder.exists():
        raise FileExistsError('Existing preparation/results are preserved; use a new name.')
    folder.mkdir(parents=True)
    (folder/'input.inp').write_bytes(text.encode('ascii'))
    write_json(folder/'warm_metadata.json',meta)
    return folder,meta


def prepare_base(name='BASE_C0_RECT004_V001',config=None,output_parent=None):
    parent=_folder(output_parent) if output_parent else ROOT/'warm'
    return _save_preparation(parent/_name(name),*build_base(config))


def parse_file_summary(path):
    """Recognize explicit file-name or file-number columns; never guess r001.

    Unknown actual output layouts deliberately stop preparation for inspection.
    The software fixtures check parser behavior, not the actual Ansys layout.
    """
    records=[]; header=False
    number=r'[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[EDed][+-]?\d+)?'
    for no,line in enumerate(Path(path).read_text(encoding='ascii',errors='replace').splitlines(),1):
        if re.search(r'FILE.*LOAD\s*STEP.*SUB\s*STEP',line,re.I):
            header=True; continue
        if not header:
            continue
        words=line.strip().split()
        if not words:
            continue
        named=re.fullmatch(r'(?:.*[\\/])?(solve\.r\d{3})',words[0],re.I)
        indexed=re.fullmatch(r'\d{1,3}',words[0])
        if named:
            filename=named[1].lower()
        elif indexed:
            filename=f'solve.r{int(words[0]):03d}'
        else:
            continue
        if not 1<=int(filename[-3:])<=999:
            raise ValueError('Actual restart file number lies outside 1..999.')
        if len(words) not in (3,4) or not all(re.fullmatch(number,w) for w in words[1:]):
            continue
        ls,ss=map(float,words[1:3])
        if ls!=int(ls) or ss!=int(ss) or ls<1 or ss<1:
            raise ValueError('Noninteger/invalid actual FILE_SUMMARY identity.')
        records.append({'filename':filename,'load_step':int(ls),'substep':int(ss),
          'time':float(words[3].replace('D','E').replace('d','e')) if len(words)==4 else None,
          'original_line_1based':no,'original_line':line})
    if not records or len({r['filename'] for r in records})!=len(records):
        raise ValueError('Actual FILE_SUMMARY table is unrecognized/ambiguous. Preserve its original text and inspect; never assume r001.')
    return records


def _identities(folder,max_step):
    table=rect_model._load(folder/'set_identity.txt',4)
    if not np.equal(table[:,:3],np.round(table[:,:3])).all():
        raise ValueError('Noninteger actual SET identity.')
    if not np.array_equal(table[:,0],np.arange(1,len(table)+1)) or set(table[:,1].astype(int))!=set(range(1,max_step+1)):
        raise ValueError('Actual result SET history is missing or relabeled.')
    if np.any(np.diff(table[:,3])<=0) or not np.all(np.isfinite(table)):
        raise ValueError('Actual SET times must increase strictly.')
    for ls in range(1,max_step+1):
        rows=table[table[:,1]==ls]
        if len(set(rows[:,2]))!=len(rows) or np.any(np.diff(rows[:,2])<=0) or abs(rows[-1,3]-ls)>1e-10:
            raise ValueError('Actual load-step endpoint/substep identity mismatch.')
    history=rect_model._load(folder/'history.txt',8,len(table))
    if not np.allclose(history[:,[0,1,2]],table[:,[0,1,3]],rtol=0,atol=1e-10):
        raise ValueError('Core reaction history and actual SET identity differ.')
    strain=rect_model._load(folder/'strain_history.txt',5,len(table))
    if not np.allclose(strain[:,:3],history[:,:3],rtol=0,atol=1e-10) or not rect_model._listing_available(folder/'strain_history_log.txt'):
        raise ValueError('Full path strain checkpoint coverage is unavailable or differs from actual SETs.')
    return table,history,strain


def _read_preparation(folder):
    folder=_folder(folder)
    meta=json.loads((folder/'warm_metadata.json').read_text(encoding='utf-8'))
    if sha(folder/'input.inp')!=meta['input_sha256'] or sha(CORE)!=meta['core_source_sha256'] or sha(__file__)!=meta['warm_source_sha256']:
        raise ValueError('Prepared input/model/postprocessor changed; use an explicitly reviewed new preparation/reanalysis.')
    if str(EXE)!=meta['solver_executable'] or sha(EXE)!=meta['solver_executable_sha256']:
        raise ValueError('Solver executable differs from the prepared same-version identity.')
    return folder,meta


def _solver_complete(folder,meta):
    status=json.loads((folder/'solver_status.json').read_text(encoding='utf-8'))
    if status.get('software_mock') or status.get('accepted_exit') is not True or status['input_sha256']!=meta['input_sha256']:
        raise RuntimeError('Actual solver completion is not accepted; mocks are not actual FE.')
    if status['cores']!=meta['solver_cores']:
        raise ValueError('Baseline/branch core count differs.')
    if not re.search(r'RELEASE\s+2026\s+R1', (folder/'solve.out').read_text(encoding='ascii',errors='replace')[:5000],re.I):
        raise ValueError('Actual output does not identify the required 2026 R1 release.')
    return status


def _hashes(folder):
    return {p.name:{'size_bytes':p.stat().st_size,'sha256':sha(p)}
            for p in folder.iterdir() if p.is_file() and p.name!='base_restart_receipt.json'}


def _verify_hashes(folder,manifest):
    for name,entry in manifest.items():
        path=folder/name
        if not path.is_file() or path.stat().st_size!=entry['size_bytes'] or sha(path)!=entry['sha256']:
            raise ValueError('Immutable base/source changed: '+str(path))


def parse_base(folder):
    folder,meta=_read_preparation(folder)
    if meta['mode']!='base':
        raise ValueError('Expected a prepared C0 base, not another branch.')
    receipt_path=folder/'base_restart_receipt.json'
    if receipt_path.exists():
        receipt=json.loads(receipt_path.read_text(encoding='utf-8'))
        if receipt.get('actual_FE') is not True or receipt['input_sha256']!=meta['input_sha256']:
            raise ValueError('Existing base receipt is not actual FE for this input.')
        _verify_hashes(folder,receipt['immutable_source_files'])
        return receipt
    status=_solver_complete(folder,meta)
    table,history,strain=_identities(folder,6)
    end=table[-1]
    candidates=[row for row in parse_file_summary(folder/'restart_file_summary.txt')
       if row['load_step']==int(end[1]) and row['substep']==int(end[2]) and (row['time'] is None or abs(row['time']-end[3])<=1e-10)]
    if len(candidates)!=1:
        raise ValueError('FILE_SUMMARY does not identify exactly the actual last C0 SET.')
    frame=candidates[0]
    files=['solve.rdb','solve.ldhi',frame['filename'],'c0_parameters.parm','solve.rst','touch_geometry.txt']
    if any(not (folder/name).is_file() or (folder/name).stat().st_size==0 for name in files):
        raise ValueError('Actual complete solver restart inputs are missing.')
    params=rect_model._load(folder/'c0_parameters_original.txt',6,1)[0]
    touch=rect_model._load(folder/'touch_geometry.txt',6,1)[0]
    if not np.allclose(params,touch,rtol=0,atol=1e-12) or min(params[4:])<1:
        raise ValueError('Saved C0 touch scalars differ from original physical touch output.')
    core=meta['core_metadata']; ids,bytool=rect_model._contact_identities(folder,core)
    states={}
    for state in ('A','B','C0'):
        element=rect_model._load(folder/f'state_{state}_element_extrema.txt',4,core['mesh_count']['solid_elements'])
        u=rect_model._load(folder/f'state_{state}_nodes.txt',3,core['mesh_count']['work_nodes'])
        fields={key:rect_model._presol_records(folder/f'state_{state}_{suffix}.txt',columns)
                for key,suffix,columns in [('p','p',('EPEQ',)),('ex','ex',('EX','EPTOX')),('sx','sx',('SX',))]}
        if not all(rect_model._ip_coverage(f,core) for f in fields.values()):
            raise ValueError('Base actual copied-IP identity coverage is incomplete: '+state)
        if max(abs(max(fields['p'].values())-element[:,0].max()),abs(min(fields['p'].values())-element[:,1].min()),
               abs(max(fields['ex'].values())-element[:,2].max()),abs(min(fields['ex'].values())-element[:,3].min()))>1e-10:
            raise ValueError('Base raw extrema do not verify ETABLE output: '+state)
        pen=rect_model._presol_records(folder/f'state_{state}_penetration.txt',('PENE',))
        pressure=rect_model._presol_records(folder/f'state_{state}_pressure.txt',('PRES',))
        contacts,complete=rect_model._contact_state(folder,state,core,u,ids,bytool,pen,pressure)
        axis,_=rect_model._centroid_axis(u,core)
        states[state]={'copied_IP_coverage_verified':True,'raw_extrema_crosscheck_verified':True,
          'fixed260_error_mm':rect_model._chord_error(axis,np.asarray(core['x_mm']),130.),
          'contact_by_tool':contacts,'raw_contact_coverage_complete':complete,
          'max_p':max(fields['p'].values()),'max_abs_EX':max(abs(x) for x in fields['ex'].values())}
    receipt={'warm_version':VERSION,'actual_FE':True,'input_sha256':meta['input_sha256'],'solver_seconds':status['seconds'],
      'core_source_sha256':meta['core_source_sha256'],'warm_source_sha256':meta['warm_source_sha256'],
      'actual_C0_SET':{'set_number':int(end[0]),'load_step':int(end[1]),'substep':int(end[2]),'time':float(end[3])},
      'actual_FILE_SUMMARY_frame':frame,'restart_input_names':files,'touch_parameters_original':params.tolist(),
      'states':states,'history_rows':len(history),'max_path_abs_axial_total_strain':float(np.max(abs(strain[:,3:]))),
      'immutable_source_files':_hashes(folder),'restart_equivalence_passed':False,'formal_restart_enabled':False,
      'full_internal_history_basis':'Actual rdb/ldhi/rnnn restart identity, not node/stress/strain reconstruction.'}
    write_json(receipt_path,receipt)
    return receipt


def prepare_branch(base_folder,stroke_mm,name=None,output_parent=None):
    base,base_meta=_read_preparation(base_folder)
    verified=parse_base(base)
    stroke=float(stroke_mm)
    if not math.isfinite(stroke) or stroke<0:
        raise ValueError('Stroke must be finite and nonnegative.')
    cfg={**base_meta['core_metadata']['config'],'stroke_mm':stroke}
    full,core=_core(cfg)
    physical,continuation,post_header,blocks,footer=_parts(full,core)
    if hashlib.sha256(physical.encode('ascii')).hexdigest()!=base_meta['physical_prefix_sha256']:
        raise ValueError('Candidate is not the same immutable physical history through C0.')
    frame=verified['actual_C0_SET']
    supuy,punuy=verified['touch_parameters_original'][2:4]
    cp=core['tools']['punch']['pilot_node']; cs=core['tools']['support']['pilot_node']
    restored='\n'.join(['/batch','/filname,solve','/solu',
      f"antype,,restart,{frame['load_step']},{frame['substep']},continue",'parres,new,c0_parameters,parm',
      'wrsold=supuy','wrpold=punuy',f'supuy={_number(supuy)}',f'punuy={_number(punuy)}',
      '*cfopen,restored_parameters,txt','*vwrite,wrsold,wrpold,supuy,punuy','(4(E24.16,1X))','*cfclos',
      'autots,on','nropt,unsym','neqit,75','cnvtol,f,,0.001,2,1','cnvtol,m,,0.001,2,1','kbc,0',
      'outres,all,last','outres,nsol,all','outres,rsol,all','outres,epel,all,workel','outres,eppl,all,workel'])+'\n'
    # Preserve the copied RST's initial A/B/C0, then append the actual branch C/D.
    text=restored+continuation+post_header+_set_identities()+''.join(blocks.values())+footer
    meta=_metadata('branch',text,core)
    meta.update(base_folder=str(base),base_input_sha256=base_meta['input_sha256'],
      actual_restart_identity=frame,actual_FILE_SUMMARY_frame=verified['actual_FILE_SUMMARY_frame'],
      original_touch_parameters=verified['touch_parameters_original'],
      expected_files=core['expected_files']+['set_identity.txt','restored_parameters.txt'],
      source_base_snapshot=verified['immutable_source_files'],
      copied_files_use='Writable same-job computational inputs for a new independent branch; no archive/backup/hard link.',
      RST_history='Initial actual base RST copied as writable computational input; real restart must preserve LS1..6 and append LS7..11. Actual SET identities and base field/curve equality are mandatory after solve.')
    if base_meta.get('software_mock') or verified.get('software_mock'):
        meta['software_mock']=True
    # Include the immutable receipt itself in the before/after source check.
    meta['source_base_snapshot']={**meta['source_base_snapshot'],
      'base_restart_receipt.json':{'size_bytes':(base/'base_restart_receipt.json').stat().st_size,'sha256':sha(base/'base_restart_receipt.json')}}
    parent=_folder(output_parent) if output_parent else base.parent/'branches'
    folder=parent/_name(name or f'BRANCH_S{stroke:.6f}_{meta["input_sha256"][:12]}')
    if folder.exists():
        raise FileExistsError('Existing branch preserved; use a new name.')
    folder.mkdir(parents=True)
    copies=[]
    _verify_hashes(base,meta['source_base_snapshot'])
    for filename in verified['restart_input_names']:
        source=base/filename; destination=folder/filename
        before=sha(source)
        shutil.copyfile(source,destination)
        if sha(source)!=before or sha(destination)!=before or source.stat().st_ino==destination.stat().st_ino:
            raise ValueError('Computational copy changed its source or is a shared file: '+filename)
        copies.append({'filename':filename,'source':str(source),'source_sha256':before,
                       'destination':str(destination),'destination_initial_sha256':sha(destination),
                       'size_bytes':destination.stat().st_size,'role':'writable computational restart input'})
    _verify_hashes(base,meta['source_base_snapshot'])
    meta['computational_copies']=copies
    meta['source_unchanged_after_preparation']=True
    (folder/'input.inp').write_bytes(text.encode('ascii'))
    write_json(folder/'warm_metadata.json',meta)
    return folder,meta


def parse_branch(folder):
    folder,meta=_read_preparation(folder)
    if meta['mode']!='branch':
        raise ValueError('Expected an independent prepared branch.')
    _solver_complete(folder,meta)
    base=_folder(meta['base_folder'])
    _verify_hashes(base,meta['source_base_snapshot'])
    table,history,_=_identities(folder,11)
    bt,bh,bs=_identities(base,6)
    initial=table[table[:,1]<=6]
    if not np.array_equal(initial,bt) or not np.allclose(history[table[:,1]<=6],bh,rtol=0,atol=1e-10):
        raise ValueError('Branch RST did not retain the actual immutable initial SET/history.')
    branch_strain=rect_model._load(folder/'strain_history.txt',5)
    if not np.allclose(branch_strain[table[:,1]<=6],bs,rtol=0,atol=1e-10):
        raise ValueError('Branch initial strain trajectory differs from the actual base.')
    pars=rect_model._load(folder/'restored_parameters.txt',4,1)[0]
    original=np.asarray(meta['original_touch_parameters'][2:4])
    if np.max(abs(pars[:2]-original))>1e-7 or not np.allclose(pars[2:],original,rtol=0,atol=1e-12):
        raise ValueError('Restored/reasserted APDL touch parameters are not safe.')
    field_diffs={}
    for state in ('A','B','C0'):
        differences={}
        for suffix,cols,rows in [('nodes',3,meta['core_metadata']['mesh_count']['work_nodes']),
                                 ('element_extrema',4,meta['core_metadata']['mesh_count']['solid_elements'])]:
            a=rect_model._load(folder/f'state_{state}_{suffix}.txt',cols,rows)
            b=rect_model._load(base/f'state_{state}_{suffix}.txt',cols,rows)
            differences[suffix]=float(np.max(abs(a-b)))
            if differences[suffix]>1e-10:
                raise ValueError('Immutable base field in combined branch RST changed: '+state+'/'+suffix)
        for suffix,cols in [('p',('EPEQ',)),('ex',('EX','EPTOX')),('sx',('SX',))]:
            a=rect_model._presol_records(folder/f'state_{state}_{suffix}.txt',cols)
            b=rect_model._presol_records(base/f'state_{state}_{suffix}.txt',cols)
            if a.keys()!=b.keys():raise ValueError('Initial copied-IP identities differ.')
            differences[suffix]=max(abs(a[k]-b[k]) for k in a)
            if differences[suffix]>1e-10:raise ValueError('Initial copied-IP material field changed.')
        field_diffs[state]=differences
    metrics=rect_model.parse(folder,meta['core_metadata'])
    receipt={'warm_version':VERSION,'actual_FE':True,'input_sha256':meta['input_sha256'],
      'base_input_sha256':meta['base_input_sha256'],'actual_restart_identity':meta['actual_restart_identity'],
      'actual_combined_SET_coverage_verified':True,'actual_initial_fields_verified':field_diffs,
      'source_base_unchanged_after_branch':True,'metrics':metrics,'restart_equivalence_passed':False,
      'formal_restart_enabled':False,'remaining_gate':'Actual independent s=0 and s=12 cold/warm comparisons, declared numerical budgets and measured timing before any protocol unlock.'}
    write_json(folder/'branch_restart_receipt.json',receipt)
    return receipt


def parse(folder):
    folder,meta=_read_preparation(folder)
    return parse_base(folder) if meta['mode']=='base' else parse_branch(folder)


def compare_cold_warm(cold_folder,warm_folder,budgets=None):
    """Actual fixed-candidate comparison; it never grants formal release.

    Default comparison budgets are prototype targets and remain explicitly
    separate from a later frozen protocol gate or a resolved stroke search.
    """
    cold=_folder(cold_folder);warm,meta=_read_preparation(warm_folder)
    if meta['mode']!='branch':raise ValueError('Need an actual independent warm branch.')
    warm_receipt=parse_branch(warm)
    cold_meta=json.loads((cold/'model_metadata.json').read_text(encoding='utf-8'))
    status=json.loads((cold/'solver_status.json').read_text(encoding='utf-8'))
    if status.get('accepted_exit') is not True or status.get('software_mock') or status['input_sha256']!=sha(cold/'input.inp'):
        raise RuntimeError('Cold solver/input completion is not actual accepted FE.')
    if cold_meta['config']!=meta['core_metadata']['config'] or cold_meta['material_sha256']!=meta['core_metadata']['material_sha256']:
        raise ValueError('Cold/warm physical inputs differ.')
    expected,_=_core(cold_meta['config'])
    actual=(cold/'input.inp').read_text(encoding='ascii')
    if actual.split('finish\n/post1\n',1)[0]!=expected.split('finish\n/post1\n',1)[0]:
        raise ValueError('Actual cold physical solution path differs from the frozen core path.')
    if not re.search(r'RELEASE\s+2026\s+R1',(cold/'solve.out').read_text(encoding='ascii',errors='replace')[:5000],re.I):
        raise ValueError('Cold output release differs.')
    targets={'nodal_mm':1e-6,'plastic_abs':1e-8,'axial_abs':1e-8,'stress_MPa':.01,
             'reaction_N':.1,'objective_mm':1e-5,'path_axial_abs':1e-8,**(budgets or {})}
    if any(not math.isfinite(float(v)) or float(v)<=0 for v in targets.values()):
        raise ValueError('Comparison budgets must be positive finite numbers.')
    core=meta['core_metadata'];differences={};passed=True
    for state in core['state_stages']:
        nodes=[];part={}
        for folder in (cold,warm):nodes.append(rect_model._load(folder/f'state_{state}_nodes.txt',3,core['mesh_count']['work_nodes']))
        part['nodal_mm']=float(np.max(abs(nodes[0]-nodes[1])))
        for key,suffix,columns in [('plastic_abs','p',('EPEQ',)),('axial_abs','ex',('EX','EPTOX')),('stress_MPa','sx',('SX',))]:
            aa=rect_model._presol_records(cold/f'state_{state}_{suffix}.txt',columns)
            bb=rect_model._presol_records(warm/f'state_{state}_{suffix}.txt',columns)
            if aa.keys()!=bb.keys() or not rect_model._ip_coverage(aa,core):raise ValueError('Cold/warm actual copied-IP identities are incomplete.')
            part[key]=max(abs(aa[k]-bb[k]) for k in aa)
        a=rect_model._load(cold/f'state_{state}_tool_vectors.txt',8,4)
        b=rect_model._load(warm/f'state_{state}_tool_vectors.txt',8,4)
        if not np.array_equal(a[:,0],b[:,0]):raise ValueError('Tool pilot identities differ.')
        part['reaction_N']=float(4*np.max(abs(a[:,2:5]-b[:,2:5])))
        axes=[rect_model._centroid_axis(u,core)[0] for u in nodes]
        part['objective_mm']=abs(rect_model._chord_error(axes[0],np.asarray(core['x_mm']),130.)-rect_model._chord_error(axes[1],np.asarray(core['x_mm']),130.))
        part['within_proposed_budgets']=all(value<=targets[key] for key,value in part.items())
        passed=passed and part['within_proposed_budgets'];differences[state]=part
    h=[rect_model._load(f/'history.txt',8) for f in (cold,warm)]
    st=[rect_model._load(f/'strain_history.txt',5) for f in (cold,warm)]
    if h[0].shape!=h[1].shape or not np.allclose(h[0][:,:3],h[1][:,:3],rtol=0,atol=1e-10):
        raise ValueError('Cold/warm actual converged substep schedules differ; no interpolation hides it.')
    if any(a.shape[0]!=len(h[i]) or not np.allclose(a[:,:3],h[i][:,:3],rtol=0,atol=1e-10) for i,a in enumerate(st)):
        raise ValueError('Cold/warm full-path strain coverage differs.')
    reaction=float(4*np.max(abs(h[0][:,[4,5,7]]-h[1][:,[4,5,7]])))
    strain=float(np.max(abs(st[0][:,3:]-st[1][:,3:])))
    passed=passed and reaction<=targets['reaction_N'] and strain<=targets['path_axial_abs']
    result={'warm_version':VERSION,'actual_fixed_stroke_mm':core['config']['stroke_mm'],
      'cold_folder':str(cold),'warm_folder':str(warm),'cold_input_sha256':status['input_sha256'],'warm_input_sha256':meta['input_sha256'],
      'budgets_status':'Proposed prototype targets; no formal protocol gate is granted here.','budgets':targets,
      'state_differences':differences,'actual_substep_schedule_matches':True,'max_curve_reaction_difference_N':reaction,
      'max_path_axial_extrema_difference':strain,'actual_fixed_candidate_comparison_passed':bool(passed),
      'cold_seconds':status['seconds'],'warm_seconds':json.loads((warm/'solver_status.json').read_text())['seconds'],
      'base_seconds':parse_base(meta['base_folder'])['solver_seconds'],'full_two_candidate_gate':'Needs separately verified s=0 and s=12 pairs; this is one pair.',
      'resolved_stroke_label_validated':False,'formal_restart_enabled':False,'restart_equivalence_passed':False}
    write_json(warm/'cold_warm_comparison.json',result)
    return result


def run(folder,timeout=2400):
    """Only the root should invoke this explicit solver action after review."""
    folder,meta=_read_preparation(folder)
    if meta.get('software_mock'):
        raise RuntimeError('Software fixture cannot launch Ansys.')
    prior=folder/'solver_status.json'
    if prior.exists():
        status=json.loads(prior.read_text(encoding='utf-8'))
        if status.get('accepted_exit') is True and status['input_sha256']==meta['input_sha256']:
            return parse(folder)
        raise RuntimeError('Prior failed attempt is preserved; prepare a new independent attempt.')
    if meta['mode']=='branch':
        base=_folder(meta['base_folder']);_verify_hashes(base,meta['source_base_snapshot'])
        for copied in meta['computational_copies']:
            if sha(folder/copied['filename'])!=copied['destination_initial_sha256']:
                raise ValueError('A prepared branch computational input changed before its first solve.')
    try:
        status=run_solver(folder,(folder/'input.inp').read_text(encoding='ascii'),meta['expected_files'],
                          timeout=timeout,cores=meta['solver_cores'])
    finally:
        if meta['mode']=='branch':_verify_hashes(base,meta['source_base_snapshot'])
    return parse(folder) if status.get('accepted_exit') else {'actual_FE':False,'solver_status':status,'formal_restart_enabled':False}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action',choices=('prepare-base','prepare-branch','run','parse','compare'))
    parser.add_argument('--folder',type=Path);parser.add_argument('--base',type=Path)
    parser.add_argument('--name');parser.add_argument('--config',type=Path)
    parser.add_argument('--stroke',type=float);parser.add_argument('--timeout',type=float,default=2400)
    parser.add_argument('--cold',type=Path)
    args=parser.parse_args()
    if args.action=='prepare-base':
        cfg=json.loads(args.config.read_text(encoding='utf-8-sig')) if args.config else None
        folder,meta=prepare_base(args.name or 'BASE_C0_RECT004_V001',cfg)
        output={'action':'prepared_base_only','folder':str(folder),'input_sha256':meta['input_sha256'],'solver_started':False}
    elif args.action=='prepare-branch':
        if args.base is None or args.stroke is None:parser.error('prepare-branch needs --base and --stroke')
        folder,meta=prepare_branch(args.base,args.stroke,args.name)
        output={'action':'prepared_independent_branch_only','folder':str(folder),'input_sha256':meta['input_sha256'],'solver_started':False}
    else:
        if args.folder is None:parser.error('run/parse needs --folder')
        if args.action=='compare':
            if args.cold is None:parser.error('compare needs --cold and --folder (warm branch)')
            output=compare_cold_warm(args.cold,args.folder)
        else:output=run(args.folder,args.timeout) if args.action=='run' else parse(args.folder)
    print(json.dumps(output,ensure_ascii=False,indent=2))


if __name__=='__main__':main()
