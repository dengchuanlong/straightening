"""Read-only review policy for unchanged V003 native automatic U controls.

Numeric inputs/lineage are delegated unchanged. Automatic-reference equality is
a diagnostic; identical actual table settings, complete actual evidence, the
unchanged 1e-7mm ceiling, support precision and original physical gates remain
mandatory. No solve, preparation, source mutation or qualification on import.
"""
from pathlib import Path
import hashlib
import math

import restart_boundary_control_v003 as numeric

VERSION = numeric.VERSION
POLICY_VERSION = 'RESTART_AUTO_REFERENCE_REVIEW_V004'
CONTROL = numeric.CONTROL
STAGES = numeric.controls.STAGES
MAX_U_CRITERION_MM = numeric.controls.MAX_U_CRITERION_MM
SUPPORT_PRECISION_MM = numeric.SUPPORT_PRECISION_MM
FROZEN_NUMERICAL_SOURCE_SHA256 = 'fdbf8bfb2887b4cd0e3800c2b0e2f5613c9bfc032429547169ac2759716b7023'
EXPECTED_U_TABLE = {'reference': 0., 'tolerance': 1e-9, 'norm': 0, 'minref': 1.}
OFFICIAL_SOURCES = [
    'https://ansyshelp.ansys.com/public/Views/Secured/corp/v261/en/ans_cmd/Hlp_C_CNVTOL.html',
    'https://ansyshelp.ansys.com/public/Views/Secured/corp/v261/en/ans_thry/thy_tool10.html',
    'https://ansyshelp.ansys.com/public/Views/Secured/corp/v261/en/ans_bas/Hlp_G_BAS3_12.html',
]


def _sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _guard():
    if _sha(numeric.__file__) != FROZEN_NUMERICAL_SOURCE_SHA256:
        raise RuntimeError('Original V003 numerical transformer/auditor changed.')
    numeric._guard_v002()


def _finite(value):
    return type(value) in (int, float) and math.isfinite(value)


def derive_input(original, kind):
    """Exactly the V003 text/lineage; this policy is not a new numeric variant."""
    _guard()
    text, lineage = numeric.derive_input(original, kind)
    _guard()
    return text, lineage


def audit_log(folder_orpath):
    """Read actual native table/iterations/fields using unchanged V003 audit."""
    _guard()
    result = numeric.audit_log(folder_orpath)
    _guard()
    result['audit_policy_version'] = POLICY_VERSION
    result['policy_source_sha256'] = _sha(__file__)
    result['numeric_variant_unchanged'] = True
    return result


def _table_valid(table):
    return (isinstance(table, dict) and type(table.get('norm')) is int
            and all(_finite(table.get(k)) and table[k] == v for k, v in EXPECTED_U_TABLE.items()))


def _audit_checks(audit):
    """Pure checks of actual audit data; mock copies are only software fixtures."""
    stages = audit.get('stages', {})
    rows = audit.get('substeps', [])
    complete = (isinstance(stages, dict) and set(stages) == {str(s) for s in STAGES}
                and isinstance(rows, list) and bool(rows))
    ids, criteria, table_ok = [], [], complete
    iteration_ok = complete
    for row in rows:
        ls, ss, tm = (row.get(k) for k in ('load_step', 'substep', 'time'))
        valid = (type(ls) is int and ls in STAGES and type(ss) is int and ss > 0
                 and _finite(tm) and tm >= 0
                 and type(row.get('iteration_U_rows')) is int and row['iteration_U_rows'] > 0
                 and _finite(row.get('last_U_iteration_value_mm')) and row['last_U_iteration_value_mm'] >= 0)
        values = row.get('criterion_values_mm', [])
        valid = valid and isinstance(values, list) and bool(values) and all(_finite(v) and v > 0 for v in values)
        iteration_ok = iteration_ok and valid
        if valid:
            ids.append((ls, ss))
            criteria.extend(values)
    complete = complete and iteration_ok and len(ids) == len(rows) and ids == sorted(set(ids))
    for stage in STAGES:
        item = stages.get(str(stage), {})
        selected = [row for row in rows if row.get('load_step') == stage]
        tables = item.get('actual_solver_tables', [])
        table_ok = table_ok and isinstance(tables, list) and bool(tables) and all(_table_valid(t) for t in tables)
        complete = (complete and bool(selected) and [r.get('substep') for r in selected] == list(range(1,len(selected)+1))
                    and type(item.get('completed_substeps')) is int and item['completed_substeps'] == len(selected)
                    and item.get('complete_actual_iteration_evidence') is True)
    actual_ceiling = bool(criteria) and all(v <= MAX_U_CRITERION_MM for v in criteria)
    support = audit.get('support_precision', {})
    a, b = support.get('actual_C_support_UY_mm'), support.get('expected_full_precision_support_UY_mm')
    precision = (support.get('passed') is True and _finite(a) and _finite(b)
                 and type(support.get('support_pilot_node')) is int and support['support_pilot_node'] > 0
                 and support.get('max_allowed_support_error_mm') == SUPPORT_PRECISION_MM
                 and abs(a-b) <= SUPPORT_PRECISION_MM)
    metadata = (audit.get('passed') is True and audit.get('control_audit_passed') is True
                and audit.get('actual_controls_verified') is True and audit.get('support_precision_verified') is True
                and audit.get('official_v261_header_seen') is True
                and audit.get('actual_control_tables_and_iteration_rows_used') is True
                and audit.get('input_ACK_used_as_control_evidence') is False
                and audit.get('parse_or_solver_error_evidence') == []
                and audit.get('expected_table_U') == EXPECTED_U_TABLE
                and audit.get('max_allowed_printed_U_criterion_mm') == MAX_U_CRITERION_MM)
    return dict(actual_table_matches_expected=bool(table_ok), complete_actual_substep_iteration_evidence=bool(complete),
                all_actual_U_criteria_within_unchanged_ceiling=bool(actual_ceiling),
                actual_support_precision_verified=bool(precision), unchanged_numeric_audit_passed=bool(metadata))


def _compare_audits(cold, warm, physical_pass=False):
    if type(physical_pass) is not bool:
        raise ValueError('Original physical comparison pass must be an explicit bool, not a truthy claim.')
    checks_cold, checks_warm = _audit_checks(cold), _audit_checks(warm)
    a, b = cold.get('substeps', []), warm.get('substeps', [])
    schedule = (len(a) == len(b) and bool(a)
                and all(x.get('load_step') == y.get('load_step') and x.get('substep') == y.get('substep')
                        and _finite(x.get('time')) and _finite(y.get('time')) and abs(x['time']-y['time']) <= 1e-10
                        for x,y in zip(a,b)))
    exact = schedule and all(x.get('criterion_values_mm') == y.get('criterion_values_mm') for x,y in zip(a,b))
    differences = [dict(load_step=x.get('load_step'),substep=x.get('substep'),time=x.get('time'),
                       cold_criterion_values_mm=x.get('criterion_values_mm'),warm_criterion_values_mm=y.get('criterion_values_mm'),
                       cold_last_U_iteration_value_mm=x.get('last_U_iteration_value_mm'),
                       warm_last_U_iteration_value_mm=y.get('last_U_iteration_value_mm'))
                   for x,y in zip(a,b) if x.get('criterion_values_mm') != y.get('criterion_values_mm')]
    ca, wa = cold.get('support_precision', {}), warm.get('support_precision', {})
    support_ready = checks_cold['actual_support_precision_verified'] and checks_warm['actual_support_precision_verified']
    target_delta = abs(ca['expected_full_precision_support_UY_mm']-wa['expected_full_precision_support_UY_mm']) if support_ready else None
    actual_delta = abs(ca['actual_C_support_UY_mm']-wa['actual_C_support_UY_mm']) if support_ready else None
    pair_precision = bool(support_ready and ca['support_pilot_node'] == wa['support_pilot_node']
                          and target_delta <= SUPPORT_PRECISION_MM and actual_delta <= SUPPORT_PRECISION_MM)
    controls_pass = all(checks_cold.values()) and all(checks_warm.values()) and schedule and pair_precision
    return dict(version=VERSION,policy_version=POLICY_VERSION,policy_source_sha256=_sha(__file__),
                numeric_source_sha256=FROZEN_NUMERICAL_SOURCE_SHA256,numeric_variant_unchanged=True,
                cold_audit=cold,warm_audit=warm,cold_hard_checks=checks_cold,warm_hard_checks=checks_warm,
                actual_completed_substep_schedule_matches=bool(schedule),
                same_actual_U_table_parameters=checks_cold['actual_table_matches_expected'] and checks_warm['actual_table_matches_expected'],
                actual_printed_U_criteria_match_at_each_substep=bool(exact),
                exact_printed_criteria_equality_is_diagnostic_only=True,observed_criterion_differences=differences,
                support_precision_pair=dict(touch_target_difference_mm=target_delta,actual_C_support_difference_mm=actual_delta,
                                            budget_mm=SUPPORT_PRECISION_MM,passed=pair_precision),
                actual_controls_pair_verified=bool(controls_pass),
                actual_fixed_candidate_comparison_passed=physical_pass,
                original_material_field_force_shape_history_budgets_still_required=True,
                passed=bool(controls_pass and physical_pass),
                reference_mechanism_basis='Program-calculated reference is state/history dependent; exact internal restart initialization mechanism is not proven.',
                warm_meets_every_cold_criterion_not_asserted=True,
                qualified=False,formal_generation_unlocked=False,formal_restart_enabled=False,
                two_candidate_method_equivalence_granted=False,official_sources=OFFICIAL_SOURCES)


def compare_logs(cold_folder_orpath,warm_folder_orpath,fixed_candidate_comparison_passed=False):
    """Actual audits + unchanged physical pass supplied by the owner's reader.

    Default False prevents control evidence alone granting a candidate pair.
    Physical budgets and native input hashes are not changed by this policy.
    """
    if type(fixed_candidate_comparison_passed) is not bool:
        raise ValueError('Original physical comparison pass must be an explicit bool.')
    _guard()
    cold,warm = audit_log(cold_folder_orpath),audit_log(warm_folder_orpath)
    result = _compare_audits(cold,warm,fixed_candidate_comparison_passed)
    _guard()
    return result
