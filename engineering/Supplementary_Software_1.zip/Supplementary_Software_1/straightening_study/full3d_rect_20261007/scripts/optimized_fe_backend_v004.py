"""Explicit actual cold/restart FE callbacks for a diagnostic optimization pilot.

New attempts only. Existing scientific files stay unchanged. No cleanup,
archive, ML, formal qualification, or solve occurs on import/construction.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import math
import re
import time
import traceback

import rect_model
import warm_restart as warm
import warm_trial_v001 as producer
import warm_version_guard_adapter_v001 as adapter
import restart_boundary_control_v003 as control
from solver_runner import ROOT, run_solver
from search_cases import admissibility

VERSION = 'OPTIMIZED_ACTUAL_FE_BACKEND_V004'
MODES = ('cold_full_history', 'warm_multiframe_continuation')
PIN_NAMES = ('optimized_fe_backend_v004.py', 'optimized_fe_backend_v003.py', 'optimized_fe_backend_v002.py',
             'restart_auto_reference_policy_v004.py', 'run_restart_control_continuation_v003.py', 'rect_model.py', 'solver_runner.py',
             'warm_restart.py', 'warm_trial_v001.py', 'warm_version_guard_adapter_v001.py',
             'restart_control_v002.py', 'restart_boundary_control_v003.py', 'search_cases.py')


def sha(path):
    return warm.sha(path)


def read(path):
    return producer.read(path)


def write_new(path, value):
    producer.write_new(path, value)


def now():
    return datetime.now(timezone.utc).isoformat()


def candidate_name(stroke, input_sha256):
    """Pure safe directory identity; preserves the actual numeric stroke/input."""
    if type(stroke) not in (int, float):
        raise ValueError('Candidate stroke must be a finite nonnegative number, not bool.')
    try:
        finite = math.isfinite(stroke)
    except OverflowError as error:
        raise ValueError('Candidate stroke must be finite.') from error
    if not finite or stroke < 0 or stroke != round(stroke, 6):
        raise ValueError('Candidate stroke must be finite, nonnegative and canonical to six decimals.')
    if not isinstance(input_sha256, str) or re.fullmatch(r'[0-9a-f]{64}', input_sha256) is None:
        raise ValueError('Candidate identity requires its complete lowercase actual input SHA256.')
    token = f'S{float(stroke):.6f}'.replace('.', 'p') + '_' + input_sha256[:12]
    return warm._name(token)


class OptimizedFEBackend:
    def __init__(self, config, *, execution_mode, method_evidence, existing_base=None):
        if execution_mode not in MODES:
            raise ValueError('Explicit actual cold/restart execution mode required.')
        self.mode = execution_mode
        _, self.core = rect_model.build({**config, 'stroke_mm': 0., 'save_full_strain_trajectory': True})
        self.config = self.core['config']
        self.case_id = self.config['case_id']
        if not re.fullmatch(r'[A-Za-z0-9_-]{1,100}', self.case_id):
            raise ValueError('Fresh ASCII case identity required.')
        self.parent = ROOT / 'optimized_runs' / self.case_id
        self.base = Path(existing_base).resolve() if existing_base else self.parent / 'C0'
        self.sources = {str((ROOT / 'scripts' / n).resolve()): sha(ROOT / 'scripts' / n) for n in PIN_NAMES}
        self.sources[str(rect_model.MATERIAL.resolve())] = sha(rect_model.MATERIAL)
        self.method_evidence = []
        for path in method_evidence:
            p = Path(path).resolve()
            d = read(p)
            if (d.get('stage_id') != 'RESTART_CONTROL_CONTINUATION_V003' or d.get('finished') is not True
                    or d.get('audited_U_method_pairs_passed') is not True
                    or d.get('actual_zero_pair_passed') is not True or d.get('actual_12mm_pair_passed') is not True
                    or d.get('original_comparison_budgets_unchanged') is not True
                    or d.get('error') is not None or d.get('actual_FE_successful') != 2
                    or d.get('reused_FE_successful') != 2 or d.get('total_verified_FE_successful') != 4
                    or d.get('variant') != control.VERSION):
                raise ValueError('Actual0reuse plus actual12 two-pair method proof required; no inferred pass.')
            plan_path = ROOT / 'report/restart_control_continuation_preparation_v003.json'
            if Path(d.get('method_plan_path', '')).resolve() != plan_path.resolve() or sha(plan_path) != d.get('preparation_sha256'):
                raise ValueError('Actual continuation method plan binding differs.')
            plan = read(plan_path)
            self.sources[str(plan_path.resolve())] = d['preparation_sha256']
            for name in ('restart_control_v002.py', 'restart_boundary_control_v003.py', 'restart_auto_reference_policy_v004.py'):
                full = str((ROOT / 'scripts' / name).resolve())
                entry = plan['source_snapshot'].get(full)
                if not entry or entry.get('sha256') != self.sources[full]:
                    raise ValueError('Actual method control/audit source binding differs.')
            artifacts = d.get('verified_method_artifacts')
            if not isinstance(artifacts, dict) or not artifacts:
                raise ValueError('No immutable actual0/12 method evidence paths supplied.')
            for name, digest in artifacts.items():
                if sha(name) != digest:
                    raise ValueError('Actual continuation method artifact changed: ' + name)
                self.sources[str(Path(name).resolve())] = digest
            statuses = [ROOT/'restart_control_v002'/f'{kind}_S00'/'solver_status.json' for kind in ('cold','warm')]
            statuses += [ROOT/'restart_control_continuation_v003'/f'{kind}_S12'/'solver_status.json' for kind in ('cold','warm')]
            for status_path in statuses:
                if str(status_path.resolve()) not in self.sources:
                    raise ValueError('Missing an actual fixed-method solver status source.')
                actual_status = read(status_path)
                launch = producer.launch_evidence(actual_status)
                if launch.get('actual_launch_verified') is not True or launch.get('actual_solver_success_verified') is not True:
                    raise ValueError('Actual fixed-method native execution not proven.')
            self.method_evidence.append({'path': str(p), 'sha256': sha(p)})
        if not self.method_evidence:
            raise ValueError('No actual successful method evidence supplied.')
        self.base_receipt = None
        self.base_metadata = None
        self.started_UTC = now()
        self.base_wall_seconds = 0.
        self.base_solver_seconds = 0.

    def check_sources(self):
        for path, digest in self.sources.items():
            if sha(path) != digest:
                raise RuntimeError('Shared source changed: ' + path)
        for item in self.method_evidence:
            if sha(item['path']) != item['sha256']:
                raise RuntimeError('Actual method evidence changed.')
        if self.base_receipt is not None:
            # Actual full byte hashes are checked on initialization, before
            # each copied continuation by warm.prepare_branch, and after FE.
            # Lightweight checks here avoid hashing the same large RST when
            # the search merely compares already completed scalar results.
            for name, item in self.base_receipt['immutable_source_files'].items():
                p = self.base / name
                if not p.is_file() or p.stat().st_size != item['size_bytes']:
                    raise RuntimeError('Base immutable file is missing or has changed size.')
            if sha(self.base / 'base_restart_receipt.json') != self.base_receipt_sha:
                raise RuntimeError('Actual C0 receipt changed.')

    def ensure_base(self, timeout=7200):
        if self.mode == 'cold_full_history' or self.base_receipt is not None:
            return
        self.check_sources()
        started = time.monotonic()
        was_reused = self.base.exists()
        if was_reused:
            folder, meta, receipt, status = producer.inspect_base(self.base)
        else:
            folder, meta = warm.prepare_base('C0', self.config, self.parent)
            status = run_solver(folder, (folder / 'input.inp').read_text(encoding='ascii'),
                                meta['expected_files'], timeout=timeout, cores=4)
            receipt = adapter.parse_base_recovered(folder)
            write_new(folder / 'base_restart_receipt.json', receipt)
        cfg = meta['core_metadata']['config']
        if cfg != self.config:
            raise ValueError('C0 is not this exact same geometry, mesh, loading and source configuration.')
        warm._verify_hashes(folder, receipt['immutable_source_files'])
        if receipt.get('actual_FE') is not True or receipt['actual_C0_SET']['load_step'] != 6:
            raise ValueError('Actual complete C0 frame required.')
        self.base, self.base_metadata, self.base_receipt = folder, meta, receipt
        self.base_receipt_sha = sha(folder / 'base_restart_receipt.json')
        self.base_wall_seconds = time.monotonic() - started
        self.base_solver_seconds = float(status['seconds'])
        self.base_was_reused = was_reused

    def backend_contract(self):
        return {'history_kind': 'independent_C0' if self.mode.startswith('warm') else 'cold_full_history',
                'numerical_variant_id': control.VERSION, 'source_pins': dict(self.sources),
                'diagnostic_only': True, 'method_evidence': list(self.method_evidence),
                'actual_method_verified': True}

    def plan_candidate(self, config, stroke):
        self.check_sources()
        full, core = rect_model.build({**config, 'stroke_mm': float(stroke), 'save_full_strain_trajectory': True})
        if {k: v for k, v in core['config'].items() if k != 'stroke_mm'} != {
                k: v for k, v in self.config.items() if k != 'stroke_mm'}:
            raise ValueError('Search callback changed a physical or numerical case setting.')
        kind = 'warm' if self.mode.startswith('warm') else 'cold'
        if kind == 'warm':
            if self.base_receipt is None:
                raise RuntimeError('Prepare/verify actual C0 explicitly before a warm search.')
            original = producer.expected_branch_input(full, core, self.base_receipt)
        else:
            original = full
        actual, lineage = control.derive_input(original, kind)
        digest = hashlib.sha256(actual.encode('ascii')).hexdigest()
        folder = self.parent / candidate_name(stroke, digest)
        plan = {'execution_mode': self.mode, 'stroke_mm': float(stroke),
                'executed_input_sha256': digest, 'numerical_variant': control.VERSION,
                'native_derivation_lineage': lineage, 'directory': str(folder),
                'normalized_full_cold_plan_sha256': hashlib.sha256(full.encode('ascii')).hexdigest(),
                'normalized_full_cold_plan_is_execution_evidence': False,
                'original_generator_plan_input_sha256': lineage['original_generator_plan_input_sha256']}
        if kind == 'warm':
            plan['base_executed_input_sha256'] = self.base_receipt['input_sha256']
            plan['base_receipt_sha256'] = self.base_receipt_sha
        return plan

    def evaluate_candidate(self, config, stroke, timeout):
        plan = self.plan_candidate(config, stroke)
        folder = Path(plan['directory'])
        if folder.exists():
            raise FileExistsError('Every prior attempt remains; caller must use a fresh case or verified seed.')
        start = time.monotonic()
        full, core = rect_model.build({**config, 'stroke_mm': float(stroke), 'save_full_strain_trajectory': True})
        kind = 'warm' if self.mode.startswith('warm') else 'cold'
        if kind == 'warm':
            generated, metadata = warm.prepare_branch(self.base, float(stroke), folder.name, self.parent)
            if generated != folder:
                raise RuntimeError('Independent branch preparation target differs.')
            original = (folder / 'input.inp').read_text(encoding='ascii')
            expected = metadata['expected_files']
        else:
            folder.mkdir(parents=True)
            original = full
            metadata = core
            expected = core['expected_files']
        actual, lineage = control.derive_input(original, kind)
        if lineage != plan['native_derivation_lineage']:
            raise RuntimeError('Actual prepared native input differs from frozen candidate plan.')
        if kind == 'warm':
            metadata = {**metadata, 'input_sha256': plan['executed_input_sha256'],
                        'native_solution_control_variant': lineage}
        else:
            metadata = {**metadata, 'native_solution_control_variant': lineage}
        # Fresh preparation only, before any solve. Original generator plan
        # remains a separately named plan and is never claimed as executed.
        (folder / 'input.inp').write_bytes(actual.encode('ascii'))
        (folder / 'generator_plan_input.inp').write_bytes(original.encode('ascii'))
        from solver_runner import write_json
        write_json(folder / ('warm_metadata.json' if kind == 'warm' else 'model_metadata.json'), metadata)
        write_new(folder / 'native_derivation_lineage.json', lineage)
        self.check_sources()
        if kind == 'warm':
            producer._verify_branch_inputs(self.base, folder, metadata)
        from update_report import update
        progress = read(ROOT / 'progress.json')
        progress.update(phase='优化流程中的实际三维候选计算', current_case=self.case_id,
                        current_stroke_mm=float(stroke), machine_learning_run=False, backup_created=False,
                        note='本候选独立恢复实际初态；求解退出后才计入完成数。')
        write_json(ROOT / 'progress.json', progress)
        update(scan_runs=False)
        status = run_solver(folder, actual, expected, timeout=timeout, cores=4)
        if kind == 'warm':
            warm._verify_hashes(self.base, self.base_receipt['immutable_source_files'])
        record = {'schema': VERSION, 'case_id': self.case_id, 'stroke_mm': float(stroke),
                  'config': core['config'], 'execution_mode': self.mode,
                  'numerical_variant': control.VERSION, 'native_derivation_lineage': lineage,
                  'input_sha256': plan['executed_input_sha256'], 'model_source_sha256': sha(rect_model.__file__),
                  'directory': str(folder), 'solver_status': status,
                  'accepted_solver': False, 'parsed': False, 'admissible': False,
                  'qualified_for_formal_dataset': False, 'formal_generation_unlocked': False,
                  'machine_learning_run': False, 'backup_created': False}
        record['newly_invoked_physical_FE_count'] = int(producer.launch_evidence(status)['actual_launch_verified'])
        for key in ('base_executed_input_sha256', 'normalized_full_cold_plan_sha256',
                    'normalized_full_cold_plan_is_execution_evidence', 'base_receipt_sha256'):
            if key in plan:
                record[key] = plan[key]
        # Shared control mismatch is a method problem, never an isolated
        # failed candidate that the search is allowed to silently skip.
        if status.get('accepted_exit') is True:
            adapter.validate_status(status, {'input_sha256': plan['executed_input_sha256'], 'solver_cores': 4})
            audit = control.audit_log(folder)
            write_new(folder / 'control_actual_audit.json', audit)
            record['actual_control_audit'] = audit
            if audit.get('passed') is not True:
                record['systemic_control_failure'] = True
                record['wall_seconds'] = time.monotonic() - start
                write_new(folder / 'optimized_trial_result.json', record)
                raise RuntimeError('Actual effective controls differ; stop the shared method.')
            record['accepted_solver'] = True
            try:
                if kind == 'warm':
                    branch = adapter.parse_branch_recovered(folder)
                    write_new(folder / 'branch_restart_receipt.json', branch)
                    metrics = branch['metrics']
                    initial = branch['actual_initial_fields_verified']
                    record['independent_initial_history_verified'] = (
                        branch['source_base_unchanged_after_branch'] is True
                        and branch['actual_combined_SET_coverage_verified'] is True
                        and all(v == 0. for state in initial.values() for v in state.values()))
                else:
                    metrics = rect_model.parse(folder, core)
                    record['independent_initial_history_verified'] = True
                record.update(parsed=True, metrics=metrics)
                record['admissible'], record['admissibility_reason'] = admissibility(record)
            except Exception as error:
                record.update(parsed=False, parse_error=repr(error), traceback=traceback.format_exc())
                record['wall_seconds'] = time.monotonic() - start
                record['actual_receipt_path'] = str(folder / 'optimized_trial_result.json')
                write_new(folder / 'optimized_trial_result.json', record)
                raise RuntimeError('Unclassified shared physical-parser error; preserve and stop.') from error
        else:
            record['failure_cause'] = 'Actual solver exit/error/timeout receipt; no substituted physical values.'
        record['wall_seconds'] = time.monotonic() - start
        record['actual_receipt_path'] = str(folder / 'optimized_trial_result.json')
        write_new(folder / 'optimized_trial_result.json', record)
        self.check_sources()
        return record

    def validate_execution(self, record, plan):
        self.check_sources()
        p = Path(record['directory']).resolve()
        receipt = p / 'optimized_trial_result.json'
        saved = read(receipt)
        if saved != record or sha(p / 'input.inp') != plan['executed_input_sha256']:
            raise ValueError('Actual candidate receipt/native input differs.')
        actual_status = read(p / 'solver_status.json')
        if (actual_status != record.get('solver_status')
                or actual_status.get('input_sha256') != plan['executed_input_sha256']
                or actual_status.get('software_mock')):
            raise ValueError('Actual completed or failed solver status/input differs from its receipt.')
        original = (p / 'generator_plan_input.inp').read_text(encoding='ascii')
        derived, lineage = control.derive_input(original, 'warm' if self.mode.startswith('warm') else 'cold')
        if (derived.encode('ascii') != (p / 'input.inp').read_bytes()
                or lineage != record['native_derivation_lineage']):
            raise ValueError('Actual derived input/control lineage cannot be reproduced.')
        if record.get('accepted_solver') is True:
            adapter.validate_status(read(p / 'solver_status.json'),
                                    {'input_sha256': plan['executed_input_sha256'], 'solver_cores': 4})
            if record.get('actual_control_audit', {}).get('passed') is not True:
                raise ValueError('No actual successful solver-control audit.')
        return {'execution_evidence_verified': True,
                'independent_initial_history_verified': record.get('independent_initial_history_verified') is True,
                'candidate_failure_recorded': record.get('accepted_solver') is not True or record.get('parsed') is not True,
                'actual_receipt_path': str(receipt), 'actual_receipt_sha256': sha(receipt),
                'numerical_variant_verified': True,
                'sources': {str(receipt): sha(receipt), str(p / 'input.inp'): sha(p / 'input.inp'),
                            str(p / 'solver_status.json'): sha(p / 'solver_status.json'), **self.sources}}
