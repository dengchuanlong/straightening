"""Continuous-history 3D rectangular-bar contact model (mm, N, MPa).

build(config) -> (ASCII MAPDL input, JSON-serializable metadata).
parse(folder, metadata) -> measured metrics; missing results are never zeros.
No solver is launched here. X and Z reflection symmetry gives a quarter model.
"""
from __future__ import annotations

import hashlib
import math
from pathlib import Path
import re
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
MATERIAL = ROOT.parent / 'auto_run_20261001/material/v002/candidate_material.inp'
VERSION = 'RECT3D004'
STAGES = {'A': 1, 'B': 5, 'C0': 6, 'C': 7, 'D': 11}


def _number(value):
    return format(float(value), '.16g')


def _normalize(config):
    c = dict(config)
    defaults = dict(b_mm=35., h_mm=8., length_mm=270.,
                    support_span_mm=260., punch_radius_mm=10., support_radius_mm=10.,
                    prebend_tool_stroke_mm=15.6934, prebend_outer_span_mm=260.,
                    prebend_inner_span_mm=100., prebend_radius_mm=10., stroke_mm=0.,
                    friction=.15, ny=8, nz=4, dx_mm=2., weak_spring_N_per_mm=.01,
                    FKN_factor=.1, FTOLN_factor=.001, max_tool_increment_mm=.15,
                    unload_increment_mm=.1, fine_withdrawal_clearance_mm=1.,
                    material_version='v002')
    c = {**defaults, **c}
    for key in defaults:
        if key == 'material_version':
            continue
        if key in ('ny', 'nz'):
            if int(c[key]) != c[key] or c[key] < 2:
                raise ValueError(f'{key} must be an integer >=2')
            c[key] = int(c[key])
        else:
            c[key] = float(c[key])
            if not math.isfinite(c[key]):
                raise ValueError(f'Non-finite {key}')
    if c['material_version'] != 'v002':
        raise ValueError('Only the identified v002 material is supported')
    for key in ('b_mm', 'h_mm', 'length_mm', 'support_span_mm', 'punch_radius_mm',
                'support_radius_mm', 'prebend_tool_stroke_mm', 'prebend_radius_mm',
                'dx_mm', 'weak_spring_N_per_mm', 'FKN_factor', 'FTOLN_factor',
                'max_tool_increment_mm','unload_increment_mm','fine_withdrawal_clearance_mm'):
        if c[key] <= 0:
            raise ValueError(f'{key} must be positive')
    if c['stroke_mm'] < 0 or c['friction'] < 0:
        raise ValueError('Negative stroke or friction')
    if c['length_mm'] < 260 or not (0 < c['prebend_inner_span_mm'] < c['prebend_outer_span_mm'] <= c['length_mm']):
        raise ValueError('Invalid fixed evaluation interval or pre-bend spans')
    if not 0 < c['support_span_mm'] <= c['length_mm']:
        raise ValueError('Correction support span must lie within bar length')
    c['tool_far_gap_mm'] = float(c.get('tool_far_gap_mm', 100.))
    c['save_full_strain_trajectory']=bool(c.get('save_full_strain_trajectory',True))
    c['tool_release_gap_mm'] = float(c.get('tool_release_gap_mm', max(40., 2*(c['prebend_tool_stroke_mm']+c['h_mm']))))
    if not math.isfinite(c['tool_far_gap_mm']) or c['tool_far_gap_mm'] <= 0 or not math.isfinite(c['tool_release_gap_mm']) or c['tool_release_gap_mm'] <= 0:
        raise ValueError('Tool clearance must be finite and positive')
    return c


def build(config):
    c = _normalize(config)
    b, h, length = c['b_mm'], c['h_mm'], c['length_mm']
    ny, nz = c['ny'], c['nz']
    anchors = np.unique([0., c['prebend_inner_span_mm']/2,
                         c['prebend_outer_span_mm']/2,
                         130., length/2])
    # Partition each anchor interval: no sliver introduced when a span varies.
    x = np.unique(np.concatenate([np.linspace(a, z, max(1, math.ceil((z-a)/c['dx_mm']))+1)
                                 for a, z in zip(anchors[:-1], anchors[1:])]))
    y, z = np.linspace(-h/2, h/2, ny+1), np.linspace(0, b/2, nz+1)
    nn, ne = len(x)*(ny+1)*(nz+1), (len(x)-1)*ny*nz
    node = lambda i, j, k: 1+(i*(ny+1)+j)*(nz+1)+k
    material_bytes = MATERIAL.read_bytes()
    material = material_bytes.decode('ascii').replace('\r\n', '\n')
    lines = ['/batch', '/prep7', 'eresx,no', 'et,1,185', 'keyopt,1,2,2',
             material.strip(), 'type,1', 'mat,1']
    for i, xx in enumerate(x):
        for j, yy in enumerate(y):
            for k, zz in enumerate(z):
                lines.append(f'n,{node(i,j,k)},{_number(xx)},{_number(yy)},{_number(zz)}')
    for i in range(len(x)-1):
        for j in range(ny):
            for k in range(nz):
                ns = [node(i,j,k), node(i+1,j,k), node(i+1,j+1,k), node(i,j+1,k),
                      node(i,j,k+1), node(i+1,j,k+1), node(i+1,j+1,k+1), node(i,j+1,k+1)]
                lines.append('e,'+','.join(map(str,ns)))
    lines += ['cm,workel,elem', 'cm,worknd,node',
              'nsel,s,loc,x,0', 'd,all,ux,0', 'allsel,all',
              'nsel,s,loc,z,0', 'd,all,uz,0', 'allsel,all',
              'cmsel,s,worknd', f'nsel,r,loc,y,{_number(h/2)}', 'cm,topnd,node',
              'cmsel,s,worknd', f'nsel,r,loc,y,{_number(-h/2)}', 'cm,botnd,node', 'allsel,all',
              'et,2,170', 'et,3,174', 'keyopt,3,2,1', 'keyopt,3,4,2', 'keyopt,3,10,2',
              f'mp,mu,2,{_number(c["friction"])}']
    tools = {}
    support_x=c['support_span_mm']/2
    support_patch=max(35.,1.5*c['support_radius_mm'])
    specifications = [
        ('prehead', 2, c['prebend_inner_span_mm']/2, h/2+c['prebend_radius_mm'], c['prebend_radius_mm'], 'topnd',25.,90.),
        ('prebase', 3, c['prebend_outer_span_mm']/2, -h/2-c['prebend_radius_mm'], c['prebend_radius_mm'], 'botnd',95.,length/2),
        ('support', 4, support_x, h/2+c['support_radius_mm']+c['tool_far_gap_mm'], c['support_radius_mm'], 'topnd',max(0.,support_x-support_patch),min(length/2,support_x+support_patch)),
        ('punch', 5, 0., -h/2-c['punch_radius_mm']-c['tool_far_gap_mm'], c['punch_radius_mm'], 'botnd',0.,min(60.,support_x))]
    contact_ne=0
    for it, (name, real, xx, yy, radius, component, xlo, xhi) in enumerate(specifications):
        pilot = nn+100+it*40
        faces=int(np.sum((x[:-1]>=xlo-1e-9)&(x[1:]<=xhi+1e-9)))*nz
        if not faces:
            raise ValueError(f'No meshed contact faces for {name}')
        contact_ne+=faces
        tools[name] = dict(pilot_node=pilot, real_id=real, initial_x_mm=xx,
                           initial_y_mm=yy, radius_mm=radius, roller_rotation='fixed',
                           reference_contact_patch_x_mm=[xlo,xhi], contact_elements=faces)
        lines += [f'r,{real},{_number(radius)},,{_number(c["FKN_factor"])},{_number(c["FTOLN_factor"])}',
                  'type,2', f'real,{real}', 'mat,2',
                  f'n,{pilot},{_number(xx)},{_number(yy)},0',
                  f'n,{pilot+10},{_number(xx)},{_number(yy)},-5',
                  f'n,{pilot+20},{_number(xx)},{_number(yy)},{_number(b/2+5)}',
                  'tshap,cyli', f'e,{pilot+10},{pilot+20}', 'tshap,pilo', f'e,{pilot}',
                  f'd,{pilot},all,0', 'cmsel,s,workel', f'cmsel,s,{component}',
                  f'nsel,r,loc,x,{_number(xlo)},{_number(xhi)}',
                  'type,3', 'esurf', 'allsel,all']
    # A UY-only spring anchors one material node, without a hard UY constraint.
    iw = int(np.argmin(abs(x-c['prebend_outer_span_mm']/2)))
    jw = ny//2
    gauge, ghost = node(iw,jw,0), nn+300
    weak = c['weak_spring_N_per_mm']
    lines += ['et,4,14', 'keyopt,4,2,2', f'r,6,{_number(weak)}', 'type,4', 'real,6',
              f'n,{ghost},{_number(x[iw])},{_number(y[jw])},0', f'e,{gauge},{ghost}',
              f'd,{ghost},all,0', 'allsel,all', 'finish', '/solu',
              'antype,static', 'nlgeom,on', 'autots,on', 'nropt,unsym', 'neqit,75',
              'cnvtol,f,,0.001,2,1', 'cnvtol,m,,0.001,2,1', 'kbc,0',
              'outres,all,last', 'outres,nsol,all', 'outres,rsol,all']
    if c['save_full_strain_trajectory']:
        lines += ['outres,epel,all,workel','outres,eppl,all,workel']
    ph, pb = tools['prehead']['pilot_node'], tools['prebase']['pilot_node']
    cs, cp = tools['support']['pilot_node'], tools['punch']['pilot_node']
    release, stroke = c['tool_release_gap_mm'], c['stroke_mm']

    def solve(step, commands, travel, increment=None):
        inc = c['max_tool_increment_mm'] if increment is None else increment
        sub = max(2, math.ceil(abs(travel)/inc))
        lines.extend([f'time,{step}', *commands, f'nsubst,{sub},{max(500,sub*10)},{sub}', 'solve'])

    solve(1, [f'd,{ph},uy,{_number(-c["prebend_tool_stroke_mm"])}'], c['prebend_tool_stroke_mm'])
    unload=c['unload_increment_mm']; fine=c['fine_withdrawal_clearance_mm']
    solve(2, [f'd,{ph},uy,0'], c['prebend_tool_stroke_mm'],unload)
    solve(3, [f'd,{ph},uy,{_number(release)}'], release,release)
    solve(4, [f'd,{pb},uy,{_number(-fine)}'], fine,unload)
    solve(5, [f'd,{pb},uy,{_number(-release)}'], release-fine,release)
    # Query the fully unloaded B deformation while remaining in /SOLU.
    # These extrema give first nodal contact with the analytic cylinders.
    lines += ['supcy=-1e30', 'puncy=1e30', 'supn=0', 'punn=0',
              'cmsel,s,topnd', '*get,nct,node,0,count', '*get,nid,node,0,num,min',
              '*do,jj,1,nct', '*get,rx,node,nid,loc,x', '*get,ry,node,nid,loc,y',
              '*get,uxb,node,nid,u,x', '*get,uyb,node,nid,u,y',
              f'xd=rx+uxb-{_number(c["support_span_mm"]/2)}',
              f'rd={_number(c["support_radius_mm"]**2)}-xd*xd',
              '*if,rd,ge,0,then', 'cy=ry+uyb+sqrt(rd)', 'supcy=max(supcy,cy)', 'supn=supn+1', '*endif',
              'nid=ndnext(nid)', '*enddo', 'cmsel,s,botnd', '*get,nct,node,0,count', '*get,nid,node,0,num,min',
              '*do,jj,1,nct', '*get,rx,node,nid,loc,x', '*get,ry,node,nid,loc,y',
              '*get,uxb,node,nid,u,x', '*get,uyb,node,nid,u,y', 'xd=rx+uxb',
              f'rd={_number(c["punch_radius_mm"]**2)}-xd*xd',
              '*if,rd,ge,0,then', 'cy=ry+uyb-sqrt(rd)', 'puncy=min(puncy,cy)', 'punn=punn+1', '*endif',
              'nid=ndnext(nid)', '*enddo', 'allsel,all',
              f'supuy=supcy-({_number(tools["support"]["initial_y_mm"])})',
              f'punuy=puncy-({_number(tools["punch"]["initial_y_mm"])})',
              '*cfopen,touch_geometry,txt', '*vwrite,supcy,puncy,supuy,punuy,supn,punn', '(6(E24.16,1X))', '*cfclos']
    solve(6, [f'd,{cs},uy,supuy', f'd,{cp},uy,punuy'], c['tool_far_gap_mm']+release,c['tool_far_gap_mm']+release)
    solve(7, [f'd,{cp},uy,punuy+{_number(stroke)}'], stroke)
    solve(8, [f'd,{cp},uy,punuy-{_number(fine)}'], stroke+fine,unload)
    solve(9, [f'd,{cp},uy,punuy-{_number(release)}'], release-fine,release)
    solve(10,[f'd,{cs},uy,supuy+{_number(fine)}'], fine,unload)
    solve(11,[f'd,{cs},uy,supuy+{_number(release)}'], release-fine,release)
    # All solves above are in one uninterrupted /SOLU history.
    lines += ['finish', '/post1', 'rsys,0', '/format,8,e,25,17,1000000,240',
              'set,last', '*get,ntset,active,0,set,nset',
              'esel,s,type,,3','*get,nce,elem,0,count','*get,ce,elem,0,num,min',
              '*cfopen,contact_identity,txt','*do,jj,1,nce','*get,cr,elem,ce,attr,real',
              '*get,cn1,elem,ce,node,1','*get,cn2,elem,ce,node,2',
              '*get,cn3,elem,ce,node,3','*get,cn4,elem,ce,node,4',
              '*vwrite,ce,cr,cn1,cn2,cn3,cn4','(6(E24.16,1X))',
              'ce=elnext(ce)','*enddo','*cfclos','allsel,all',
              '*cfopen,history,txt', '*do,iset,1,ntset', 'set,,,,,,,iset',
              '*get,lstep,active,0,set,lstp', '*get,rtime,active,0,set,time',
              f'*get,pcuy,node,{cp},u,y', f'*get,pcfy,node,{cp},rf,fy',
              f'*get,phfy,node,{ph},rf,fy', f'*get,swuy,node,{gauge},u,y',
              f'*get,sufy,node,{cs},rf,fy',
              '*vwrite,iset,lstep,rtime,pcuy,pcfy,phfy,swuy,sufy', '(8(E24.16,1X))', '*enddo', '*cfclos']
    if c['save_full_strain_trajectory']:
        lines += [f'*dim,TR,array,{ne},2','/output,strain_history_log,txt','*cfopen,strain_history,txt',
                  '*do,iset,1,ntset','allsel,all','set,,,,,,,iset',
                  '*get,lstep,active,0,set,lstp','*get,rtime,active,0,set,time',
                  'cmsel,s,workel','nsle,s','etable,erase',
                  'etable,trmax,epto,x,max','etable,trmin,epto,x,min',f'*vlen,{ne}',
                  '*vget,TR(1,1),elem,1,etab,trmax','*vget,TR(1,2),elem,1,etab,trmin',
                  '*vscfun,emax,max,TR(1,1)','*vscfun,emin,min,TR(1,2)',
                  '*vlen,1','*vwrite,iset,lstep,rtime,emax,emin','(5(E24.16,1X))',
                  '*enddo','*cfclos','/output','allsel,all']
    for label, step in STAGES.items():
        arr = 'U'+label
        ea = 'E'+label
        lines += [f'set,{step},last', 'allsel,all', f'*dim,{arr},array,{nn},3', f'*vlen,{nn}',
                  f'*vget,{arr}(1,1),node,1,u,x', f'*vget,{arr}(1,2),node,1,u,y', f'*vget,{arr}(1,3),node,1,u,z',
                  f'*cfopen,state_{label}_nodes,txt', f'*vwrite,{arr}(1,1),{arr}(1,2),{arr}(1,3)', '(3(E24.16,1X))', '*cfclos',
                  'cmsel,s,workel', 'nsle,s', 'etable,erase',
                  'etable,pamax,nl,epeq,max', 'etable,pamin,nl,epeq,min',
                  'etable,exmax,epto,x,max', 'etable,exmin,epto,x,min',
                  f'*dim,{ea},array,{ne},4', f'*vlen,{ne}',
                  f'*vget,{ea}(1,1),elem,1,etab,pamax', f'*vget,{ea}(1,2),elem,1,etab,pamin',
                  f'*vget,{ea}(1,3),elem,1,etab,exmax', f'*vget,{ea}(1,4),elem,1,etab,exmin',
                  f'*cfopen,state_{label}_element_extrema,txt',
                  f'*vwrite,{ea}(1,1),{ea}(1,2),{ea}(1,3),{ea}(1,4)', '(4(E24.16,1X))', '*cfclos',
                  '*vlen,1', 'etable,wene,sene', 'ssum', '*get,wel,ssum,0,item,wene',
                  f'*get,swuy,node,{gauge},u,y', f'*get,pcfy,node,{cp},rf,fy',
                  f'*get,sufy,node,{cs},rf,fy', f'*get,phfy,node,{ph},rf,fy',
                  f'*get,pbfy,node,{pb},rf,fy',
                  f'*cfopen,state_{label}_scalars,txt', '*vwrite,wel,swuy,pcfy,sufy,phfy,pbfy', '(6(E24.16,1X))', '*cfclos',
                  f'/output,state_{label}_p,txt', 'presol,nl,epeq', '/output',
                  f'/output,state_{label}_ex,txt', 'presol,epto,x', '/output',
                  f'/output,state_{label}_sx,txt', 'presol,s,x', '/output',
                  'esel,s,type,,3', 'nsle,s', f'/output,state_{label}_penetration,txt', 'presol,cont,pene', '/output',
                  f'/output,state_{label}_pressure,txt', 'presol,cont,pres', '/output',
                  f'/output,state_{label}_contact_table_log,txt','etable,erase',
                  'etable,cstat,cont,stat,max','etable,cpen,cont,pene','etable,cpre,cont,pres',
                  'ctavail=0','*get,ctcols,etab,0,ncol,max',
                  '*if,ctcols,ge,3,then','*get,cslab,etab,1,lab',
                  '*get,cplab,etab,2,lab','*get,crlab,etab,3,lab',
                  "*if,cslab,eq,'CSTAT',then","*if,cplab,eq,'CPEN',then",
                  "*if,crlab,eq,'CPRE',then",'ctavail=1','*endif','*endif','*endif','*endif',
                  f'*cfopen,state_{label}_contact_elements,txt','*get,ce,elem,0,num,min',
                  '*do,jj,1,nce','csval=-1e30','cpval=-1e30','crval=-1e30',
                  '*if,ctavail,eq,1,then',
                  '*get,csval,elem,ce,etab,cstat','*get,cpval,elem,ce,etab,cpen','*get,crval,elem,ce,etab,cpre',
                  '*endif',
                  '*vwrite,ce,csval,cpval,crval','(4(E24.16,1X))','ce=elnext(ce)','*enddo','*cfclos','/output','allsel,all',
                  f'*cfopen,state_{label}_tool_vectors,txt']
        for tool in tools.values():
            pn=tool['pilot_node']
            lines += [f'*get,tu,node,{pn},u,y',f'*get,tfx,node,{pn},rf,fx',
                      f'*get,tfy,node,{pn},rf,fy',f'*get,tfz,node,{pn},rf,fz',
                      f'*get,tmx,node,{pn},rf,mx',f'*get,tmy,node,{pn},rf,my',f'*get,tmz,node,{pn},rf,mz',
                      f'*vwrite,{pn},tu,tfx,tfy,tfz,tmx,tmy,tmz','(8(E24.16,1X))']
        lines += ['*cfclos']
    lines += ['*cfopen,complete,txt', '*vwrite,1', '(F8.0)', '*cfclos', 'finish', 'save,model,db', '/exit,nosave']
    expected = ['complete.txt', 'solve.rst', 'history.txt', 'touch_geometry.txt','contact_identity.txt']
    if c['save_full_strain_trajectory']:expected.extend(['strain_history.txt','strain_history_log.txt'])
    for state in STAGES:
        expected += [f'state_{state}_{suffix}.txt' for suffix in ('nodes', 'element_extrema', 'scalars', 'p', 'ex', 'sx', 'penetration', 'pressure')]
        expected += [f'state_{state}_{suffix}.txt' for suffix in ('contact_elements','contact_table_log','tool_vectors')]
    metadata = dict(model_version=VERSION, config=c, units=dict(length='mm', force='N', stress='MPa', energy='N mm'),
                    state_stages=STAGES, stage_description={'A':'prebend peak', 'B':'prebend free unload',
                    'C0':'first corrective nodal contact', 'C':'corrective maximum prescribed stroke', 'D':'final free unload'},
                    dimension='3D quarter: exact X=0 and Z=0 symmetry', reaction_multiplier=4., roller_rotation='fixed',
                    gravity='ignored', mesh_count=dict(work_nodes=nn, solid_elements=ne,
                    contact_elements=contact_ne,estimated_total_nodes=nn+13, estimated_total_elements=ne+contact_ne+9),
                    x_mm=x.tolist(), y_mm=y.tolist(), z_mm=z.tolist(),
                    mesh_order='node=1+(i*(ny+1)+j)*(nz+1)+k; element i,j,k lexicographic',
                    tools=tools, weak_spring=dict(node=gauge, ghost_node=ghost, stiffness_N_per_mm=weak),
                    material_file=str(MATERIAL), material_sha256=hashlib.sha256(material_bytes).hexdigest(),
                    expected_files=expected, evaluation_interval_mm=260., full_length_mm=length,
                    contact_detection='CONTA174 KEYOPT(4)=2 nodes to analytic cylindrical TARGE170; fixed rollers',
                    plastic_state_quantity='NL,EPEQ accumulated effective plastic strain',
                    ip_extrema_basis='ERESX NO ETABLE MAX/MIN copied integration-point records; raw PRESOL retained',
                    history_saved='NSOL and RSOL every converged substep; full fields last substep of each stage; optional workel EPEL+EPPL every substep',
                    independent_candidates='Every stroke starts from a cold complete pre-bend history')
    metadata['prebend_history_identity']='Pre-bend mesh, material, prescribed tool paths and substeps do not depend on corrective stroke.'
    metadata['mesh_anchors_mm']=anchors.tolist()
    metadata['correction_support_mesh_anchor']=False
    metadata['time_axis']='Monotonic static load parameter; not physical elapsed seconds.'
    metadata['contact_identity_export']='Actual EID/REAL/four-node identities exported from saved model; CONT STAT maximum status, PENE/PRES element averages, raw PRESOL kept separately.'
    metadata['contact_table_missing_policy']='Check ETAB NCOL and actual column labels before GET; unavailable CONT uses -1e30 output sentinel parsed as null, never zero.'
    metadata['loaded_tool_unload_increment_mm']=unload
    metadata['air_motion_substeps']=2
    metadata['centroid_area_basis']='true 3D Q4 surface: norm(cross(dX/dxi,dX/deta)); 3x3 Gauss'
    return '\n'.join(lines)+'\n', metadata


def _load(path, columns=None, rows=None):
    a = np.atleast_2d(np.loadtxt(path))
    if not np.isfinite(a).all() or (columns is not None and a.shape[1] != columns) or (rows is not None and a.shape[0] != rows):
        raise ValueError(f'Invalid result array {path}: {a.shape}')
    return a


def _centroid_axis(u, metadata):
    """Q4 true 3D material-section area integral of XYZ, mirrored across Z=0.

    3x3 Gauss integration uses the deformed cross-section, not a node average.
    The symmetry half at negative X is reconstructed only for chord evaluation.
    """
    x, y, z = map(np.asarray, (metadata['x_mm'], metadata['y_mm'], metadata['z_mm']))
    ny, nz = len(y)-1, len(z)-1
    ref = np.stack(np.meshgrid(x,y,z,indexing='ij'),axis=-1)
    xyz = ref + u.reshape(len(x),len(y),len(z),3)
    gauss, weights = np.polynomial.legendre.leggauss(3)
    axis, areas = [], []
    for section in xyz:
        moment = np.zeros(3); area = 0.
        for j in range(ny):
            for k in range(nz):
                q = section[[j,j+1,j+1,j],[k,k,k+1,k+1]]
                for xi, wi in zip(gauss,weights):
                    for eta, wj in zip(gauss,weights):
                        n = .25*np.array([(1-xi)*(1-eta),(1+xi)*(1-eta),(1+xi)*(1+eta),(1-xi)*(1+eta)])
                        dxi = .25*np.array([-(1-eta),1-eta,1+eta,-(1+eta)])
                        deta = .25*np.array([-(1-xi),-(1+xi),1+xi,1-xi])
                        tangent_xi,tangent_eta=dxi@q,deta@q
                        projected=np.linalg.det(np.array([tangent_xi[1:],tangent_eta[1:]]))
                        if metadata.get('model_version') in ('RECT3D001','RECT3D002'):
                            jac=float(projected)
                        else:
                            jac=float(np.linalg.norm(np.cross(tangent_xi,tangent_eta)))
                        if projected<=0 or jac<=0:
                            raise ValueError('Nonpositive material-section orientation/area (fold or rotation outside model range)')
                        da = wi*wj*jac
                        moment += da*(n@q); area += da
        center = moment/area
        center[2] = 0. # full-section reflection symmetry
        axis.append(center); areas.append(2*area)
    return np.asarray(axis), np.asarray(areas)


def _chord_error(axis, refs, half_interval):
    hit = np.flatnonzero(np.isclose(refs,half_interval,atol=1e-9))
    if len(hit)!=1:
        raise ValueError('Evaluation endpoint not explicitly meshed')
    endpoint = axis[int(hit[0])]
    minus = endpoint*np.array([-1.,1.,1.]); chord = endpoint-minus
    pts = axis[refs <= half_interval+1e-9]
    return float(np.max(np.linalg.norm(np.cross(pts-minus,chord),axis=1)/np.linalg.norm(chord)))


_FLOAT = r'[-+]?(?:\d+\.?\d*|\.\d+)(?:[EeDd][-+]?\d+)?'


def _presol_records(path, column):
    """Element/node result records, without averaging adjacent elements.

    The key is (element, node, row occurrence). ERESX NO copies IP records
    to corner nodes; these are not asserted to be integration-point coordinates.
    """
    records = {}; element = None; repeats = {}; index_column = None
    listing=Path(path).read_text(encoding='ascii',errors='replace')
    if '*** ERROR ***' in listing:
        raise ValueError(f'Error in redirected PRESOL listing: {path}')
    for line in listing.splitlines():
        header = re.search(r'\bELEMENT\s*(?:=|NUMBER\s*=?)\s*(\d+)',line,re.I)
        if header:
            element = int(header.group(1)); continue
        labels=re.findall(r'\b[A-Z][A-Z0-9]*\b',line.upper())
        if labels and labels[0]=='NODE':
            index_column=next((i for i,label in enumerate(labels) if label in column),None)
            continue
        if element is None or not re.match(r'^\s*\d+\s+[-+\d.]',line):
            continue
        values = re.findall(_FLOAT,line)
        if index_column is None or len(values)<=index_column:
            continue
        node = int(float(values[0].replace('D','E').replace('d','e')))
        pair = (element,node); index=repeats.get(pair,0); repeats[pair]=index+1
        val=float(values[index_column].replace('D','E').replace('d','e'))
        if not math.isfinite(val):
            raise ValueError(f'Non-finite PRESOL in {path}')
        records[(element,node,index)] = val
    return records


def _difference(a,b):
    if not a or a.keys()!=b.keys():
        return None
    return float(max(abs(a[k]-b[k]) for k in a))


def _ip_coverage(records, metadata):
    """Check the exact saved element-node identity, not just the row count."""
    nx,ny,nz=len(metadata['x_mm'])-1,len(metadata['y_mm'])-1,len(metadata['z_mm'])-1
    node=lambda i,j,k: 1+(i*(ny+1)+j)*(nz+1)+k
    expected=set(); eid=0
    for i in range(nx):
        for j in range(ny):
            for k in range(nz):
                eid+=1
                ns=[node(i,j,k),node(i+1,j,k),node(i+1,j+1,k),node(i,j+1,k),
                    node(i,j,k+1),node(i+1,j,k+1),node(i+1,j+1,k+1),node(i,j+1,k+1)]
                expected.update((eid,n,0) for n in ns)
    return records.keys()==expected


def _contact_identities(folder,metadata):
    a=_load(folder/'contact_identity.txt',6,metadata['mesh_count']['contact_elements'])
    if not np.equal(a,np.round(a)).all():raise ValueError('Non-integer contact identity')
    a=a.astype(int);x=np.asarray(metadata['x_mm']);ny=len(metadata['y_mm'])-1;nz=len(metadata['z_mm'])-1
    node=lambda i,j,k: 1+(i*(ny+1)+j)*(nz+1)+k
    identities={};bytool={}
    for name,tool in metadata['tools'].items():
        part=a[a[:,1]==tool['real_id']]
        if len(part)!=tool['contact_elements']:raise ValueError(f'Incomplete contact identity for {name}')
        lo,hi=tool['reference_contact_patch_x_mm'];j=ny if name in ('prehead','support') else 0
        expected={frozenset([node(i,j,k),node(i+1,j,k),node(i+1,j,k+1),node(i,j,k+1)])
                  for i in range(len(x)-1) if x[i]>=lo-1e-9 and x[i+1]<=hi+1e-9 for k in range(nz)}
        actual={frozenset(row[2:]) for row in part}
        if actual!=expected:raise ValueError(f'Contact {name} geometry differs from source mesh')
        bytool[name]=[int(row[0]) for row in part]
        for row in part:
            eid=int(row[0])
            if eid in identities:raise ValueError('Duplicate contact element ID')
            identities[eid]=(name,set(map(int,row[2:])))
    if len(identities)!=len(a):raise ValueError('Unexpected contact REAL identity')
    return identities,bytool


def _listing_available(path):
    listing=path.read_text(encoding='ascii',errors='replace')
    return not re.search(r'\*\*\* ERROR \*\*\*|not available|undefined|not defined|invalid|not recognized|ignored',listing,re.I)


def _contact_state(folder,state,metadata,u,identities,bytool,pen,pressure):
    vectors=_load(folder/f'state_{state}_tool_vectors.txt',8,4)
    tables=_load(folder/f'state_{state}_contact_elements.txt',4,len(identities))
    if set(tables[:,0].astype(int))!=set(identities):raise ValueError('Incomplete contact element result table')
    available=_listing_available(folder/f'state_{state}_contact_table_log.txt')
    expected_records={(e,n,0) for e,(_,nodes) in identities.items() for n in nodes}
    if not set(pen).issubset(expected_records) or pen.keys()!=pressure.keys():
        raise ValueError('PRESOL contact records lack a valid element/node identity')
    x,y,z=map(np.asarray,(metadata['x_mm'],metadata['y_mm'],metadata['z_mm']))
    xyz=np.stack(np.meshgrid(x,y,z,indexing='ij'),axis=-1).reshape(-1,3)+u
    results={}
    for name,tool in metadata['tools'].items():
        selected=vectors[np.isclose(vectors[:,0],tool['pilot_node'])]
        if len(selected)!=1:raise ValueError('Missing/duplicated target pilot vector')
        row=selected[0]; center_y=tool['initial_y_mm']+row[1]
        node_ids=sorted({n for eid in bytool[name] for n in identities[eid][1]})
        nodes=xyz[np.asarray(node_ids)-1]
        if np.min(nodes[:,2]) < -5.-1e-8 or np.max(nodes[:,2])>metadata['config']['b_mm']/2+5.+1e-8:
            raise ValueError('Contact nodes outside analytic cylinder axial extent')
        gaps=np.hypot(nodes[:,0]-tool['initial_x_mm'],nodes[:,1]-center_y)-tool['radius_mm']
        part=tables[np.isin(tables[:,0],bytool[name])]
        valid=bool(available and np.all(abs(part[:,1:])<1e20))
        pp=[value for (eid,_,_),value in pen.items() if eid in bytool[name]]
        pr=[value for (eid,_,_),value in pressure.items() if eid in bytool[name]]
        force=row[2:5]
        force_bound=float(4*np.linalg.norm(force))
        min_gap=float(np.min(gaps))
        results[name]=dict(pilot_UY_mm=float(row[1]),actual_center_y_mm=float(center_y),
                          quarter_RF_xyz_N=force.tolist(),quarter_RF_mxyz_Nmm=row[5:8].tolist(),
                          full_FY_N=float(4*row[3]),four_times_quarter_force_norm_N=force_bound,
                          min_nodal_radial_gap_mm=min_gap,geometric_gap_node_count=len(node_ids),
                          element_count=len(part),element_table_available=valid,
                          max_element_contact_status=float(part[:,1].max()) if valid else None,
                          max_element_mean_penetration_mm=float(part[:,2].max()) if valid else None,
                          max_element_mean_pressure_MPa=float(part[:,3].max()) if valid else None,
                          max_available_point_penetration_mm=float(max(pp)) if pp else None,
                          max_available_point_pressure_MPa=float(max(pr)) if pr else None,
                          available_point_records=len(pp),
                          independently_open_by_geometry_and_RF=bool(min_gap>1e-6 and force_bound<.1))
    return results,bool(pen.keys()==expected_records)


def parse(folder, metadata):
    folder=Path(folder); c=metadata['config']; nn=metadata['mesh_count']['work_nodes']; ne=metadata['mesh_count']['solid_elements']
    history=_load(folder/'history.txt',8)
    touch=_load(folder/'touch_geometry.txt',6,1)[0]
    if min(touch[4:])<1 or max(abs(touch[:4]))>1e10:
        raise ValueError('No valid first-contact geometric candidate')
    refs=np.asarray(metadata['x_mm']); states={}; p_records={}; sx_records={}; axes={}; node_u={}; ext=[]
    identities,bytool=_contact_identities(folder,metadata) if metadata['model_version'] in ('RECT3D003','RECT3D004') else ({},{})
    for state in metadata['state_stages']:
        u=_load(folder/f'state_{state}_nodes.txt',3,nn)
        node_u[state]=u
        elem=_load(folder/f'state_{state}_element_extrema.txt',4,ne)
        scalar=_load(folder/f'state_{state}_scalars.txt',6,1)[0]
        axis,areas=_centroid_axis(u,metadata); axes[state]=axis; ext.append(elem)
        p_records[state]=_presol_records(folder/f'state_{state}_p.txt',('EPEQ',))
        sx_records[state]=_presol_records(folder/f'state_{state}_sx.txt',('SX',))
        ex_records=_presol_records(folder/f'state_{state}_ex.txt',('EX','EPTOX'))
        pen=_presol_records(folder/f'state_{state}_penetration.txt',('PENE',))
        pressure=_presol_records(folder/f'state_{state}_pressure.txt',('PRES',))
        expected_ip=8*ne
        if any(not _ip_coverage(r,metadata) for r in (p_records[state],sx_records[state],ex_records)):
            raise ValueError(f'Incomplete {state} copied-IP coverage; expected {expected_ip}, got p/SX/EX={len(p_records[state])}/{len(sx_records[state])}/{len(ex_records)}')
        p_raw_max,p_raw_min=max(p_records[state].values()),min(p_records[state].values())
        ex_raw_max,ex_raw_min=max(ex_records.values()),min(ex_records.values())
        contact_expected=4*metadata['mesh_count']['contact_elements']
        contact_complete=len(pen)==contact_expected and pen.keys()==pressure.keys()
        crosscheck_p=max(abs(p_raw_max-elem[:,0].max()),abs(p_raw_min-elem[:,1].min()))
        crosscheck_ex=max(abs(ex_raw_max-elem[:,2].max()),abs(ex_raw_min-elem[:,3].min()))
        # Both raw listings and vector exports use high precision. These gates
        # expose failed/ignored ETABLE options instead of accepting invented zeros.
        extrema_verified=bool(crosscheck_p<=1e-10 and crosscheck_ex<=1e-10)
        states[state]=dict(error_fixed_260_mm=_chord_error(axis,refs,130.),
                           error_full_length_mm=_chord_error(axis,refs,c['length_mm']/2),
                           axis_reference_x_mm=refs.tolist(), axis_xyz_mm=axis.tolist(),
                           section_area_mm2=areas.tolist(), body_strain_energy_Nmm=float(4*scalar[0]),
                           weak_spring_force_N=float(4*c['weak_spring_N_per_mm']*scalar[1]),
                           weak_spring_energy_Nmm=float(4*.5*c['weak_spring_N_per_mm']*scalar[1]**2),
                           punch_force_N=float(4*scalar[2]), support_force_N=float(4*scalar[3]),
                           prebend_head_force_N=float(4*scalar[4]), prebend_support_force_N=float(4*scalar[5]),
                           max_accumulated_plastic_strain=float(elem[:,0].max()),
                           min_accumulated_plastic_strain=float(elem[:,1].min()),
                           max_abs_axial_total_strain=float(max(abs(elem[:,2]).max(),abs(elem[:,3]).max())),
                           max_contact_penetration_mm=float(max(pen.values())) if pen else None,
                           max_contact_pressure_MPa=float(max(pressure.values())) if pressure else None,
                           copied_IP_p_record_count=len(p_records[state]), copied_IP_SX_record_count=len(sx_records[state]),
                           copied_IP_EX_record_count=len(ex_records),contact_penetration_record_count=len(pen),
                           contact_pressure_record_count=len(pressure),contact_records_complete=contact_complete,
                           extrema_crosscheck_passed=extrema_verified,
                           extrema_crosscheck=dict(raw_p_max=p_raw_max,raw_p_min=p_raw_min,raw_EX_max=ex_raw_max,raw_EX_min=ex_raw_min,
                           p_max_abs_difference=float(abs(p_raw_max-elem[:,0].max())),
                           p_min_abs_difference=float(abs(p_raw_min-elem[:,1].min())),
                           EX_max_abs_difference=float(abs(ex_raw_max-elem[:,2].max())),
                           EX_min_abs_difference=float(abs(ex_raw_min-elem[:,3].min()))))
        if identities:
            tools,complete=_contact_state(folder,state,metadata,u,identities,bytool,pen,pressure)
            states[state]['tools']=tools
            states[state]['contact_records_complete']=complete
            states[state]['contact_identity_verified']=True
            states[state]['all_tools_independently_open']=all(t['independently_open_by_geometry_and_RF'] for t in tools.values())
    press=history[np.isclose(history[:,1],metadata['state_stages']['C'])]
    if not len(press):
        raise ValueError('Corrective loading history is absent')
    extrema=np.concatenate(ext)
    maxweak=float(4*c['weak_spring_N_per_mm']*np.max(abs(history[:,6])))
    zero={}
    for a,b in [('B','C0'),('B','D'),('C0','D')]:
        zero[f'{a}_{b}_axis_max_abs_difference_mm']=float(np.max(abs(axes[a]-axes[b])))
        zero[f'{a}_{b}_node_U_max_abs_difference_mm']=float(np.max(abs(node_u[a]-node_u[b])))
        zero[f'{a}_{b}_p_max_abs_difference']=_difference(p_records[a],p_records[b])
        zero[f'{a}_{b}_SX_max_abs_difference_MPa']=_difference(sx_records[a],sx_records[b])
    finite_pen=[v['max_contact_penetration_mm'] for v in states.values() if v['max_contact_penetration_mm'] is not None]
    prebend=history[np.isclose(history[:,1],1)]
    if not len(prebend):
        raise ValueError('Pre-bend loading history is absent')
    peak_prebend=float(4*np.max(abs(prebend[:,5])))
    final_tool_force=max(abs(states['D'][k]) for k in ('punch_force_N','support_force_N','prebend_head_force_N','prebend_support_force_N'))
    result=dict(model_version=metadata['model_version'], initial_error_mm=states['B']['error_fixed_260_mm'],
                final_error_mm=states['D']['error_fixed_260_mm'],
                initial_full_error_mm=states['B']['error_full_length_mm'], final_full_error_mm=states['D']['error_full_length_mm'],
                peak_press_force_N=float(4*np.max(abs(press[:,4]))), final_press_force_N=abs(states['D']['punch_force_N']),
                peak_prebend_force_N=peak_prebend, final_support_force_N=abs(states['D']['support_force_N']),
                final_max_abs_tool_force_N=float(final_tool_force),
                max_ip_accumulated_plastic_strain=float(extrema[:,0].max()),
                max_abs_ip_axial_total_strain=float(max(abs(extrema[:,2]).max(),abs(extrema[:,3]).max())),
                weak_spring_max_force_N=maxweak,
                weak_spring_max_force_over_prebend_force=maxweak/peak_prebend if peak_prebend>0 else None,
                max_contact_penetration_mm=max(finite_pen) if finite_pen else None,
                first_contact_geometry=dict(support_center_y_mm=float(touch[0]),punch_center_y_mm=float(touch[1]),
                support_UY_mm=float(touch[2]),punch_UY_mm=float(touch[3]),support_candidate_count=int(touch[4]),punch_candidate_count=int(touch[5])),
                states=states, zero_stroke_checks=zero, history_row_count=len(history),
                raw_IP_coverage_complete=True,
                raw_extrema_crosscheck_passed=all(v['extrema_crosscheck_passed'] for v in states.values()),
                raw_contact_coverage_complete=all(v['contact_records_complete'] for v in states.values()),
                quality_definition=dict(shape='Q4 area-centroid axis distance to end chord of fixed reference +/-130 mm interval',
                plasticity='NL EPEQ accumulated effective plastic strain, ERESX NO copied IP extrema',
                axial_strain='global EPTO X extrema at A/B/C0/C/D; other substep strain extrema not exported',
                force=f'maximum absolute central-punch RFY across every saved stage-{metadata["state_stages"]["C"]} substep, quarter reaction times four',
                contact='PRESOL CONT PENE/PRES unaveraged contact-node records; missing output is null',
                weak='one UY-only COMBIN14; full-domain symmetry multiplier four',
                symmetry='exact X=0/Z=0 reflection; asymmetric instability excluded', gravity='ignored'))
    result['quality_definition']['section_area']=metadata.get('centroid_area_basis','projected Y-Z area, legacy RECT3D001/002')
    if identities:
        result['contact_identity_verified']=True
        result['initial_all_tools_open']=states['B']['all_tools_independently_open']
        result['final_all_tools_open']=states['D']['all_tools_independently_open']
        result['final_max_tool_force_vector_bound_N']=max(t['four_times_quarter_force_norm_N'] for t in states['D']['tools'].values())
        result['quality_definition']['contact']='Actual EID/REAL/four-node mapping; available PRESOL point records only. Full-contact ETABLE STAT MAX and PENE/PRES element averages have separate availability flag. All-tools-open independently checked by positive analytic nodal gaps and zero quarter RF vectors.'
    if c.get('save_full_strain_trajectory'):
        trajectory=_load(folder/'strain_history.txt',5,len(history))
        if not np.allclose(trajectory[:,:3],history[:,:3],rtol=0,atol=1e-10):raise ValueError('Trajectory SET/time coverage does not match every saved converged substep')
        available=_listing_available(folder/'strain_history_log.txt')
        checkpoint_errors={}
        for state,step in metadata['state_stages'].items():
            row=trajectory[np.isclose(trajectory[:,1],step)][-1]
            expected=states[state]['extrema_crosscheck']
            checkpoint_errors[state]=max(abs(float(row[3])-expected['raw_EX_max']),abs(float(row[4])-expected['raw_EX_min']))
        verified=bool(available and max(checkpoint_errors.values())<=1e-10)
        result['strain_trajectory']=dict(requested=True,converged_substeps=len(trajectory),
                expected_solid_elements_each_set=ne,field_availability_log_passed=available,
                checkpoint_errors=checkpoint_errors,checkpoint_extrema_verified=verified,
                max_abs_axial_total_strain=float(np.max(abs(trajectory[:,3:5]))),
                min_axial_total_strain=float(np.min(trajectory[:,4])),max_axial_total_strain=float(np.max(trajectory[:,3])),
                basis='ERESX NO global EPTO X ETABLE MAX/MIN over all workel at every converged SET; EPEL+EPPL saved each substep. Raw copied-IP identities and extrema crosschecked at five key states, intermediate SET per-point text is not exported.')
        if not verified:raise ValueError('Full strain trajectory extraction unavailable or checkpoint mismatch')
        result['max_abs_ip_axial_total_strain']=result['strain_trajectory']['max_abs_axial_total_strain']
        result['quality_definition']['axial_strain']=result['strain_trajectory']['basis']
    else:
        result['strain_trajectory']=dict(requested=False,basis='Five key states only; does not prove all-path strain envelope')
    return result
