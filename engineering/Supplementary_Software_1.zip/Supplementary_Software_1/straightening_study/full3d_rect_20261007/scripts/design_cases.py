"""Reproducible parameter design only: no FE, ML, backups, or archives.

Pilot tables contain 24 distinct conditions including the base and eight
representatives. Formal CSV generation is locked until an explicit gate receipt
matches the current protocol SHA256 and all required checks pass.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path
import random
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_PROTOCOL = ROOT / "protocol" / "protocol_v002.json"
FEATURES = (
    "b_mm", "h_mm", "support_span_mm", "punch_radius_mm",
    "support_radius_mm", "prebend_tool_stroke_mm",
)
FIXED_FIELDS = (
    "length_mm", "prebend_outer_span_mm", "prebend_inner_span_mm",
    "prebend_radius_mm",
)
FIELDS = (
    "case_id", "phase", "design_role", "pilot_case_id", "protocol_version",
    "material_version", *FEATURES, *FIXED_FIELDS,
    "width_to_thickness", "straightening_span_to_thickness",
    "punch_radius_to_thickness", "support_radius_to_thickness",
    "prebend_stroke_to_thickness", "design_parameter_sha256",
)


def load_protocol(path: Path | str = DEFAULT_PROTOCOL) -> dict[str, Any]:
    with Path(path).open("r", encoding="utf-8-sig") as stream:
        protocol = json.load(stream)
    spec = {item["name"]: item for item in protocol["variable_inputs"]}
    if set(spec) != set(FEATURES):
        raise ValueError("Protocol must define the declared six independent input fields.")
    for name in FEATURES:
        if not float(spec[name]["minimum"]) < float(spec[name]["maximum"]):
            raise ValueError(f"Invalid physical range for {name}")
    if protocol["user_constraints"]["machine_learning_training"]:
        raise ValueError("This project is a data-generation project without ML training.")
    return protocol


def sha256_file(path: Path | str) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _bounds(protocol: dict[str, Any]) -> dict[str, tuple[float, float]]:
    return {
        item["name"]: (float(item["minimum"]), float(item["maximum"]))
        for item in protocol["variable_inputs"]
    }


def _physical_values(row: dict[str, Any]) -> tuple[float, ...]:
    return tuple(round(float(row[name]), 6) for name in FEATURES)


def _record(values: dict[str, float], case_id: str, role: str,
            phase: str, protocol: dict[str, Any], pilot_case_id: str = "") -> dict[str, Any]:
    limits = _bounds(protocol)
    physical = {name: round(float(values[name]), 6) for name in FEATURES}
    for name, value in physical.items():
        low, high = limits[name]
        if not low - 1e-9 <= value <= high + 1e-9:
            raise ValueError(f"{case_id}: {name}={value} outside [{low}, {high}]")
    fixed = {name: float(protocol["fixed_geometry"][name]) for name in FIXED_FIELDS}
    if physical["support_span_mm"] >= fixed["length_mm"]:
        raise ValueError("Straightening support centers must lie inside the bar length.")
    key_data = {
        "physical_inputs": physical,
        "fixed_geometry": fixed,
        "material_parameter_sha256": protocol["material"]["parameter_source_sha256"],
        "controlled_history": "public-type four-point prebend, unload, reverse three-point straightening",
    }
    key = hashlib.sha256(json.dumps(key_data, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    h = physical["h_mm"]
    return {
        "case_id": case_id, "phase": phase, "design_role": role,
        "pilot_case_id": pilot_case_id, "protocol_version": protocol["protocol_version"],
        "material_version": protocol["material"]["version"],
        **physical, **fixed,
        "width_to_thickness": round(physical["b_mm"] / h, 9),
        "straightening_span_to_thickness": round(physical["support_span_mm"] / h, 9),
        "punch_radius_to_thickness": round(physical["punch_radius_mm"] / h, 9),
        "support_radius_to_thickness": round(physical["support_radius_mm"] / h, 9),
        "prebend_stroke_to_thickness": round(physical["prebend_tool_stroke_mm"] / h, 9),
        "design_parameter_sha256": key,
    }


def _lhs(n: int, protocol: dict[str, Any], seed: int) -> list[dict[str, float]]:
    """Independent random permutations plus jitter in each 6-D Latin stratum."""
    if n <= 0:
        return []
    generator = random.Random(seed)
    bounds = _bounds(protocol)
    columns: dict[str, list[float]] = {}
    for name in FEATURES:
        cells = list(range(n))
        generator.shuffle(cells)
        low, high = bounds[name]
        columns[name] = [round(low + (high - low) * (cell + generator.random()) / n, 6) for cell in cells]
    return [{name: columns[name][i] for name in FEATURES} for i in range(n)]


def _representatives(protocol: dict[str, Any]) -> list[tuple[str, dict[str, float]]]:
    base = {name: float(protocol["base_condition"][name]) for name in FEATURES}
    bounds = _bounds(protocol)
    changes = [
        ("narrow", "b_mm", bounds["b_mm"][0]),
        ("wide", "b_mm", bounds["b_mm"][1]),
        ("thin", "h_mm", bounds["h_mm"][0]),
        ("thick", "h_mm", bounds["h_mm"][1]),
        ("short_straightening_span", "support_span_mm", bounds["support_span_mm"][0]),
        ("large_punch", "punch_radius_mm", bounds["punch_radius_mm"][1]),
        ("large_supports", "support_radius_mm", bounds["support_radius_mm"][1]),
        ("smaller_prebend", "prebend_tool_stroke_mm", bounds["prebend_tool_stroke_mm"][0]),
    ]
    return [(name, {**base, feature: value}) for name, feature, value in changes]


def generate_pilot(n: int = 24, *, protocol_path: Path | str = DEFAULT_PROTOCOL) -> list[dict[str, Any]]:
    """Return n pilot conditions: base + eight representatives + LHS remainder."""
    if n < 20 or n > 30:
        raise ValueError("Pilot must contain between 20 and 30 total distinct conditions.")
    protocol = load_protocol(protocol_path)
    records = [_record(protocol["base_condition"], "B0001", "base", "pilot", protocol)]
    for i, (role, values) in enumerate(_representatives(protocol), 1):
        records.append(_record(values, f"R{i:04d}", f"representative_{role}", "pilot", protocol))
    for i, values in enumerate(_lhs(n - len(records), protocol, int(protocol["design"]["pilot_seed"])), 1):
        records.append(_record(values, f"P{i:04d}", "lhs", "pilot", protocol))
    validate_records(records, expected_count=n)
    return records


def _formal_gate(protocol_path: Path | str, gate_path: Path | str | None = None) -> dict[str, Any]:
    protocol_path = Path(protocol_path)
    protocol = load_protocol(protocol_path)
    gate_path = Path(gate_path) if gate_path is not None else ROOT / protocol["gates"]["gate_receipt"]
    if not gate_path.is_file():
        raise RuntimeError(f"Formal design is locked: missing gate receipt {gate_path}")
    with gate_path.open("r", encoding="utf-8-sig") as stream:
        gate = json.load(stream)
    if gate.get("formal_generation_unlocked") is not True:
        raise RuntimeError("Formal design is locked: gate receipt does not unlock generation.")
    if gate.get("protocol_sha256") != sha256_file(protocol_path):
        raise RuntimeError("Formal design is locked: gate receipt does not match protocol SHA256.")
    if gate.get("protocol_version") != protocol["protocol_version"]:
        raise RuntimeError("Formal design is locked: gate receipt protocol version differs.")
    passes = gate.get("passes", {})
    missing = [name for name in protocol["gates"]["required_passes"] if passes.get(name) is not True]
    if missing:
        raise RuntimeError("Formal design is locked: unpassed gates " + ", ".join(missing))
    return gate


def _boundary_anchors(protocol: dict[str, Any]) -> list[tuple[str, dict[str, float]]]:
    bounds = _bounds(protocol)
    center = {name: (low + high) / 2 for name, (low, high) in bounds.items()}
    anchors: list[tuple[str, dict[str, float]]] = []
    for name in FEATURES:
        for side, value in zip(("low", "high"), bounds[name]):
            anchors.append((f"face_{name}_{side}", {**center, name: value}))
    # Eight contrasting corners change geometry ratios and history; they are
    # not homothetic copies of a single bar/setup.
    patterns = (
        (0, 0, 0, 0, 0, 0), (1, 1, 1, 1, 1, 1),
        (1, 0, 0, 1, 0, 1), (0, 1, 1, 0, 1, 0),
        (0, 1, 0, 1, 1, 1), (1, 0, 1, 0, 0, 0),
        (0, 0, 1, 1, 0, 1), (1, 1, 0, 0, 1, 0),
    )
    for i, pattern in enumerate(patterns, 1):
        anchors.append((f"corner_{i:02d}", {name: bounds[name][bit] for name, bit in zip(FEATURES, pattern)}))
    return anchors


def generate_design(n: int = 1500, *, protocol_path: Path | str = DEFAULT_PROTOCOL,
                    gate_path: Path | str | None = None) -> list[dict[str, Any]]:
    """Return formal planned candidates ONLY after the protocol-matched gates pass.

    Generating candidate parameters does not establish FE success or 1000 labels.
    Pilot conditions are included once, with pilot_case_id retained for reuse
    only if the runner also verifies identical material/mesh/contact/history.
    """
    protocol = load_protocol(protocol_path)
    _formal_gate(protocol_path, gate_path)
    if n < int(protocol["design"]["formal_minimum_complete_distinct_final_cases"]):
        raise ValueError("The formal candidate plan cannot contain fewer than the required 1000 final conditions.")
    values_and_roles: list[tuple[dict[str, float], str, str]] = []
    known: set[tuple[float, ...]] = set()
    for row in generate_pilot(int(protocol["design"]["pilot_total_cases"]), protocol_path=protocol_path):
        values = {name: float(row[name]) for name in FEATURES}
        known.add(_physical_values(values))
        values_and_roles.append((values, "pilot_reused_" + row["design_role"], row["case_id"]))
    for role, values in _boundary_anchors(protocol):
        key = _physical_values(values)
        if key not in known:
            known.add(key)
            values_and_roles.append((values, role, ""))
    remaining = n - len(values_and_roles)
    if remaining < 0:
        raise ValueError("Requested design is smaller than its mandatory anchors.")
    for values in _lhs(remaining, protocol, int(protocol["design"]["formal_seed"])):
        key = _physical_values(values)
        if key in known:
            raise ValueError("Rounded LHS duplicated an existing condition; change recorded design seed/range version.")
        known.add(key)
        values_and_roles.append((values, "lhs", ""))
    records = [_record(values, f"C{i:06d}", role, "formal_candidate", protocol, pilot_id)
               for i, (values, role, pilot_id) in enumerate(values_and_roles, 1)]
    validate_records(records, expected_count=n)
    return records


def validate_records(records: list[dict[str, Any]], *, expected_count: int) -> None:
    if len(records) != expected_count:
        raise ValueError("Unexpected condition count.")
    if len({row["case_id"] for row in records}) != len(records):
        raise ValueError("Duplicate case IDs.")
    if len({_physical_values(row) for row in records}) != len(records):
        raise ValueError("Duplicate physical conditions; duplicate runs do not add data rows.")
    if len({row["design_parameter_sha256"] for row in records}) != len(records):
        raise ValueError("Duplicate physical-input fingerprint.")
    for name in FEATURES:
        if len({row[name] for row in records}) < 2:
            raise ValueError(f"Input {name} never varies.")
    for group in ("width_to_thickness", "straightening_span_to_thickness",
                  "punch_radius_to_thickness", "support_radius_to_thickness"):
        if len({row[group] for row in records}) < 2:
            raise ValueError("The plan degenerates into only proportional geometry copies.")


def _csv_text(records: list[dict[str, Any]]) -> str:
    import io
    stream = io.StringIO(newline="")
    writer = csv.DictWriter(stream, fieldnames=FIELDS, lineterminator="\n")
    writer.writeheader()
    writer.writerows(records)
    return stream.getvalue()


def write_csv(path: Path | str, records: list[dict[str, Any]]) -> None:
    """Create a table or verify its exact reproduction; never overwrite changed data."""
    path = Path(path)
    content = _csv_text(records)
    if path.exists():
        if path.read_text(encoding="utf-8-sig") != content:
            raise FileExistsError(f"Refusing to overwrite differing original table: {path}")
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8-sig", newline="") as stream:
        stream.write(content)


def _write_json_once(path: Path, value: dict[str, Any]) -> None:
    content = json.dumps(value, ensure_ascii=False, indent=2) + "\n"
    if path.exists():
        if path.read_text(encoding="utf-8-sig") != content:
            raise FileExistsError(f"Refusing to overwrite differing original metadata: {path}")
        return
    with path.open("x", encoding="utf-8", newline="") as stream:
        stream.write(content)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("phase", choices=("pilot", "formal"))
    parser.add_argument("--protocol", type=Path, default=DEFAULT_PROTOCOL)
    parser.add_argument("--gate", type=Path)
    parser.add_argument("--n", type=int)
    parser.add_argument("--out", type=Path, default=ROOT / "protocol")
    args = parser.parse_args()
    protocol = load_protocol(args.protocol)
    args.out.mkdir(parents=True, exist_ok=True)
    if args.phase == "pilot":
        n = args.n if args.n is not None else int(protocol["design"]["pilot_total_cases"])
        records = generate_pilot(n, protocol_path=args.protocol)
        write_csv(args.out / "pilot_cases.csv", records)
        write_csv(args.out / "base_condition.csv", [row for row in records if row["design_role"] == "base"])
        write_csv(args.out / "representative_cases.csv", [row for row in records if row["design_role"].startswith("representative_")])
        receipt = {
            "phase": "pilot_design_only_no_solver",
            "protocol_version": protocol["protocol_version"],
            "protocol_sha256": sha256_file(args.protocol),
            "generator_sha256": sha256_file(__file__),
            "seed": protocol["design"]["pilot_seed"],
            "distinct_total_conditions": len(records),
            "base_conditions": 1,
            "representative_conditions": len(_representatives(protocol)),
            "lhs_conditions": len(records) - 1 - len(_representatives(protocol)),
            "formal_candidates_generated": False,
            "solver_started": False,
            "warning": "Parameter design is not FE completion and does not establish 1000 final labels."
        }
        _write_json_once(args.out / "pilot_design_receipt.json", receipt)
    else:
        n = args.n if args.n is not None else int(protocol["design"]["formal_planned_candidate_cases"])
        records = generate_design(n, protocol_path=args.protocol, gate_path=args.gate)
        write_csv(args.out / "formal_candidate_cases.csv", records)
        receipt = {
            "phase": "formal_candidate_design_only_no_solver",
            "protocol_version": protocol["protocol_version"],
            "protocol_sha256": sha256_file(args.protocol),
            "generator_sha256": sha256_file(__file__),
            "seed": protocol["design"]["formal_seed"],
            "distinct_candidate_conditions": len(records),
            "target_complete_final_conditions": protocol["design"]["formal_minimum_complete_distinct_final_cases"],
            "solver_started": False
        }
        _write_json_once(args.out / "formal_design_receipt.json", receipt)
    print(json.dumps(receipt, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
