"""Actual D-shape proposals followed by real FE and two-sided actual neighbours.

Import/reading does not launch Ansys. Execution is supplied explicitly by the
owner's callbacks. A numerical derivative remains an actual derivative input;
neither its generator plan nor an interpolated shape is execution evidence.
This module writes only one fresh diagnostic search directory, never labels.csv.
"""
from decimal import Decimal, ROUND_FLOOR
from pathlib import Path
import hashlib
import json
import math
import re
import traceback

import numpy as np
import rect_model as core
import search_cases as rules
import shape_candidate_proposer_v001 as shape
import stroke_search_engine_v001 as common
from solver_runner import ROOT, write_json

VERSION = 'ACTUAL_SHAPE_OPTIMIZED_SEARCH_V002'
FEATURES = ('b_mm', 'h_mm', 'support_span_mm', 'punch_radius_mm',
            'support_radius_mm', 'prebend_tool_stroke_mm')
DEFAULT_VARIANT = 'frozen_default'
MODES = common.MODES


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def json_sha(value):
    return common.json_sha(value)


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def number(value):
    return common.finite_number(value)


def invocation_count(trials, planned_count):
    counts = [record.get('newly_invoked_physical_FE_count') for record in trials]
    return (sum(counts) if len(counts) == planned_count
            and all(type(count) is int and count >= 0 for count in counts) else None)


def variant_id(value):
    return value if isinstance(value, str) else value.get('variant') if isinstance(value, dict) else None


def check_hashes(sources):
    if not isinstance(sources, dict):
        raise ValueError('Evidence/source pins must be an explicit path-to-SHA dictionary.')
    for name, expected in sources.items():
        path = Path(name)
        if not path.is_absolute() or not common.digest(expected) or sha(path) != expected:
            raise ValueError('Source/evidence pin is missing or changed: ' + str(path))


def validate_contract(contract, mode):
    """Registration evidence is method-only, never production qualification."""
    if not isinstance(contract, dict) or mode not in MODES:
        raise ValueError('An explicit cold/warm execution contract is required.')
    kind = 'independent_C0' if mode == 'warm_multiframe_continuation' else 'cold_full_history'
    if contract.get('history_kind') != kind or contract.get('diagnostic_only') is not True:
        raise ValueError('The independent initial history and diagnostic-only scope are mandatory.')
    variant = contract.get('numerical_variant_id')
    if not isinstance(variant, str) or not variant:
        raise ValueError('A named numerical variant is required.')
    if type(contract.get('actual_method_verified')) is not bool:
        raise ValueError('Method verification must be an explicit boolean.')
    check_hashes(contract.get('source_pins'))
    evidence = contract.get('method_evidence')
    if not isinstance(evidence, list):
        raise ValueError('Actual method evidence must be an explicit immutable receipt list.')
    for item in evidence:
        if not isinstance(item, dict):
            raise ValueError('Invalid method receipt descriptor.')
        check_hashes({item['path']: item['sha256']})
    if mode == 'warm_multiframe_continuation' or variant != DEFAULT_VARIANT:
        if contract['actual_method_verified'] is not True or not evidence:
            raise ValueError('Untested restart/numerical variants cannot execute this search.')
    return variant


def validate_plan(plan, mode, stroke, contract):
    common.validate_plan(plan, mode, stroke)
    if variant_id(plan.get('numerical_variant', DEFAULT_VARIANT)) != contract['numerical_variant_id']:
        raise ValueError('Actual candidate numerical variant differs from registration.')
    if contract['numerical_variant_id'] != DEFAULT_VARIANT:
        lineage = plan.get('native_derivation_lineage', {})
        if (lineage.get('actual_derived_input_sha256') != plan['executed_input_sha256']
                or variant_id(lineage) != contract['numerical_variant_id']
                or not common.digest(lineage.get('original_generator_plan_input_sha256'))
                or lineage.get('original_generator_plan_is_execution_evidence') is not False
                or not common.digest(lineage.get('variant_source_sha256'))):
            raise ValueError('Derived actual input and non-executed generator plan must remain distinct.')


def validate_record(record, plan, mode, config, contract):
    common.validate_record(record, plan, mode, config['case_id'], sha(core.__file__))
    expected = contract['numerical_variant_id']
    if variant_id(record.get('numerical_variant', DEFAULT_VARIANT)) != expected:
        raise ValueError('Actual receipt numerical variant differs from registration.')
    if expected != DEFAULT_VARIANT:
        if variant_id(plan['native_derivation_lineage']) != expected:
            raise ValueError('Native derivative lineage identifies a different numerical variant.')
        if record.get('native_derivation_lineage') != plan.get('native_derivation_lineage'):
            raise ValueError('Actual numerical-input lineage differs from the planned derivative.')
        if record['accepted_solver'] and record['parsed']:
            audit = record.get('actual_control_audit', {})
            if audit.get('passed') is not True:
                raise ValueError('Actual derived numerical controls were not independently audited.')


def validate_proof(proof, record):
    """Owner callback verifies actual schema/solver/header/history, not just J."""
    if not isinstance(proof, dict):
        raise ValueError('Backend must return an explicit actual execution/failure proof.')
    check_hashes(proof.get('sources'))
    path = proof.get('actual_receipt_path')
    if not isinstance(path, str):
        raise ValueError('The unchanged original actual or failed receipt must be identified.')
    check_hashes({path: proof.get('actual_receipt_sha256')})
    if record['accepted_solver'] and record['parsed']:
        if any(proof.get(key) is not True for key in
               ('execution_evidence_verified', 'independent_initial_history_verified', 'numerical_variant_verified')):
            raise ValueError('Actual solver/history/numerical evidence has not been verified.')
    elif proof.get('candidate_failure_recorded') is not True:
        raise ValueError('An isolated rejected candidate needs its preserved failure receipt.')


def verify_coordinates(text, *, warm, metadata_outer, record, source_paths):
    coordinates = [line.strip().replace(' ', '') for line in text.splitlines() if re.match(r'^\s*rsys\s*,', line)]
    if not coordinates or any(line != 'rsys,0' for line in coordinates):
        raise ValueError('Actual D global coordinate/export convention is unverified.')
    if 'eresx,no' in text.splitlines():
        return 'explicit actual candidate input'
    if not warm:
        raise ValueError('Actual cold ERESX NO convention is unverified.')
    # A continuation does not repeat the preprocessing command. It must have
    # the executed immutable C0 input and the verified restored full history.
    base_input = Path(metadata_outer['base_folder']).resolve() / 'input.inp'
    if (sha(base_input) != metadata_outer.get('base_input_sha256')
            or sha(base_input) != record.get('base_executed_input_sha256')):
        raise ValueError('Restored actual C0 input identity differs from the branch metadata/receipt.')
    base_text = base_input.read_text(encoding='ascii').lower().replace('\r\n', '\n')
    if 'eresx,no' not in base_text.splitlines():
        raise ValueError('Executed C0 did not establish the inherited ERESX NO convention.')
    source_paths['actual_C0_input'] = base_input
    return 'executed immutable C0 input; independent full-history restoration verified by owner'


def read_actual_profile(receipt_path, *, record=None, execution_proof=None,
                        numerical_variant_id=DEFAULT_VARIANT):
    """Reconstruct D from original nodes for cold, warm, or numerical derivatives.

For warm/derived receipts the normalized record and owner validation proof are
required. The receipt's original mode/schema/lineage are preserved in `parent`.
No generic receipt conversion grants a method, material, or formal gate.
"""
    path = Path(receipt_path).resolve()
    raw = read(path)
    if record is None:
        # Strict existing reader establishes genuine old cold evidence. This
        # convenience API is for read-only diagnostics, not execution approval.
        if path.name != 'trial_result.json' or raw.get('execution_mode') not in (None, 'cold_full_history'):
            raise ValueError('Warm/derived reading requires an explicit normalized record and execution proof.')
        if numerical_variant_id != DEFAULT_VARIANT:
            raise ValueError('A derivative cannot be inferred from an old cold receipt.')
        profile = shape.load_actual_profile(path)
        profile['parent']['receipt_execution_mode'] = raw.get('execution_mode')
        profile['parent']['normalized_execution_mode'] = 'cold_full_history'
        profile['parent']['numerical_variant_id'] = DEFAULT_VARIANT
        return profile
    validate_proof(execution_proof, record)
    if variant_id(record.get('numerical_variant', DEFAULT_VARIANT)) != numerical_variant_id:
        raise ValueError('Profile numerical identity differs from its actual normalized receipt.')
    if Path(execution_proof['actual_receipt_path']).resolve() != path:
        raise ValueError('Actual execution proof refers to a different receipt.')
    valid, why = rules.admissibility(record)
    if not valid or record.get('software_mock') or raw.get('software_mock'):
        raise ValueError('Shape parent is not actual/admissible: ' + why)
    folder = path.parent
    directory = Path(record['directory'])
    if (directory if directory.is_absolute() else ROOT / directory).resolve() != folder:
        raise ValueError('Normalized record and original output directory differ.')
    if (raw.get('accepted_solver') is not True or raw.get('parsed') is not True
            or raw.get('input_sha256') != record['input_sha256'] or raw.get('metrics') != record['metrics']):
        raise ValueError('Normalized quantities differ from the original actual receipt.')
    warm = record['execution_mode'] == 'warm_multiframe_continuation'
    metadata_path = folder / ('warm_metadata.json' if warm else 'model_metadata.json')
    outer = read(metadata_path)
    metadata = outer['core_metadata'] if warm else outer
    paths = {'input': folder / 'input.inp', 'status': folder / 'solver_status.json',
             'nodes': folder / 'state_D_nodes.txt', 'metadata': metadata_path}
    status = read(paths['status'])
    if status != record['solver_status'] or sha(paths['input']) != record['input_sha256']:
        raise ValueError('Original actual input/status differs from the normalized receipt.')
    physical_sha = sha(core.__file__)
    if record['model_source_sha256'] != physical_sha:
        raise ValueError('Physical core source is not the actual frozen parser source.')
    if (metadata.get('model_version') != core.VERSION or metadata.get('evaluation_interval_mm') != 260.
            or metadata.get('dimension') != '3D quarter: exact X=0 and Z=0 symmetry'
            or metadata.get('centroid_area_basis') != 'true 3D Q4 surface: norm(cross(dX/dxi,dX/deta)); 3x3 Gauss'
            or metadata.get('mesh_order') != 'node=1+(i*(ny+1)+j)*(nz+1)+k; element i,j,k lexicographic'
            or metadata.get('state_stages') != core.STAGES):
        raise ValueError('Unsupported D/reference/true-3D area/mesh convention.')
    config = metadata['config']
    stroke = record['stroke_mm']
    if not number(stroke) or stroke < 0 or config.get('stroke_mm') != stroke:
        raise ValueError('Actual metadata and receipt stroke differ.')
    material = Path(metadata['material_file'])
    if sha(material) != metadata.get('material_sha256'):
        raise ValueError('Original material-card source changed.')
    text = paths['input'].read_text(encoding='ascii').lower().replace('\r\n', '\n')
    convention_source = verify_coordinates(text, warm=warm, metadata_outer=outer, record=record, source_paths=paths)
    nn = metadata['mesh_count']['work_nodes']
    if type(nn) is not int or nn <= 0:
        raise ValueError('Invalid actual work-node count.')
    export = (f"set,{core.STAGES['D']},last\nallsel,all\n*dim,ud,array,{nn},3\n*vlen,{nn}\n"
              '*vget,ud(1,1),node,1,u,x\n*vget,ud(1,2),node,1,u,y\n'
              '*vget,ud(1,3),node,1,u,z\n*cfopen,state_d_nodes,txt\n')
    if text.count(export) != 1:
        raise ValueError('Original D SET/XYZ/work-node order export is unverified.')
    refs = np.asarray(metadata['x_mm'], dtype=float)
    if refs.ndim != 1 or not len(refs) or not np.isfinite(refs).all() or refs[0] != 0. or not np.all(np.diff(refs) > 0):
        raise ValueError('Invalid original material section keys.')
    nodes = core._load(paths['nodes'], 3, nn)
    axis, areas = core._centroid_axis(nodes, metadata)
    saved = record['metrics']['states']['D']
    if (not np.array_equal(refs, np.asarray(saved['axis_reference_x_mm']))
            or np.asarray(saved['axis_xyz_mm']).shape != axis.shape
            or not np.allclose(axis, saved['axis_xyz_mm'], atol=1e-10, rtol=0.)
            or not np.allclose(areas, saved['section_area_mm2'], atol=1e-10, rtol=0.)):
        raise ValueError('Original D nodes and saved actual area-centroid profile differ.')
    full_refs, residual, measured = shape._residual_vectors(axis, refs)
    if (not number(saved.get('error_fixed_260_mm'))
            or abs(measured-saved['error_fixed_260_mm']) > 1e-10
            or abs(measured-record['metrics']['final_error_mm']) > 1e-10):
        raise ValueError('Original D geometry differs from the measured actual J.')
    physical = {k: v for k, v in config.items() if k not in ('case_id', 'stroke_mm')}
    identity = dict(physical_config=physical, material_sha256=metadata['material_sha256'],
                    physical_model_source_sha256=physical_sha, numerical_variant_id=numerical_variant_id,
                    execution_mode=record['execution_mode'], RSYS=0, ERESX='NO',
                    reference_half_interval_mm=130., section_area_basis=metadata['centroid_area_basis'],
                    mesh={k: metadata[k] for k in ('x_mm', 'y_mm', 'z_mm', 'mesh_count', 'mesh_order')})
    if warm:
        identity['actual_base_C0_input_sha256'] = record['base_executed_input_sha256']
        identity['actual_checkpoint_key_sha256'] = record.get('checkpoint_key_sha256')
    sources = {str(path): sha(path), **{str(p): sha(p) for p in paths.values()},
               str(material): sha(material), str(Path(core.__file__).resolve()): physical_sha,
               **execution_proof['sources']}
    keys = json_sha(dict(reference_x_mm=full_refs.tolist(), original_node_order=metadata['mesh_order'], mesh=identity['mesh']))
    residual.setflags(write=False)
    return dict(stroke_mm=float(stroke), residual_vectors_mm=residual,
                profile_identity_sha256=json_sha(identity), profile_keys_sha256=keys,
                parent=dict(record_path=str(path), actual_input_sha256=record['input_sha256'],
                            receipt_execution_mode=raw.get('execution_mode'), normalized_execution_mode=record['execution_mode'],
                            numerical_variant_id=numerical_variant_id, actual_D_error_mm=measured,
                            ERESX_convention_source=convention_source,
                            section_count=len(full_refs), profile_identity_sha256=json_sha(identity),
                            profile_keys_sha256=keys, residual_vectors_sha256=json_sha(residual.tolist()), sources=sources))


def propose_profiles(left, right, *, sampled_strokes_mm, failed_strokes_mm):
    """Pure suggestion: interpolation/root is never an actual label or J."""
    result = dict(version=VERSION, stroke_or_None=None, suggestion_only=True,
                  candidate_evaluated_by_FE=False, candidate_actual_J_mm=None,
                  parents=[], qualified_for_formal_dataset=False)
    try:
        parents = sorted((left, right), key=lambda p: p['stroke_mm'])
        a, b = parents
        low, high = a['stroke_mm'], b['stroke_mm']
        if any(not number(x) or x < 0 for x in (*sampled_strokes_mm, *failed_strokes_mm)):
            raise ValueError('Finite actual sampled/rejected stroke ledger is required.')
        if not low < high or any(low <= s <= high for s in failed_strokes_mm):
            raise ValueError('Parent interval is empty or crosses a failed/material-rejected point.')
        if low not in sampled_strokes_mm or high not in sampled_strokes_mm:
            raise ValueError('Actual parents must belong to the current preserved candidate ledger.')
        if a['profile_identity_sha256'] != b['profile_identity_sha256'] or a['profile_keys_sha256'] != b['profile_keys_sha256']:
            raise ValueError('Parent physical/numerical/history/section identities differ.')
        result['parents'] = [p['parent'] for p in parents]
        t, value, f0, f1 = shape._convex_minimum(a['residual_vectors_mm'], b['residual_vectors_mm'])
        s = round(low+t*(high-low), 6)
        result['trace'] = dict(parent_interval_mm=[low, high], t=t,
                              method='linear actual signed XYZ section residuals; convex maximum norm',
                              interpolated_objective_mm=value, interpolated_endpoint_objectives_mm=[f0, f1],
                              interpolation_is_execution_evidence=False)
        if not low < s < high or s in sampled_strokes_mm:
            raise ValueError('Rounded proposal is outside parents or already evaluated.')
        if value >= min(f0, f1)-1e-12*max(1., f0, f1):
            raise ValueError('No strict interior interpolated improvement; midpoint fallback.')
        result.update(stroke_or_None=s, reason='Suggestion only; real FE and real two-sided neighbours are required.')
    except (ValueError, TypeError, KeyError, IndexError, FloatingPointError) as error:
        result['reason'] = str(error)
    return result


def verified_neighbours(stroke, low, high, resolution=.02):
    """Only propose points, bounded by real parents; neither point is fabricated."""
    if any(not number(x) for x in (stroke, low, high, resolution)) or not low < stroke < high or resolution < 2e-6:
        raise ValueError('Finite strictly internal proposal and usable resolution are required.')
    half = math.floor(resolution*500000.)/1000000.
    points = (round(stroke-half, 6), round(stroke+half, 6))
    return [s for s in points if low < s < high and s != stroke]


def hole_free_neighborhood(near, cache):
    """An admissible-list neighbour must not bridge a known failed/domain hole."""
    if near is None:
        return None
    result = dict(near)
    left, right = result.get('left_mm'), result.get('right_mm')
    holes = [] if left is None or right is None else [s for s, record in cache.items()
              if left <= s <= right and not rules.admissibility(record)[0]]
    result['known_rejected_strokes_inside_mm'] = sorted(holes)
    if holes:
        result.update(resolved=False, proposals=[], reason='Actual neighbourhood crosses known failure/material boundary.')
    return result


def identify_valleys(strokes, cache, prefix):
    """Consecutive actual triples only: never bridge inadmissible coarse points."""
    found = []
    ordered = sorted(strokes)
    for a, b, c in zip(ordered, ordered[1:], ordered[2:]):
        rows = [cache[s] for s in (a, b, c)]
        if not all(rules.admissibility(r)[0] for r in rows):
            continue
        fa, fb, fc = (r['metrics']['final_error_mm'] for r in rows)
        if fb <= fa and fb <= fc and fb < max(fa, fc):
            found.append(dict(valley_id=f'{prefix}_{a:.6f}_{b:.6f}_{c:.6f}', low_mm=a, high_mm=c,
                              screening_stroke_mm=b))
    return found


def material_domain_rejection(record):
    """Identify only domain failures with all other existing checks satisfied.

    A temporary scalar comparison does not alter the actual stored record. It
    tests whether there is an additional solver/contact/raw/force failure that
    the early-return material screen would otherwise hide.
    """
    if record.get('accepted_solver') is not True or record.get('parsed') is not True:
        return False
    metrics = record.get('metrics', {})
    p, axial = metrics.get('max_ip_accumulated_plastic_strain'), metrics.get('max_abs_ip_axial_total_strain')
    if not number(p) or not number(axial) or not (p > .0873690726826633+1e-8 or axial > .02+1e-8):
        return False
    diagnostic = {**record, 'metrics': {**metrics, 'max_ip_accumulated_plastic_strain': .0873690726826633,
                                       'max_abs_ip_axial_total_strain': .02}}
    return rules.admissibility(diagnostic)[0]


def frontier_interval(cache):
    """A bounded probe may refine a domain cutoff, never a solver/unknown hole."""
    usable = rules._usable(cache)
    if not usable:
        return None
    best = rules._best(usable)
    if best['stroke_mm'] != usable[-1]['stroke_mm']:
        return None
    low = best['stroke_mm']
    higher = sorted(s for s in cache if s > low)
    if not higher or not material_domain_rejection(cache[higher[0]]):
        return None
    high = higher[0]
    midpoint = round((low+high)/2., 6)
    if not low < midpoint < high or midpoint in cache:
        return None
    return dict(left_actual_stroke_mm=low, right_actual_domain_rejected_stroke_mm=high,
                left_actual_input_sha256=cache[low]['input_sha256'],
                right_actual_input_sha256=cache[high]['input_sha256'], proposed_stroke_mm=midpoint,
                domain_rejection_reason=rules.admissibility(cache[high])[1],
                monotonic_material_cutoff_assumed=False)


def refinement_statuses(coarse_valleys, cache, resolution):
    # Keep all original coarse regions, and every currently observed actual
    # local valley. Nested/multiple valleys are not represented by one winner.
    regions = [*coarse_valleys, *identify_valleys(cache, cache, 'actual')]
    statuses = []
    for region in regions:
        status = rules._valley_status(region, cache, resolution)
        status = {**status, **hole_free_neighborhood(status, cache)}
        statuses.append(status)
    return statuses


def search(config, *, plan_candidate, evaluate_candidate, check_sources,
           validate_execution, backend_contract, execution_mode, output_folder,
           upper=None, resolution=.02, max_trials=44, timeout=7200, screening_n=7,
           frontier_probe_limit=3):
    """Callbacks: plan(cfg,s), evaluate(cfg,s,timeout), check_sources(),
    validate_execution(record,plan)->proof. No callback runs on import.

    Explicit accepted/failed original receipts and their source pins are required.
    Unknown exceptions stop; isolated failures are returned as rejected records.
    The owner retains the serial solver guard and all actual runtime accounting.
    """
    if not all(callable(cb) for cb in (plan_candidate, evaluate_candidate, check_sources, validate_execution)):
        raise ValueError('All four explicit execution/source validation callbacks are required.')
    contract = json.loads(json.dumps(backend_contract, allow_nan=False))
    variant = validate_contract(contract, execution_mode)
    cfg = dict(config)
    if not isinstance(cfg.get('case_id'), str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,100}', cfg['case_id']):
        raise ValueError('A distinct simple string case identity is required.')
    if any(not number(cfg.get(key)) or cfg[key] <= 0 for key in FEATURES):
        raise ValueError('All six physical input features must be explicit finite positive values.')
    requested = upper if upper is not None else max(8., 1.6*cfg['prebend_tool_stroke_mm'])
    if not number(requested) or requested <= 0:
        raise ValueError('Finite positive physical search upper bound is required.')
    bound = float(Decimal(str(requested)).quantize(Decimal('0.000001'), rounding=ROUND_FLOOR))
    if (type(screening_n) is not int or screening_n != 7 or type(max_trials) is not int or not 7 <= max_trials <= 44
            or type(frontier_probe_limit) is not int or not 0 <= frontier_probe_limit <= 3
            or not number(resolution) or not 2e-6 <= resolution <= .02 or not number(timeout) or not 0 < timeout <= 32400
            or bound <= 0 or len(set(np.round(np.linspace(0., bound, 7), 6))) != 7):
        raise ValueError('Use seven distinct coarse points, <=44 candidates, <=.02 total width and finite timeout <=9h.')
    folder = Path(output_folder).resolve()
    if not folder.is_relative_to((ROOT / 'optimized_cases').resolve()) or folder.exists():
        raise FileExistsError('Use a fresh search folder under optimized_cases; existing evidence is protected.')
    sources = {str(Path(module.__file__).resolve()): sha(module.__file__) for module in (core, rules, shape, common)}
    sources[str(Path(__file__).resolve())] = sha(__file__)
    sources.update(contract['source_pins'])
    sources.update({item['path']: item['sha256'] for item in contract['method_evidence']})
    settings = dict(version=VERSION, execution_mode=execution_mode, requested_upper_mm=requested, upper_mm=bound,
                    resolution_mm=resolution, max_trials=max_trials, timeout_s=timeout, screening_n=7,
                    frontier_probe_limit=frontier_probe_limit, frontier_probes_count_toward_max_trials=True,
                    frontier_policy='highest legal actual minimum beside explicit material-only rejection; at most three bisections',
                    tie_error_mm=0., screening_noise_mm=0., numerical_variant_id=variant,
                    shape_policy='real proposal plus real local two-sided neighbours; all observed valleys; midpoint fallback')
    result = dict(case_id=cfg['case_id'], config=cfg, input_features={key: cfg[key] for key in FEATURES},
                  case_config_sha256=json_sha(cfg), search_version=VERSION, execution_mode=execution_mode,
                  backend_contract=contract, search_settings=settings, search_settings_sha256=json_sha(settings),
                  implementation_sources=sources, trials=[], candidate_plans=[], execution_proofs=[], shape_proposals=[],
                  frontier_probe_ledger=[],
                  observed_valleys=[], label=None, diagnostic_label=None, complete=False, search_acceptance_passed=False,
                  qualified_for_formal_dataset=False, formal_generation_unlocked=False, formal_restart_enabled=False,
                  global_optimum_proven=False, machine_learning_run=False, backup_created=False,
                  incompletion_reasons=[], candidate_requests=0, newly_invoked_physical_FE_count=None)
    cache, proofs, profiles, tried_parent_intervals = {}, {}, {}, set()
    folder.mkdir(parents=True)

    def intact():
        check_hashes(sources)
        validate_contract(contract, execution_mode)
        for proof in proofs.values():
            check_hashes(proof['sources'])
            check_hashes({proof['actual_receipt_path']: proof['actual_receipt_sha256']})
        check_sources()

    def save():
        result['candidate_requests'] = len(result['candidate_plans'])
        result['newly_invoked_physical_FE_count'] = invocation_count(result['trials'], len(result['candidate_plans']))
        write_json(folder / 'search_result.json', result)
        rows = []
        for record in result['trials']:
            valid, reason = rules.admissibility(record)
            rows.append({**record, **record.get('metrics', {}), 'admissible': valid,
                         'exclusion_reason': reason, 'record_origin': execution_mode,
                         'seconds': record.get('solver_status', {}).get('seconds')})
        rules.csv_dump(folder / 'candidate_curve.csv', rules.TRIAL_FIELDS, rows)
        failures = [dict(stroke_mm=r['stroke_mm'], actual_input_sha256=r['input_sha256'],
                         actual_receipt=proofs[r['stroke_mm']]['actual_receipt_path'],
                         exclusion_reason=rules.admissibility(r)[1], exception=r.get('exception'),
                         cause=r.get('cause', 'Unknown beyond the preserved actual evidence.'),
                         impact='Rejected candidate; no interpolated label and no crossing this known hole.')
                    for r in result['trials'] if not rules.admissibility(r)[0]]
        write_json(folder / 'candidate_failures.json', failures)

    def sample(value, origin):
        if not number(value):
            raise ValueError('Candidate must be finite, not bool/NaN.')
        s = round(value, 6)
        if not 0 <= s <= bound:
            raise ValueError('Candidate outside the frozen physical interval.')
        if s in cache or len(result['candidate_plans']) >= max_trials:
            return False
        intact()
        plan = plan_candidate(cfg, s)
        validate_plan(plan, execution_mode, s, contract)
        result['candidate_plans'].append({**plan, 'proposed_by': origin})
        save()  # Persist the real planned identity before invoking the backend.
        record = evaluate_candidate(cfg, s, timeout)
        intact()
        validate_record(record, plan, execution_mode, cfg, contract)
        proof = validate_execution(record, plan)
        validate_proof(proof, record)
        cache[s], proofs[s] = record, proof
        result['trials'].append(record)
        result['execution_proofs'].append(dict(stroke_mm=s, proof=proof))
        save()
        return True

    def profile(s):
        if s not in profiles:
            profiles[s] = read_actual_profile(proofs[s]['actual_receipt_path'], record=cache[s],
                                               execution_proof=proofs[s], numerical_variant_id=variant)
        check_hashes(profiles[s]['parent']['sources'])
        return profiles[s]

    def shape_proposal(status):
        low, high = status.get('left_mm'), status.get('right_mm')
        if low is None or high is None or (low, high) in tried_parent_intervals:
            return None
        tried_parent_intervals.add((low, high))
        rejected = [s for s, r in cache.items() if not rules.admissibility(r)[0]]
        try:
            suggestion = propose_profiles(profile(low), profile(high), sampled_strokes_mm=tuple(cache), failed_strokes_mm=rejected)
        except (OSError, ValueError, KeyError, TypeError, IndexError) as error:
            suggestion = dict(version=VERSION, stroke_or_None=None, suggestion_only=True,
                              candidate_evaluated_by_FE=False, candidate_actual_J_mm=None,
                              reason=str(error), parents=[])
        suggestion['refinement_region'] = status.get('valley_id', 'actual_selected_neighborhood')
        result['shape_proposals'].append(suggestion)
        save()
        return suggestion

    try:
        intact()
        coarse = [float(s) for s in np.round(np.linspace(0., bound, 7), 6)]
        result['coarse_screening_strokes_mm'] = coarse
        for s in coarse:
            sample(s, 'actual_seven_point_screening')
        result['initial_coarse_screening_valleys'] = identify_valleys(coarse, cache, 'coarse')
        augmented = list(coarse)
        for _ in range(frontier_probe_limit):
            if len(result['candidate_plans']) >= max_trials:
                break
            frontier = frontier_interval(cache)
            if frontier is None:
                break
            result['frontier_probe_ledger'].append(frontier)
            save()
            s = frontier['proposed_stroke_mm']
            sample(s, 'bounded_actual_material_domain_frontier')
            augmented.append(s)
            frontier.update(actual_input_sha256=cache[s]['input_sha256'],
                            actual_admissible=rules.admissibility(cache[s])[0],
                            actual_exclusion_reason=rules.admissibility(cache[s])[1])
            save()
        result['augmented_actual_screening_strokes_mm'] = sorted(augmented)
        coarse_valleys = identify_valleys(augmented, cache, 'screening')
        result['identified_screening_valleys'] = coarse_valleys
        result['coarse_screening_exclusions'] = [dict(stroke_mm=s, reason=rules.admissibility(cache[s])[1])
                                                for s in coarse if not rules.admissibility(cache[s])[0]]
        observed = set()
        while True:
            statuses = refinement_statuses(coarse_valleys, cache, resolution)
            for status in statuses:
                if status['valley_id'] not in observed:
                    observed.add(status['valley_id'])
                    result['observed_valleys'].append({k: status[k] for k in ('valley_id', 'low_mm', 'high_mm', 'screening_stroke_mm')})
            usable, raw, selected, raw_near, selected_near = rules._selection(cache, resolution, 0.)
            raw_near, selected_near = hole_free_neighborhood(raw_near, cache), hole_free_neighborhood(selected_near, cache)
            if not usable or len(result['candidate_plans']) >= max_trials:
                break
            if statuses and all(v['resolved'] for v in statuses) and raw_near['resolved'] and selected_near['resolved']:
                break
            created = False
            region_keys = set()
            for status in [*statuses, raw_near, selected_near]:
                if status is None or status['resolved'] or status.get('known_rejected_strokes_inside_mm'):
                    continue
                pair = (status.get('left_mm'), status.get('right_mm'))
                if pair in region_keys:
                    continue
                region_keys.add(pair)
                suggestion = shape_proposal(status)
                s = suggestion.get('stroke_or_None') if suggestion is not None else None
                if s is not None:
                    created = sample(s, 'actual_D_shape_suggestion') or created
                    if s in cache and rules.admissibility(cache[s])[0]:
                        # These are actual backend calls, not inferred neighbours.
                        # A smaller J at either side moves the minimum and keeps
                        # the larger-side neighbourhood unresolved next round.
                        for near in verified_neighbours(s, pair[0], pair[1], resolution):
                            created = sample(near, 'real_two_sided_shape_verification') or created
                else:
                    for midpoint in status.get('proposals', []):
                        created = sample(midpoint, 'actual_midpoint_fallback') or created
            if not created:
                break
        statuses = refinement_statuses(coarse_valleys, cache, resolution)
        usable, raw, selected, raw_near, selected_near = rules._selection(cache, resolution, 0.)
        raw_near, selected_near = hole_free_neighborhood(raw_near, cache), hole_free_neighborhood(selected_near, cache)
        reasons = []
        if not usable:
            reasons.append('no admissible actual FE candidates')
        if not coarse_valleys:
            reasons.append('no hole-free interior actual coarse-screening valley')
        if statuses and not all(v['resolved'] for v in statuses):
            reasons.append('one or more identified actual valleys remain unresolved')
        if selected is not None:
            if raw_near['boundary'] or selected_near['boundary']:
                reasons.append('minimum is at an actual sampled/material boundary')
            if raw_near.get('known_rejected_strokes_inside_mm') or selected_near.get('known_rejected_strokes_inside_mm'):
                reasons.append('actual selected bracket crosses a known failed/material-rejected candidate')
            if not raw_near['resolved'] or not selected_near['resolved']:
                reasons.append('actual two-sided total bracket has not reached <= declared .02mm resolution')
        if reasons and len(result['candidate_plans']) >= max_trials:
            reasons.append('actual candidate request budget exhausted')
        result.update(refined_valleys=statuses, raw_best_neighborhood=raw_near, selected_neighborhood=selected_near,
                      all_identified_valleys_resolved=bool(coarse_valleys) and all(v['resolved'] for v in statuses),
                      bracket_resolution_met=bool(selected is not None and raw_near['resolved'] and selected_near['resolved']),
                      search_boundary=bool(selected is not None and (raw_near['boundary'] or selected_near['boundary'])),
                      incompletion_reasons=reasons)
        if selected is not None:
            label = rules._label(cfg, selected, raw, selected_near, result, cache)
            label.update(search_version=VERSION, execution_mode=execution_mode, numerical_variant=selected.get('numerical_variant', DEFAULT_VARIANT),
                         native_derivation_lineage=selected.get('native_derivation_lineage'),
                         actual_control_audit=selected.get('actual_control_audit'),
                         executed_candidate_input_sha256=selected['input_sha256'],
                         actual_receipt_path=proofs[selected['stroke_mm']]['actual_receipt_path'],
                         actual_receipt_sha256=proofs[selected['stroke_mm']]['actual_receipt_sha256'],
                         qualified_for_formal_dataset=False, formal_qualification_pending_new_execution_mode_reader=True)
            for key in ('base_executed_input_sha256', 'normalized_full_cold_plan_sha256',
                        'normalized_full_cold_plan_is_execution_evidence', 'checkpoint_key_sha256'):
                if key in selected:
                    label[key] = selected[key]
            if reasons:
                result['diagnostic_label'] = label
            else:
                result.update(label=label, complete=True, search_acceptance_passed=True)
        intact()
    except Exception as error:
        result.update(exception=repr(error), traceback=traceback.format_exc(), complete=False,
                      search_acceptance_passed=False, label=None)
        result['incompletion_reasons'].append('shared/execution/source error; no complete label and no automatic retry')
    save()
    return result
