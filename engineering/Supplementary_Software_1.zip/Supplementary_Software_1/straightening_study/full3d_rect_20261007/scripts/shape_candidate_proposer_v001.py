"""Read-only shape interpolation proposes a stroke; it never evaluates FE or labels.

Both parents must be actual accepted/admissible trial receipts with their original
D-node exports. A missing/incompatible parent or an unusable proposal returns
None, so a future search adapter can retain its original midpoint proposal.
"""
from pathlib import Path
import hashlib
import json
import math
import re

import numpy as np
import rect_model as core
import search_cases as rules

VERSION = 'ACTUAL_D_SHAPE_CANDIDATE_V001'
HALF_INTERVAL_MM = 130.
ROOT = Path(__file__).resolve().parents[1]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def json_sha(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
                                    allow_nan=False).encode('utf-8')).hexdigest()


def _number(value):
    return type(value) in (int, float) and math.isfinite(value)


def _read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def _residual_vectors(axis, refs):
    """Same endpoint/ref mask as core._chord_error, plus exact X reflection."""
    hit = np.flatnonzero(np.isclose(refs, HALF_INTERVAL_MM, atol=1e-9))
    if len(hit) != 1:
        raise ValueError('Fixed reference +130 mm must be explicitly meshed once.')
    endpoint = axis[int(hit[0])]
    minus = endpoint * np.array([-1., 1., 1.])
    chord = endpoint - minus
    length = float(np.linalg.norm(chord))
    if not math.isfinite(length) or length <= 0:
        raise ValueError('Degenerate deformed fixed-reference chord.')
    mask = refs <= HALF_INTERVAL_MM + 1e-9
    positive_refs, positive = refs[mask], axis[mask]
    # X=0 occurs once. Every material section on [-130,+130] is retained.
    full_refs = np.concatenate((-positive_refs[:0:-1], positive_refs))
    full_axis = np.concatenate((positive[:0:-1] * [-1., 1., 1.], positive))
    delta = full_axis - minus
    unit = chord / length
    residual = delta - np.outer(delta @ unit, unit)
    measured = core._chord_error(axis, refs, HALF_INTERVAL_MM)
    if not math.isclose(float(np.max(np.linalg.norm(residual, axis=1))), measured,
                        rel_tol=0., abs_tol=1e-10):
        raise ValueError('Residual-vector construction disagrees with original J.')
    return full_refs, residual, measured


def load_actual_profile(record_path):
    """Read small original evidence only; no RST, POST, solver, or file writes.

    The caller may retain the returned profile for this search. The final FE
    label remains owned by the original backend/search/admissibility rules.
    """
    record_path = Path(record_path).resolve()
    folder = record_path.parent
    record = _read(record_path)
    if record.get('software_mock') or record.get('solver_status', {}).get('software_mock'):
        raise ValueError('Software fixtures are not actual FE parents.')
    if record.get('accepted_solver') is not True or record.get('parsed') is not True:
        raise ValueError('Parent is not an actual accepted and parsed trial.')
    valid, reason = rules.admissibility(record)
    if not valid:
        raise ValueError('Parent is inadmissible: ' + reason)
    directory = Path(record['directory'])
    if (directory if directory.is_absolute() else ROOT / directory).resolve() != folder:
        raise ValueError('Receipt directory differs from its raw evidence folder.')
    stroke = record.get('stroke_mm')
    if not _number(stroke) or stroke < 0:
        raise ValueError('Invalid actual parent stroke.')
    paths = {name: folder / name for name in
             ('model_metadata.json', 'input.inp', 'solver_status.json', 'state_D_nodes.txt')}
    status = _read(paths['solver_status.json'])
    tree = status.get('process_tree', {})
    identities = tree.get('identities', [])
    if (status.get('accepted_exit') is not True or type(status.get('returncode')) is not int
            or status['returncode'] != 0 or type(status.get('error_count')) is not int
            or status['error_count'] != 0 or status.get('timed_out') is not False
            or status.get('exception') is not None or tree.get('tree_exit_confirmed') is not True
            or not identities or tree.get('live_identities') != [] or tree.get('identity_errors') != []):
        raise ValueError('Actual solver completion/owned exit is not established.')
    for identity in identities:
        if (type(identity.get('pid')) is not int or identity['pid'] <= 0
                or not _number(identity.get('create_time')) or identity['create_time'] <= 0):
            raise ValueError('Invalid actual solver process identity.')
    input_sha = sha(paths['input.inp'])
    if input_sha != record.get('input_sha256') or input_sha != status.get('input_sha256'):
        raise ValueError('Original actual solver input SHA differs from the receipts.')
    if status != record.get('solver_status'):
        raise ValueError('Embedded and original native solver receipts differ.')
    source_sha = sha(core.__file__)
    if record.get('model_source_sha256') != source_sha:
        raise ValueError('Actual parser/model source differs from the current frozen core.')
    metadata = _read(paths['model_metadata.json'])
    if (metadata.get('model_version') != core.VERSION
            or metadata.get('evaluation_interval_mm') != 260.
            or metadata.get('dimension') != '3D quarter: exact X=0 and Z=0 symmetry'
            or metadata.get('centroid_area_basis') != 'true 3D Q4 surface: norm(cross(dX/dxi,dX/deta)); 3x3 Gauss'
            or metadata.get('mesh_order') != 'node=1+(i*(ny+1)+j)*(nz+1)+k; element i,j,k lexicographic'
            or metadata.get('state_stages') != core.STAGES):
        raise ValueError('Unsupported shape/reference/mesh-identity convention.')
    config = metadata['config']
    if config.get('stroke_mm') != stroke:
        raise ValueError('Actual stroke differs from original model metadata.')
    material = Path(metadata['material_file'])
    if sha(material) != metadata.get('material_sha256'):
        raise ValueError('Actual material-card source changed.')
    text = paths['input.inp'].read_text(encoding='ascii').lower().replace('\r\n', '\n')
    coordinates = [s.strip().replace(' ', '') for s in text.splitlines() if re.match(r'^\s*rsys\s*,', s)]
    if not coordinates or any(s != 'rsys,0' for s in coordinates) or 'eresx,no' not in text.splitlines():
        raise ValueError('Actual global RSYS=0 / ERESX NO convention is not verified.')
    nn = metadata['mesh_count']['work_nodes']
    export = (f"set,{core.STAGES['D']},last\nallsel,all\n*dim,ud,array,{nn},3\n*vlen,{nn}\n"
              '*vget,ud(1,1),node,1,u,x\n*vget,ud(1,2),node,1,u,y\n'
              '*vget,ud(1,3),node,1,u,z\n*cfopen,state_d_nodes,txt\n')
    if text.count(export) != 1:
        raise ValueError('Original D SET/global XYZ/node-order export is not verified.')
    refs = np.asarray(metadata['x_mm'], dtype=float)
    if not np.isfinite(refs).all() or refs.ndim != 1 or refs[0] != 0. or not np.all(np.diff(refs) > 0):
        raise ValueError('Invalid material section reference keys.')
    u = core._load(paths['state_D_nodes.txt'], 3, nn)
    axis, areas = core._centroid_axis(u, metadata)
    saved = record['metrics']['states']['D']
    if (not np.array_equal(refs, np.asarray(saved['axis_reference_x_mm']))
            or np.asarray(saved['axis_xyz_mm']).shape != axis.shape
            or not np.allclose(axis, saved['axis_xyz_mm'], rtol=0, atol=1e-10)
            or not np.allclose(areas, saved['section_area_mm2'], rtol=0, atol=1e-10)):
        raise ValueError('Saved centroid profile differs from original full XYZ node output.')
    full_refs, residual, measured = _residual_vectors(axis, refs)
    if not _number(saved.get('error_fixed_260_mm')) or not _number(record['metrics'].get('final_error_mm')):
        raise ValueError('Actual D deviation is not a finite numeric quantity.')
    if max(abs(measured-saved['error_fixed_260_mm']), abs(measured-record['metrics']['final_error_mm'])) > 1e-10:
        raise ValueError('Actual D geometry disagrees with saved J.')
    # case_id is a name, not physics. Every other config field is preserved.
    physical = {k: v for k, v in config.items() if k not in ('case_id', 'stroke_mm')}
    identity = dict(physical_config=physical, material_sha256=metadata['material_sha256'],
                    model_source_sha256=source_sha, RSYS=0, ERESX='NO',
                    reference_half_interval_mm=HALF_INTERVAL_MM,
                    mesh={k: metadata[k] for k in ('x_mm', 'y_mm', 'z_mm', 'mesh_count', 'mesh_order')},
                    section_area_basis=metadata['centroid_area_basis'])
    sources = {str(record_path): sha(record_path),
               **{str(p): sha(p) for p in paths.values()}, str(material): sha(material),
               str(Path(core.__file__).resolve()): source_sha,
               str(Path(rules.__file__).resolve()): sha(rules.__file__)}
    keys_sha = json_sha(dict(reference_x_mm=full_refs.tolist(),
                            original_node_order=metadata['mesh_order'], mesh=identity['mesh']))
    residual.setflags(write=False)
    return dict(stroke_mm=float(stroke), residual_vectors_mm=residual,
                profile_identity_sha256=json_sha(identity), profile_keys_sha256=keys_sha,
                parent=dict(record_path=str(record_path), actual_input_sha256=input_sha,
                            model_source_sha256=source_sha, profile_keys_sha256=keys_sha,
                            profile_identity_sha256=json_sha(identity),
                            residual_vectors_sha256=json_sha(residual.tolist()),
                            actual_D_error_mm=measured, section_count=len(full_refs), sources=sources))


def _convex_minimum(left, right, iterations=64):
    """Finite golden-section minimization of max(section-vector norm), t in [0,1]."""
    if type(iterations) is not int or not 8 <= iterations <= 96:
        raise ValueError('Use an integer bounded iteration count (8..96).')
    left, right = np.asarray(left, dtype=float), np.asarray(right, dtype=float)
    if (left.shape != right.shape or left.ndim != 2 or left.shape[1] != 3 or not len(left)
            or not np.isfinite(left).all() or not np.isfinite(right).all()):
        raise ValueError('Finite equally keyed full XYZ residual arrays are required.')
    with np.errstate(over='raise', invalid='raise'):
        try:
            delta = right - left
        except FloatingPointError as error:
            raise ValueError('Nonfinite interpolation arithmetic.') from error
    def objective(t):
        value = float(np.max(np.linalg.norm(left + t*delta, axis=1)))
        if not math.isfinite(value):
            raise ValueError('Nonfinite interpolation objective.')
        return value
    low, high, ratio = 0., 1., (math.sqrt(5.)-1.)/2.
    a, b = high-ratio*(high-low), low+ratio*(high-low)
    fa, fb = objective(a), objective(b)
    for _ in range(iterations):
        if fa <= fb:
            high, b, fb = b, a, fa
            a = high-ratio*(high-low); fa = objective(a)
        else:
            low, a, fa = a, b, fb
            b = low+ratio*(high-low); fb = objective(b)
    t = (low+high)/2.
    return t, objective(t), objective(0.), objective(1.)


def propose_shape_candidate(left_record_path, right_record_path, *, sampled_strokes_mm,
                            failed_strokes_mm, iterations=64):
    """Return stroke_or_None + trace only. The complete known ledger is required.

    No output is a trial/label or an evaluated candidate J. Rejected proposals
    use None; original search midpoint/admissibility/all-valley/bracket rules
    must remain the caller's fallback and decision authority.
    """
    result = dict(version=VERSION, stroke_or_None=None, suggestion_only=True,
                  candidate_evaluated_by_FE=False, candidate_actual_J_mm=None,
                  qualified_for_formal_dataset=False, global_optimum_proven=False,
                  parents=[], method_trace={}, proposer_source_sha256=sha(__file__))
    try:
        sampled_strokes_mm, failed_strokes_mm = tuple(sampled_strokes_mm), tuple(failed_strokes_mm)
        for values in (sampled_strokes_mm, failed_strokes_mm):
            if any(not _number(x) or x < 0 for x in values):
                raise ValueError('Known sampled/failed stroke lists must contain finite nonnegative numbers.')
        profiles = sorted((load_actual_profile(left_record_path), load_actual_profile(right_record_path)),
                          key=lambda p: p['stroke_mm'])
        result['parents'] = [p['parent'] for p in profiles]
        left, right = profiles
        low, high = left['stroke_mm'], right['stroke_mm']
        if low >= high or round(low, 6) != low or round(high, 6) != high:
            raise ValueError('Distinct six-decimal actual parent strokes are required.')
        if any(low <= x <= high for x in failed_strokes_mm):
            raise ValueError('Parent interval crosses a known failed/rejected candidate.')
        if any(p['stroke_mm'] not in sampled_strokes_mm for p in profiles):
            raise ValueError('Both actual parents must appear in the explicit sampled ledger.')
        if left['profile_identity_sha256'] != right['profile_identity_sha256'] or left['profile_keys_sha256'] != right['profile_keys_sha256']:
            raise ValueError('Parents differ in physical config, mesh, material, source, RSYS or reference keys.')
        t, value, f0, f1 = _convex_minimum(left['residual_vectors_mm'], right['residual_vectors_mm'], iterations)
        stroke = round(low+t*(high-low), 6)
        result['method_trace'] = dict(method='linear signed full-section residual vectors; convex max norm',
                                     iterations=iterations, interval_mm=[low, high], t=t,
                                     interpolated_profile_objective_mm=value,
                                     interpolated_endpoint_objectives_mm=[f0, f1],
                                     interpolation_is_an_actual_FE_result=False,
                                     fallback='unchanged original midpoint policy')
        if not low < stroke < high:
            raise ValueError('Rounded suggestion is not strictly inside the actual parents.')
        if stroke in {round(x, 6) for x in sampled_strokes_mm}:
            raise ValueError('Rounded suggestion is already sampled; no duplicate proposal.')
        if value >= min(f0, f1)-1e-12*max(1., f0, f1):
            raise ValueError('Interpolated minimum offers no strict interior improvement over its endpoints.')
        result['stroke_or_None'] = stroke
        result['reason'] = 'New candidate suggestion only; actual FE and original search checks are required.'
    except (OSError, ValueError, KeyError, TypeError, IndexError) as error:
        result['reason'] = str(error)
    return result
