"""Large-print local status. Reads actual experiment records; never trains."""
from pathlib import Path
from datetime import datetime,timezone,timedelta
import csv,html,json
from qualification_overlay import verified_export_summary

ROOT=Path(__file__).resolve().parents[1]

def read_json(path,default):
    return json.loads(path.read_text(encoding='utf-8')) if path.exists() else default

def formal_snapshot(root=ROOT):
    """Count one immutable qualified export, never flags in the raw label table."""
    paths=list((root/'dataset/qualified_exports').glob('*/export_receipt.json'))
    if not paths:
        return {'formal_completed':0,'formal_count_basis':'尚无独立验收后的正式导出；原始搜索表不作正式计数。'}
    # A later snapshot replaces the earlier cumulative view. Do not add them.
    latest=max(paths,key=lambda p:(p.stat().st_mtime_ns,str(p)))
    try:
        value=verified_export_summary(latest,root=root)
        return {'formal_completed':value['qualified_distinct_conditions'],
                'formal_count_basis':'单份不可改写的验收导出；按不同物理工况计数，不累加历史导出。',
                'formal_export_generated_utc':value['export_snapshot_generated_utc'],
                'formal_export_protocol_sha256':value['protocol_sha256'],
                'formal_export_csv':value['qualified_labels_path'],
                'formal_export_receipt':value['export_receipt']}
    except Exception as error:
        # An invalid latest claim must remain visible, not silently use an old count.
        return {'formal_completed':0,'formal_count_basis':'最近正式导出未通过读取校验，计数暂不采信。',
                'formal_export_problem':str(error),'formal_export_receipt':str(latest)}

def update(scan_runs=True):
    status=read_json(ROOT/'progress.json',{'phase':'准备三维实体模型','formal_completed':0,'target':1000})
    sources=read_json(ROOT/'provenance'/'review_summary.json',{})
    rows=[]
    labels=ROOT/'dataset'/'labels.csv'
    if labels.exists():
        with labels.open(encoding='utf-8-sig',newline='') as stream: rows=list(csv.DictReader(stream))
    if scan_runs and (ROOT/'runs').exists():
        receipts=[read_json(path,{}) for path in (ROOT/'runs').glob('*/*/trial_result.json')]
        status['new_FE_trials_completed']=sum(bool(v.get('accepted_solver')) for v in receipts)
    elif (ROOT/'dataset/trials.csv').exists():
        with (ROOT/'dataset/trials.csv').open(encoding='utf-8-sig',newline='') as stream:
            status['new_FE_trials_completed']=sum(row.get('accepted_solver','').lower()=='true' for row in csv.DictReader(stream))
    status.update(formal_snapshot())
    status['original_search_records']=len(rows)
    status.pop('pilot_completed',None)
    if sources:
        status['source_files_recorded']=sources.get('source_file_n')
        status['source_usage_records']=sources.get('usage_record_n')
        status['source_checks_passed']=sources.get('checks_n',0)-len(sources.get('failed_checks',[]))
    usage_v002=ROOT/'provenance/data_usage_v002.json'
    if usage_v002.exists():
        usage=read_json(usage_v002,{})
        status['current_source_usage_records']=len(usage.get('records',{}).get('current',[]))
    now=datetime.now(timezone(timedelta(hours=8))).strftime('%Y-%m-%d %H:%M:%S')
    def esc(v): return html.escape(str(v))
    stage_items=[]
    for label,filename,mode in [('冷启动与重启动对照','warm_stage_continuation_v001.json','actual_solver_runs_started'),('步长、接触和弱弹簧检查','final_fixed_screens_v001.json','actual_solver_runs_started'),('原结果的接触路径读取','contact_geometry_post_v001.json','actual_POST_runs_started'),('完整三维网格的效率对照','mesh_efficiency_v001.json','actual_solver_runs_started'),('所选网格的检查与公开弯曲复核','selected_public_benchmark_v002.json','actual_solver_runs_started'),('修正收敛条件后的重启动对照','warm_displacement_revision_v001.json','actual_FE_started'),('实际收敛标准和触点精度的新对照','restart_control_v002.json','actual_FE_started'),('三工况优化验证与计时','optimization_workflow_v001.json','actual_FE_started'),('自动参考值复核与12毫米接续对照','restart_control_continuation_v003.json','actual_FE_started'),('三工况优化验证与计时第二版','optimization_workflow_v002.json','actual_FE_started'),('复用已有初态后继续三工况验证','optimization_workflow_v003.json','actual_FE_started')]:
        path=ROOT/'logs'/filename
        if not path.exists():continue
        try:stage=read_json(path,{})
        except json.JSONDecodeError:
            stage_items.append(f'<li>{esc(label)}：状态正在写入，稍后读取。</li>');continue
        actual=stage.get(mode,0)
        count_text=f'已记录并核对{actual}次启动' if type(actual) is int else '启动次数待核对'
        kind='只读后处理' if mode=='actual_POST_runs_started' else '有限元求解'
        stage_items.append(f'<li><strong>{esc(label)}</strong>：{esc(stage.get("phase","初始化"))}。{esc(kind)}{esc(count_text)}；不计入正式工况。</li>')
    stage_view='<h2>后续串行任务</h2><ul>'+''.join(stage_items)+'</ul><p class="small">正在运行的一次计算，在退出并核对执行记录后才计入上述次数；这些次数不计入正式工况。</p>' if stage_items else ''
    links=[]
    usage_path='../provenance/data_usage_v002.csv' if (ROOT/'provenance/data_usage_v002.csv').exists() else '../provenance/data_usage.csv'
    for label,path in [('流程与实验规定（第二版）','../protocol/设计说明_v002.txt'),('公开数据来源',usage_path),('材料和基准复核','../provenance/README.txt'),('公开夹具和尺寸说明','../provenance/fixture_observations.txt'),('已完成行程数据','../dataset/labels.csv'),('各候选行程','../dataset/trials.csv'),('失败记录','../dataset/failures.csv')]:
        if (ROOT/'report'/path).exists(): links.append(f'<li><a href="{path}">{label}</a></li>')
    dictionary='../protocol/data_dictionary_v002.json' if (ROOT/'protocol/data_dictionary_v002.json').exists() else '../protocol/data_dictionary.json'
    mesh_decision='mesh_refinement_decision_v002.txt' if (ROOT/'report/mesh_refinement_decision_v002.txt').exists() else 'mesh_refinement_decision_v001.txt'
    for label,path in [('容易读的流程与文件说明','实验流程与文件说明.txt'),('现在做到哪里与接下来怎么做','当前计算安排_v002.txt'),('列名、单位和定义',dictionary),('12毫米实际试算检查','press12_review_v001.txt'),('公开弯曲基准检查','public_benchmark_review_v002.txt'),('为什么继续细化网格',mesh_decision),('第三级网格实际结果核对','mesh_l3_actual_review_v001.txt'),('第四级网格启动检查','mesh_ladder_v002_review_v001.txt'),('失败原因、处理和影响（更新）','失败与处理记录_v002.txt'),('重启动卸载位移不一致的原因','warm_zero_displacement_failure_diagnosis_v001.txt'),('收紧收敛条件的修正说明','warm_zero_minimal_numerical_candidate_v001.txt'),('初态读取恢复与原结果核对','warm_guard_recovery_v001/说明与重审结果.txt'),('场数据保存与实际逐条读回说明','../permanent_fields/FORMAT_WITNESS_L3_D_V001/说明.txt')]:
        if (ROOT/'report'/path).exists():links.append(f'<li><a href="{path}">{label}</a></li>')
    status_note=ROOT/'report/状态与提速建议_20261007_1335.txt'
    if status_note.exists():
        links.insert(0,'<li><a href="状态与提速建议_20261007_1335.txt">10月7日13:35的状态查询与提速建议（当时快照）</a></li>')
    for label,path in [('本轮优化与三工况计算计划','optimization_validation_plan_v001.txt'),('重启动实际控制与精度修订','restart_boundary_control_v003_review.txt'),('优化流程的最新说明','优化流程与进度_v001.txt')]:
        if (ROOT/'report'/path).exists():
            links.insert(0,f'<li><a href="{esc(path)}">{esc(label)}</a></li>')
    formal_csv=status.get('formal_export_csv')
    if formal_csv and status.get('formal_completed',0):
        path=Path(formal_csv).relative_to(ROOT).as_posix()
        links.append(f'<li><a href="../{esc(path)}">独立验收后的正式行程数据</a></li>')
    preview=''
    preview_path=ROOT/'report/physical_review_ddd347f8a1c7.png'
    if preview_path.exists():
        preview='<h2>已经算出的形状变化</h2><p>这是12毫米候选行程的一次实际计算。卸载后偏差从5.405毫米降到1.378毫米，最佳行程还需要搜索。</p><img src="physical_review_ddd347f8a1c7.png" alt="实际三维试算的形状变化" style="width:100%;height:auto">'
    selected_b_path=ROOT/'benchmark/PUBLIC0007_CORE004_SELECTED_B_V002/benchmark_metrics.json'
    if selected_b_path.exists():
        selected_b=read_json(selected_b_path,{})
        if selected_b.get('accepted_solver') is True:
            preview+=f'<h2>B网格公开弯曲对比已完成</h2><p>对比{int(selected_b["force_comparison_sample_count"])}个实际力测量点，误差为{100*float(selected_b["force_nrmse_peak"]):.2f}%（误差均方根除以试验峰值）。三项固定行程数值检查已完成；变化尺寸工况和最佳行程仍待验证，试验验收阈值尚需明确。</p>'
    benchmark_path=ROOT/'benchmark/PUBLIC0007_CORE004_NOMINAL_V002/benchmark_metrics.json'
    benchmark_plot=ROOT/'report/public_force_comparison_v002.png'
    if benchmark_path.exists() and benchmark_plot.exists():
        benchmark=read_json(benchmark_path,{})
        if benchmark.get('accepted_solver') is True:
            preview+=f'<h2>此前原网格的公开弯曲对比</h2><p>下面保留的是此前原网格的对比图。对比原试验的{int(benchmark["force_comparison_sample_count"])}个测量点，力曲线误差为{100*float(benchmark["force_nrmse_peak"]):.2f}%（误差均方根除以试验峰值）。图中包含加载和卸载。该比较支持公开四点弯曲阶段；最佳矫直行程与变化尺寸工况仍需独立计算。</p><img src="public_force_comparison_v002.png" alt="此前原网格公开试验与实际三维计算的力曲线对比" style="width:100%;height:auto">'
    names={'new_FE_trials_completed':'最近汇总的求解器及文件检查通过候选数','material':'材料','workpiece':'工件类型','machine_learning_run':'是否运行预测模型','backup_created':'是否新建备份','note':'说明','current_case':'当前工况','current_stroke_mm':'当前行程（毫米）','current_case_trials':'当前工况已实际试算的候选数','current_case_admissible_trials':'当前工况筛查合格的候选数','original_search_records':'原始表中完成搜索的记录（含后续已验收者）','source_files_recorded':'已记录来源文件','source_usage_records':'原来源审查的历史使用片段','current_source_usage_records':'新版来源表的当前使用片段','source_checks_passed':'通过的来源一致性检查','formal_count_basis':'正式计数依据','formal_export_generated_utc':'正式导出生成时间（UTC）','formal_export_protocol_sha256':'正式导出的实验规定版本校验值','formal_export_csv':'正式数据原文件','formal_export_receipt':'正式导出校验记录','formal_export_problem':'正式导出读取问题'}
    def readable(value):
        if value is None:return '—'
        if value is True: return '是'
        if value is False: return '否'
        return value
    detail=''.join(f'<tr><td>{esc(names.get(k,k))}</td><td>{esc(readable(v))}</td></tr>' for k,v in status.items() if k not in ('phase','target','formal_completed','updated_at'))
    text=f'''<!doctype html><html lang="zh-CN"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width"><meta http-equiv="refresh" content="30"><title>三维矩形杆仿真实验进度</title><style>body{{font-family:"Microsoft YaHei",sans-serif;font-size:25px;line-height:1.65;max-width:1080px;margin:32px auto;padding:0 25px;color:#1e293b;background:#fafafa}}h1{{font-size:36px}}h2{{font-size:30px}}.status{{padding:22px;background:#e8f1ff;border-left:6px solid #315d98}}table{{border-collapse:collapse;width:100%;font-size:21px}}td{{border:1px solid #cbd5e1;padding:10px;overflow-wrap:anywhere}}a{{color:#174b88}}.small{{font-size:20px}}</style></head><body><h1>三维矩形杆仿真实验</h1><p class="small">页面生成时间：{now}（北京时间）。本页每30秒刷新；状态由计算程序在阶段变化时更新。</p><div class="status"><strong>当前：{esc(status['phase'])}</strong><p>正式有效工况：{int(status.get('formal_completed',len(rows)))} / {int(status.get('target',1000))}</p></div><p>材料采用公开OPARA试验中的42CrMo4+QT。工件为三维矩形实体，使用固定方向的圆柱压头和支承，保留预弯和卸载后的塑性历史。这是声明了夹具假设的虚拟工艺。</p>{stage_view}<h2>怎么做</h2><ol><li>核对材料和公开四点弯曲试验，记录原文件及使用的数据。</li><li>模拟四点预弯，充分卸载，保留初始弯曲和残余应力。</li><li>反向三点矫直。行程从压头首次接触工件开始计算。</li><li>各候选行程从同一个初始状态独立试算，退出压头后比较整段弯曲。</li><li>选已实际计算的最佳行程，保存曲线、来源和必要原始结果。</li><li>代表工况与小批量检查通过后，再生成至少1000条正式记录。</li></ol><p>正式数据只由实际有限元计算产生。本项目不训练预测模型，不创建备份或压缩包。个别失败记录原因和影响，不记入有效工况数量。</p>{preview}<h2>已保存的记录</h2><ul>{''.join(links) or '<li>来源记录与核心模型正在建立。</li>'}</ul><table>{detail}</table><p class="small">公开四点弯曲支持材料和预弯阶段。反向三点矫直及变化尺寸属于本项目的仿真设计，结果适用于这里声明的工艺和参数范围。</p></body></html>'''
    output=ROOT/'report'/'index.html'; output.parent.mkdir(exist_ok=True)
    output.write_text(text,encoding='utf-8')
    return output

if __name__=='__main__': print(update())
