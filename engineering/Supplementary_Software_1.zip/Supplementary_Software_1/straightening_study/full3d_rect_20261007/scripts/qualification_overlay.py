"""Offline export of independently qualified labels; never changes originals.

Only explicit --export writes a new qualified_labels.csv/export_receipt.json.
The default is a read-only availability check. Solver, POST, qualifier and
search modules are never imported or executed. Software fixtures stay in report.
"""
from __future__ import annotations

import argparse
import ast
import csv
import hashlib
import io
import json
import math
import re
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
VERSION = "RECT_QUALIFICATION_OVERLAY_V001"
FEATURES = ("b_mm", "h_mm", "support_span_mm", "punch_radius_mm", "support_radius_mm", "prebend_tool_stroke_mm")
FIXED = ("length_mm", "prebend_outer_span_mm", "prebend_inner_span_mm", "prebend_radius_mm")
NUMERICAL = ("ny", "nz", "dx_mm", "FKN_factor", "FTOLN_factor", "max_tool_increment_mm", "unload_increment_mm", "weak_spring_N_per_mm", "friction", "fine_withdrawal_clearance_mm", "tool_far_gap_mm", "save_full_strain_trajectory")
SOURCES = ("rect_model.py", "search_cases.py", "numerical_acceptance.py", "trial.py", "solver_runner.py", "design_cases.py", "qualify_case.py")
EXTRA_FIELDS = ("registered_design_case_id", "source_search_case_id", "physical_condition_sha256", "qualification_receipt", "qualification_receipt_sha256", "search_result_sha256", "protocol_sha256", "accepted_numerical_config_sha256", "winning_normalized_config_sha256", "frozen_original_source_snapshot_sha256", "countable_distinct_condition")
REQUIRED_CHECKS = {"formal_generation_unlocked", "case_uses_globally_accepted_numerical_settings", "search_protocol_SHA_and_version", "search_frozen_model_and_algorithm_sources", "case_config_SHA", "formal_design_case_unique_match", "case_matches_registered_physical_inputs", "design_parameter_SHA_recomputed", "independent_search_reconstruction", "all_candidate_B_C0_initial_history", "selected_actual_candidate_individually_valid", "selected_actual_valid_two_sided_bracket", "raw_best_actual_valid_two_sided_bracket", "label_is_actual_selected_stroke_and_J", "source_snapshot_still_matches_at_receipt", "source_snapshot_matches_inside_issuance_lock"}


def load(path):
    def reject(value):
        raise ValueError("Nonfinite JSON constant: " + value)
    return json.loads(Path(path).read_text(encoding="utf-8-sig"), parse_constant=reject)


def canonical_sha(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")).hexdigest()


def finite(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def require(value, message):
    if not value:
        raise ValueError(message)


class SourceReader:
    """Stream each unchanged file once, caching common global evidence hashes."""
    def __init__(self):
        self.cache = {}
        self.observed = {}

    def sha(self, path):
        path = Path(path).resolve()
        a = path.stat()
        key = (str(path), a.st_size, a.st_mtime_ns, a.st_ctime_ns)
        if key not in self.cache:
            h = hashlib.sha256()
            with path.open("rb") as stream:
                for chunk in iter(lambda: stream.read(4 * 1024 * 1024), b""):
                    h.update(chunk)
            b = path.stat()
            require((a.st_size, a.st_mtime_ns, a.st_ctime_ns) == (b.st_size, b.st_mtime_ns, b.st_ctime_ns), "Source changed while hashing: " + str(path))
            self.cache[key] = h.hexdigest()
        self.observed[str(path)] = {"size_bytes": a.st_size, "mtime_ns": a.st_mtime_ns, "ctime_ns": a.st_ctime_ns, "sha256": self.cache[key]}
        return self.cache[key]

    def stable(self):
        for path, before in self.observed.items():
            s = Path(path).stat()
            require((s.st_size, s.st_mtime_ns, s.st_ctime_ns) == (before["size_bytes"], before["mtime_ns"], before["ctime_ns"]), "Source changed before export: " + path)


def resolve(path, root):
    p = Path(path)
    return (p if p.is_absolute() else Path(root) / p).resolve()


def within(path, directory):
    require(Path(path).resolve().is_relative_to(Path(directory).resolve()), "Path is outside its declared source directory: " + str(path))


def mock_guard(value, software_test, description):
    marked = value.get("software_mock") is True or str(value.get("mode", "")).startswith(("software_", "synthetic_", "isolated_"))
    require(software_test or not marked, "Software fixture cannot supply formal evidence: " + description)


def physical_key(values, protocol):
    # Exact definition in qualify_case.physical_key: six decimals are identity,
    # but registry/config values are additionally compared without rounding.
    body = {"physical_inputs": {k: round(float(values[k]), 6) for k in FEATURES},
            "fixed_geometry": {k: float(protocol["fixed_geometry"][k]) for k in FIXED},
            "material_parameter_sha256": protocol["material"]["parameter_source_sha256"],
            "controlled_history": "public-type four-point prebend, unload, reverse three-point straightening"}
    return canonical_sha(body), body


def validate_receipt(path, *, root=ROOT, protocol_path=None, reader=None, software_test=False):
    """Return a validated label copy and its source references; write nothing."""
    root = Path(root).resolve()
    if software_test:
        within(root, ROOT / "report/qualification_overlay")
        require(root != ROOT, "Isolated tests cannot use the actual study root")
    reader = reader or SourceReader()
    path = resolve(path, root)
    within(path, root / "report/case_qualification")
    require(path.name == "qualification_receipt.json", "A review/software receipt is not an issued qualification")
    receipt_sha = reader.sha(path)
    q = load(path)
    mock_guard(q, software_test, "qualification receipt")
    require(q.get("schema_version") == "RECT_CASE_QUALIFICATION_V001" and q.get("mode") == "issue_requested", "Unsupported or non-issued qualifier schema")
    require(q.get("status") == "pass" and q.get("ready_for_future_qualification") is True and q.get("qualified_for_formal_dataset") is True, "Qualification is not explicitly passed and issued")
    require(q.get("Ansys_invocations") == 0 and q.get("POST_invocations") == 0 and q.get("source_receipts_modified") is False and q.get("dataset_CSVs_modified") is False, "Qualifier activity declaration is absent or inconsistent")
    require(resolve(q.get("receipt_path", ""), root) == path, "Issued receipt path identity differs")
    checks = q.get("checks", [])
    require(isinstance(checks, list) and bool(checks) and all(c.get("status") == "pass" and c.get("check") for c in checks), "Qualification required checks are not all passed")
    require(REQUIRED_CHECKS.issubset({c["check"] for c in checks}), "Qualification lacks required source/design/search/issuance checks")
    snapshot = q.get("source_snapshot", {})
    original = q.get("frozen_original_source_snapshot", {})
    derived = q.get("derived_audit_snapshot", {})
    require(isinstance(snapshot, dict) and bool(snapshot) and isinstance(original, dict) and bool(original) and isinstance(derived, dict), "Complete source snapshots are absent")
    require(not (set(original) & set(derived)) and snapshot == {**original, **derived}, "Original/derived snapshots do not partition the full source snapshot")
    derived_root = (root / "report/numerical_acceptance/qualification_rechecks").resolve()
    actual_derived = {p: d for p, d in snapshot.items() if resolve(p, root).is_relative_to(derived_root)}
    require(derived == actual_derived, "Derived audit snapshot does not match the qualifier's actual directory definition")
    pinned = {}
    for name, digest in snapshot.items():
        p = resolve(name, root)
        require(re.fullmatch(r"[0-9a-f]{64}", str(digest)) is not None and reader.sha(p) == digest, "Qualification source SHA mismatch: " + str(p))
        require(str(p) not in pinned or pinned[str(p)] == digest, "Contradictory source identity")
        pinned[str(p)] = digest

    def source_ref(ref, directory=None):
        require(isinstance(ref, dict) and ref.get("exists") is True and ref.get("path") and ref.get("sha256"), "Bound source reference is incomplete")
        p = resolve(ref["path"], root)
        if directory is not None:
            within(p, directory)
        require(pinned.get(str(p)) == ref["sha256"] == reader.sha(p), "Source reference is not covered by unchanged qualification snapshot: " + str(p))
        return p

    sources = q.get("source_hashes", {})
    require(set(sources) == set(SOURCES), "Qualifier source chain does not have the actual schema's seven files")
    for name in SOURCES:
        p = root / "scripts" / name
        require(pinned.get(str(p.resolve())) == sources[name] == reader.sha(p), "Qualifier implementation SHA differs: " + name)
    require(source_ref(q["qualification_source"], root / "scripts") == (root / "scripts/qualify_case.py").resolve(), "Qualification source is not the declared qualifier")
    search_path = source_ref(q["search_source"], root / "cases")
    pp = source_ref(q["protocol_source"], root / "protocol")
    if protocol_path is not None:
        require(pp == resolve(protocol_path, root), "Receipt belongs to a different selected protocol")
    source_ref(q["budgets_source"], root / "protocol")
    gate_path = source_ref(q["global_gate_source"], root / "protocol")
    protocol, gate, search = load(pp), load(gate_path), load(search_path)
    for name, obj in (("protocol", protocol), ("gate", gate), ("search", search)):
        mock_guard(obj, software_test, name)
    protocol_sha = reader.sha(pp)
    parameters_path = resolve(protocol["material"]["parameter_source"], root)
    require(pinned.get(str(parameters_path)) == protocol["material"]["parameter_source_sha256"] == reader.sha(parameters_path), "Declared material parameter source is not unchanged and covered")
    require(gate.get("formal_generation_unlocked") is True and gate.get("protocol_sha256") == protocol_sha and gate.get("protocol_version") == protocol["protocol_version"], "Global gate/protocol identity differs")
    passes = list(protocol["gates"]["required_passes"])
    if protocol["history"]["restart_used"] is True:
        passes.append("restart_equivalence")
    else:
        require(protocol["history"]["restart_used"] is False and gate.get("restart_equivalence_status") == "not_applicable_restart", "Cold/restart policy is not explicit")
    require(all(gate.get("passes", {}).get(k) is True for k in passes), "Global required passes are incomplete")
    require(all(gate.get("source_hashes", {}).get(k) == v for k, v in sources.items()), "Global gate and issued qualifier sources differ")
    require(search.get("case_id") == q.get("case_id") and bool(search.get("case_id")), "Search case identity differs")
    require(all(search.get(k) is True for k in ("complete", "search_acceptance_passed", "bracket_resolution_met", "all_identified_valleys_resolved")) and search.get("search_boundary") is False, "Search is unresolved or a boundary diagnostic")
    config = search["config"]
    require(config.get("protocol_sha256") == protocol_sha and config.get("protocol_version") == protocol["protocol_version"], "Search protocol differs")
    require(search.get("case_config_sha256") == canonical_sha(config), "Search config SHA differs")
    require(search.get("model_source_sha256") == sources["rect_model.py"] and search.get("search_source_sha256") == sources["search_cases.py"], "Search model/algorithm source differs")
    require(search.get("search_settings_sha256") == canonical_sha(search["search_settings"]), "Search settings SHA differs")
    label = search.get("label")
    require(isinstance(label, dict) and bool(label), "Search has no actual selected label")
    require(label.get("case_id") == search["case_id"] and label.get("model_source_sha256") == sources["rect_model.py"] and label.get("case_config_sha256") == search["case_config_sha256"], "Original label source/config identity differs")
    require(label.get("search_settings_sha256") == search["search_settings_sha256"] and label.get("protocol_version") == protocol["protocol_version"], "Original label settings/protocol differs")
    physical, definition = physical_key(config, protocol)
    link = q["formal_design_link"]
    require(q.get("physical_condition_sha256") == link.get("physical_condition_sha256") == physical and link.get("physical_condition_definition") == definition, "Qualified physical condition identity differs")
    registry_path = source_ref(link["registry_source"], root / "protocol")
    registry_receipt_path = source_ref(link["registry_receipt_source"], root / "protocol")
    with registry_path.open(encoding="utf-8-sig", newline="") as stream:
        registry = list(csv.DictReader(stream))
    design = load(registry_receipt_path)
    require(design.get("phase") == "formal_candidate_design_only_no_solver" and design.get("protocol_sha256") == protocol_sha and design.get("protocol_version") == protocol["protocol_version"], "Formal design protocol/phase differs")
    require(design.get("generator_sha256") == sources["design_cases.py"] and design.get("seed") == protocol["design"]["formal_seed"] and design.get("solver_started") is False, "Formal registry generator/seed differs")
    ids = [r.get("case_id") for r in registry]
    keys = [physical_key(r, protocol)[0] for r in registry]
    require(bool(registry) and all(ids) and len(set(ids)) == len(ids) and len(set(keys)) == len(keys), "Registry has duplicate case/physical conditions")
    require(design.get("distinct_candidate_conditions") == len(registry) and design.get("target_complete_final_conditions") == protocol["design"]["formal_minimum_complete_distinct_final_cases"] and len(registry) >= protocol["design"]["formal_minimum_complete_distinct_final_cases"], "Registry declared plan size differs from the qualified protocol")
    matches = [r for r in registry if r.get("case_id") == link.get("design_case_id")]
    require(len(matches) == 1 and matches[0] == link.get("design_row"), "Qualified registry row does not match the unique original row")
    row = matches[0]
    require(row.get("phase") == "formal_candidate" and row.get("protocol_version") == protocol["protocol_version"] and row.get("material_version") == protocol["material"]["version"] and row.get("design_parameter_sha256") == physical, "Registry phase/material/physical hash differs")
    bounds = {v["name"]: (v["minimum"], v["maximum"]) for v in protocol["variable_inputs"]}
    for k in (*FEATURES, *FIXED):
        require(finite(config.get(k)) and float(row[k]) == config[k] == label.get(k), "Original label/config/registry physical input differs: " + k)
        if k in FEATURES:
            require(bounds[k][0] <= config[k] <= bounds[k][1], "Physical input outside protocol: " + k)
        else:
            require(config[k] == protocol["fixed_geometry"][k], "Fixed geometry differs: " + k)
    require(label.get("material_parameter_sha256") == protocol["material"]["parameter_source_sha256"], "Label material parameters differ")
    selected = q["actual_valid_search"]["selected"]
    require(selected.get("input_sha256") == label.get("best_input_sha256") and selected.get("stroke_mm") == label.get("best_stroke_mm") and finite(selected.get("final_error_mm")) and finite(label.get("final_error_mm")) and abs(selected["final_error_mm"] - label["final_error_mm"]) <= 1e-10, "Independently accepted selected point differs from label")
    winner = [c for c in q.get("candidates", []) if c.get("input_sha256") == selected["input_sha256"] and c.get("qualification_contribution") is True]
    require(len(winner) == 1, "No unique independently valid actual selected candidate")
    w = winner[0]
    require(w.get("source_status") == "pass" and w.get("method_status") == "pass" and w.get("admissibility") is True, "Selected candidate's independent source/method review is not passed")
    selected_trials = [t for t in search.get("trials", []) if t.get("input_sha256") == selected["input_sha256"]]
    require(len(selected_trials) == 1, "Original search has no unique actual selected trial")
    selected_trial = selected_trials[0]
    require(selected_trial.get("accepted_solver") is True and selected_trial.get("parsed") is True and selected_trial.get("model_source_sha256") == sources["rect_model.py"], "Original search selected trial was not successfully parsed by the qualified model")
    require(w.get("stroke_mm") == selected_trial.get("stroke_mm") == selected["stroke_mm"] and resolve(w.get("directory", ""), root) == resolve(selected_trial.get("directory", ""), root) == resolve(label["best_run"], root), "Selected qualification/search trial directories or strokes differ")
    provenance = w["provenance"]
    input_path = source_ref(provenance["input_source"], root / "runs")
    metadata_path = source_ref(provenance["metadata_source"], root / "runs")
    trial_path = source_ref(provenance["trial_receipt_source"], root / "runs")
    solver_path = source_ref(provenance["solver_status_source"], root / "runs")
    require(len({p.parent for p in (input_path, metadata_path, trial_path, solver_path)}) == 1, "Winning actual source files are from different attempts")
    require(resolve(label["best_run"], root) == input_path.parent, "Original best_run is not the selected actual folder")
    meta, trial, solver = load(metadata_path), load(trial_path), load(solver_path)
    for name, obj in (("metadata", meta), ("trial", trial), ("solver", solver)):
        mock_guard(obj, software_test, name)
    signature = hashlib.sha256(input_path.read_text(encoding="ascii").replace("\r\n", "\n").encode("ascii")).hexdigest()
    require(signature == selected["input_sha256"] == solver.get("input_sha256") == trial.get("input_sha256"), "Winning actual input identity differs")
    require(provenance.get("input_sha256") == provenance.get("rebuilt_input_sha256") == signature, "Qualification actual and rebuilt winning signatures differ")
    require(solver.get("accepted_exit") is True and solver.get("returncode") == 0 and solver.get("error_count") == 0 and solver.get("timed_out") is False and solver.get("exception") is None and solver.get("process_tree", {}).get("tree_exit_confirmed") is True, "Winning physical solver is not accepted")
    require(trial.get("accepted_solver") is True and trial.get("parsed") is True and not trial.get("post_only") and not meta.get("recovery_mode"), "Winning trial is not an accepted cold physical run")
    require(trial.get("case_id") == search["case_id"] and trial.get("stroke_mm") == selected["stroke_mm"] and resolve(trial.get("directory", ""), root) == input_path.parent, "Winning raw trial case/stroke/directory differs")
    require(trial.get("model_source_sha256") == sources["rect_model.py"] and all(trial.get("implementation_source_hashes", {}).get(k) == sources[k] for k in ("rect_model.py", "trial.py", "solver_runner.py")), "Winning implementation source differs")
    accepted = gate.get("accepted_numerical_config", {})
    require(isinstance(accepted, dict) and all(k in accepted for k in NUMERICAL) and accepted.get("save_full_strain_trajectory") is True and all(meta["config"].get(k) == accepted[k] for k in NUMERICAL), "Winning normalized config does not match accepted numerical settings")
    require(meta["config"].get("case_id") == config.get("case_id") == search["case_id"] and meta["config"].get("stroke_mm") == selected["stroke_mm"], "Winning case/stroke differs")
    require(all(meta["config"].get(k) == config[k] for k in (*FEATURES, *FIXED)), "Winning physical config differs")
    require(label.get("material_card_sha256") == meta.get("material_sha256"), "Winning material card differs")
    material_path = resolve(meta["material_file"], root)
    require(pinned.get(str(material_path)) == meta["material_sha256"] == reader.sha(material_path), "Winning actual material card is not unchanged and covered")
    for key in ("initial_error_mm", "final_error_mm", "max_ip_accumulated_plastic_strain", "max_abs_ip_axial_total_strain"):
        raw = w.get("independent_metrics", {}).get(key)
        require(finite(raw) and finite(label.get(key)) and abs(raw - label[key]) <= 1e-10, "Winning independently checked label metric differs: " + key)
    require(finite(label.get("best_stroke_mm")) and label["best_stroke_mm"] > 0 and label.get("search_boundary") is False, "Selected label is a zero/boundary diagnostic")
    require(label.get("meets_0p05mm") is (label["final_error_mm"] <= .05), "Process acceptance flag differs; process misses may remain qualified")
    augmented = {**label, "qualified_for_formal_dataset": not software_test,
                 "registered_design_case_id": link["design_case_id"], "source_search_case_id": search["case_id"],
                 "physical_condition_sha256": physical, "qualification_receipt": str(path), "qualification_receipt_sha256": receipt_sha,
                 "search_result_sha256": reader.sha(search_path), "protocol_sha256": protocol_sha,
                 "accepted_numerical_config_sha256": canonical_sha(accepted), "winning_normalized_config_sha256": canonical_sha(meta["config"]),
                 "frozen_original_source_snapshot_sha256": canonical_sha(original), "countable_distinct_condition": not software_test}
    return augmented, {"receipt_path": str(path), "receipt_sha256": receipt_sha, "search_path": str(search_path), "search_sha256": reader.sha(search_path),
                       "physical_condition_sha256": physical, "original_countable_distinct_condition": q.get("countable_distinct_condition"),
                       "original_source_count": len(original), "derived_source_count": len(derived), "limitations_preserved": q.get("limitations_preserved", []),
                       "accepted_numerical_config": accepted, "software_test": software_test}


def label_fields(root):
    # Read a literal constant; do not import the solver-linked search module.
    tree = ast.parse((Path(root) / "scripts/search_cases.py").read_text(encoding="utf-8-sig"))
    hits = [n.value for n in tree.body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "FIELDS" for t in n.targets)]
    require(len(hits) == 1, "Search label column literal is unavailable")
    fields = ast.literal_eval(hits[0])
    require(isinstance(fields, list) and len(fields) == len(set(fields)) and all(isinstance(v, str) for v in fields), "Invalid search label field list")
    return fields + [f for f in EXTRA_FIELDS if f not in fields]


def export_qualified(receipts, output_dir, *, root=ROOT, protocol_path=None, software_test=False):
    """Create a new immutable export pair; all requested sources must validate."""
    root = Path(root).resolve()
    paths = sorted({str(resolve(p, root)) for p in receipts})
    if not paths:
        return {"status": "pending_no_issued_receipts", "qualified_distinct_conditions": 0, "export_written": False, "Ansys_invocations": 0, "POST_invocations": 0}
    reader = SourceReader()
    unique = {}
    evidence = []
    duplicates = []
    for path in paths:
        row, reference = validate_receipt(path, root=root, protocol_path=protocol_path, reader=reader, software_test=software_test)
        key = row["physical_condition_sha256"]
        if key in unique:
            previous = unique[key]
            # Different aliases/source receipts may describe the same physical
            # condition, but contradictory accepted labels cannot be arbitrated.
            identity_fields = (*FEATURES, "best_stroke_mm", "final_error_mm", "initial_error_mm", "material_parameter_sha256", "material_card_sha256", "protocol_sha256", "accepted_numerical_config_sha256", "winning_normalized_config_sha256")
            # Normalized config includes case_id: aliases are allowed when all
            # actual physics, numerical settings and label metrics agree.
            identity_fields = tuple(k for k in identity_fields if k != "winning_normalized_config_sha256")
            require(all(previous.get(k) == row.get(k) for k in identity_fields), "Conflicting passed labels for one physical condition: " + key)
            duplicates.append({"physical_condition_sha256": key, "retained_receipt": previous["qualification_receipt"], "duplicate_receipt": row["qualification_receipt"], "counted_additional_rows": 0})
        else:
            unique[key] = row
        evidence.append(reference)
    protocol_shas = {r["protocol_sha256"] for r in unique.values()}
    require(len(protocol_shas) == 1, "One export cannot mix protocol scopes")
    rows = sorted(unique.values(), key=lambda r: (r["registered_design_case_id"], r["physical_condition_sha256"]))
    require(len({r["registered_design_case_id"] for r in rows}) == len(rows), "One registered case ID maps to multiple physical conditions")
    output = resolve(output_dir, root)
    within(output, root / ("report/qualification_overlay" if software_test else "dataset/qualified_exports"))
    require(not output.exists(), "Preserve an existing export; choose a new output directory")
    fields = label_fields(root)
    text = io.StringIO(newline="")
    writer = csv.DictWriter(text, fieldnames=fields, extrasaction="ignore", lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    csv_bytes = text.getvalue().encode("utf-8-sig")
    reader.stable()
    result = {"schema_version": VERSION, "generated_utc": datetime.now(timezone.utc).isoformat(),
              "mode": "isolated_software_export_not_formal_data" if software_test else "actual_independently_qualified_label_export", "status": "pass", "export_written": True,
              "qualified_distinct_conditions": 0 if software_test else len(rows), "software_fixture_distinct_conditions": len(rows) if software_test else 0,
              "issued_receipts_seen": len(paths), "duplicates_not_counted": duplicates, "counting_rule": "one independently qualified physical_condition_sha256 = one row",
              "protocol_sha256": next(iter(protocol_shas)), "qualified_labels_path": str(output / "qualified_labels.csv"),
              "qualified_labels_sha256": hashlib.sha256(csv_bytes).hexdigest(), "columns": fields, "row_count": len(rows), "source_evidence": evidence,
              "verified_source_files": reader.observed, "overlay_source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              "original_labels_modified": False, "original_receipts_modified": False, "Ansys_invocations": 0, "POST_invocations": 0, "machine_learning_run": False, "backup_created": False,
              "formal_generation_unlock_changed": False, "scope": "Reports previously issued qualifications only; does not grant a new qualification or change protocol gates."}
    output.mkdir(parents=True, exist_ok=False)
    with (output / "qualified_labels.csv").open("xb") as stream:
        stream.write(csv_bytes)
    with (output / "export_receipt.json").open("x", encoding="utf-8") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
    return result


def verified_export_summary(export_receipt, *, root=ROOT, software_test=False):
    """Small read-only progress interface to an immutable exported snapshot.

    It verifies the export/CSV bytes and unique row identities; it does not
    repeat qualification or rehash every large FE source on each page refresh.
    A new qualification/source revision requires a new offline export.
    """
    root = Path(root).resolve()
    if software_test:
        within(root, ROOT / "report/qualification_overlay")
    path = resolve(export_receipt, root)
    within(path, root / ("report/qualification_overlay" if software_test else "dataset/qualified_exports"))
    require(path.name == "export_receipt.json", "Expected an immutable export receipt")
    q = load(path)
    expected_mode = "isolated_software_export_not_formal_data" if software_test else "actual_independently_qualified_label_export"
    require(q.get("schema_version") == VERSION and q.get("mode") == expected_mode and q.get("status") == "pass" and q.get("export_written") is True, "Export is not an accepted snapshot of the requested mode")
    table_path = resolve(q["qualified_labels_path"], root)
    require(table_path.parent == path.parent and table_path.name == "qualified_labels.csv", "Export table path differs")
    data = table_path.read_bytes()
    require(hashlib.sha256(data).hexdigest() == q["qualified_labels_sha256"], "Export CSV changed")
    rows = list(csv.DictReader(io.StringIO(data.decode("utf-8-sig"), newline="")))
    require(type(q.get("row_count")) is int and len(rows) == q["row_count"], "Export row count differs")
    hashes = [r.get("physical_condition_sha256") for r in rows]
    require(all(re.fullmatch(r"[0-9a-f]{64}", h or "") for h in hashes) and len(set(hashes)) == len(hashes), "Export physical conditions are missing or duplicated")
    expected_flag = "false" if software_test else "true"
    require(all(r.get("qualified_for_formal_dataset", "").lower() == expected_flag for r in rows), "Export qualification row flags differ")
    count = 0 if software_test else len(rows)
    require(type(q.get("qualified_distinct_conditions")) is int and q["qualified_distinct_conditions"] == count, "Export qualified count is inconsistent")
    return {"qualified_distinct_conditions": count, "export_snapshot_generated_utc": q["generated_utc"], "protocol_sha256": q["protocol_sha256"],
            "export_receipt": str(path), "export_receipt_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            "qualified_labels_path": str(table_path), "qualified_labels_sha256": q["qualified_labels_sha256"], "count_scope": "immutable offline qualified snapshot; original labels.csv is not promoted"}


def discover_issued_receipts(root=ROOT):
    """Select issued qualification claims; preserve nonqualified reviews intact.

    Issuance may retain a failed qualification_receipt with qualified=false.
    Such files are not formal rows. Every selected true claim still undergoes
    full source verification; a contradictory/stale true receipt cannot hide.
    """
    paths = sorted((Path(root) / "report/case_qualification").glob("*/*/qualification_receipt.json"))
    eligible, not_qualified = [], []
    for path in paths:
        q = load(path)
        if q.get("qualified_for_formal_dataset") is True:
            eligible.append(path)
        else:
            not_qualified.append(path)
    return eligible, not_qualified


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--receipt", type=Path, action="append", help="Explicit independent issued receipt; repeat for multiple files")
    parser.add_argument("--protocol", type=Path, default=ROOT / "protocol/protocol_v002.json")
    parser.add_argument("--export", action="store_true", help="Future actual export; no receipts means no output")
    parser.add_argument("--output-dir", type=Path, help="New directory under dataset/qualified_exports; never overwrite")
    args = parser.parse_args()
    discovered, nonqualified = discover_issued_receipts() if args.receipt is None else (args.receipt, [])
    receipts = discovered
    if not args.export:
        result = {"status": "availability_only", "issued_qualification_claims_present": len(receipts), "nonqualified_receipts_preserved_not_selected": len(nonqualified), "export_written": False, "qualified_distinct_conditions": 0, "note": "Availability is not qualification. Use explicit --export only after actual independent issuance."}
    else:
        output = args.output_dir or ROOT / "dataset/qualified_exports" / datetime.now(timezone.utc).strftime("export_%Y%m%dT%H%M%S%fZ")
        result = export_qualified(receipts, output, protocol_path=args.protocol)
    print(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False))
    return 0 if result["status"] in ("pass", "availability_only") else 2


if __name__ == "__main__":
    raise SystemExit(main())
