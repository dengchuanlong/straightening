"""Pure native control derivation and read-only actual MAPDL control audit.

No solver, POST, preparation, source mutation or qualification is performed.
Automatic reference with an explicit lower bound avoids claiming that a
fixed VALUE survives restart. Actual printed criteria remain mandatory.
"""
from pathlib import Path
import argparse
import hashlib
import json
import math
import re

VERSION = 'RESTART_CONTROL_AUTOREF_MIN1_V002'
CONTROL = 'cnvtol,u,,1e-9,0,1\n'
STAGES = (7, 8, 9, 10, 11)
MAX_U_CRITERION_MM = 1e-7
_FLOAT = r'[-+]?(?:\d+\.?\d*|\.\d+)(?:[EeDd][-+]?\d+)?'


def _sha(text):
    return hashlib.sha256(text.encode('ascii')).hexdigest()


def derive_input(original, kind):
    """Append one U control before each time7..11 of an untouched plan.

    original is the original core/warm generator text, not the previous
    fixed-U derived input. No existing U controls may be silently replaced.
    """
    if kind not in ('cold', 'warm') or not isinstance(original, str):
        raise ValueError('Explicit cold/warm untouched native text required.')
    original.encode('ascii')
    if '\r' in original or re.search(r'^\s*cnvtol\s*,\s*u\b', original, re.I | re.M):
        raise ValueError('Use canonical LF untouched generator text without a previous U variant.')
    anchors = ['\ntime,' + str(stage) + '\n' for stage in STAGES]
    if any(original.count(anchor) != 1 for anchor in anchors):
        raise ValueError('Exactly one native time7..11 boundary for each stage required.')
    positions = [original.index(anchor) for anchor in anchors]
    if positions != sorted(positions):
        raise ValueError('Native stage sequence is not 7..11.')
    derived = original
    for anchor in anchors:
        derived = derived.replace(anchor, '\n' + CONTROL + anchor[1:], 1)
    if derived.replace('\n' + CONTROL, '\n') != original:
        raise ValueError('Native derivation is not exactly reversible.')
    prefix = original[:positions[0]]
    if derived[:positions[0]] != prefix:
        raise ValueError('Actual pre-C0 prefix changed.')
    return derived, {
        'version': VERSION, 'variant': VERSION, 'execution_kind': kind, 'numerical_only': True,
        'modification': 'Reassert identical automatic-reference U controls before native time7..11; all other original bytes unchanged.',
        'command': CONTROL.strip(), 'native_control_stages': list(STAGES),
        'native_insertion_count': len(STAGES),
        'original_generator_plan_input_sha256': _sha(original),
        'actual_derived_input_sha256': _sha(derived),
        'prefix_through_C0_sha256': _sha(prefix),
        'original_prefix_through_C0_identical': True,
        'original_all_bytes_preserved_in_order': True,
        'original_generator_plan_is_execution_evidence': False,
        'derivative_source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'variant_source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'variant_source_role': 'Pure restart_control_v002 transformer; execution worker source must be bound separately.',
        'input_ack_is_actual_control_evidence': False,
        'expected_table_U': {'reference': 0., 'tolerance': 1e-9, 'norm': 0, 'minref': 1.},
        'maximum_actual_printed_U_criterion_mm': MAX_U_CRITERION_MM,
        'MINREF_is_lower_bound_not_absolute_cap': True,
        'requires_new_actual_log_and_unchanged_cold_warm_budget_checks': True,
        'material_contact_spring_mesh_load_path_changed': False,
        'qualified': False, 'formal_generation_unlocked': False,
    }


def _number(token):
    value = float(token.replace('D', 'E').replace('d', 'e'))
    if not math.isfinite(value):
        raise ValueError('Nonfinite actual convergence value.')
    return value


def _parse_lines(lines, ceiling):
    current_ls = None
    in_table = False
    tables = {str(stage): [] for stage in STAGES}
    pending = []
    substeps = []
    waiting_time = None
    version_seen = False
    errors = []
    for line_number, line in enumerate(lines, 1):
        if re.search(r'(?:RELEASE\s+2026\s+R1|REL(?:EASE)?\.?\s+2026\s+R1)', line, re.I):
            version_seen = True
        if '*** ERROR ***' in line:
            errors.append(line_number)
        match = re.search(r'LOAD STEP NUMBER[^\d]*(\d+)', line)
        if match:
            current_ls = int(match.group(1))
        if 'CONVERGENCE CONTROLS' in line:
            in_table = True
            continue
        if in_table:
            match = re.match(r'^\s*U\s+(' + _FLOAT + r')\s+(' + _FLOAT + r')\s+(\d+)\s+(' + _FLOAT + r')\s*$', line)
            if match and current_ls in STAGES:
                tables[str(current_ls)].append({
                    'line': line_number, 'reference': _number(match[1]),
                    'tolerance': _number(match[2]), 'norm': int(match[3]),
                    'minref': _number(match[4]),
                })
            elif 'COPY INTEGRATION' in line or 'DATABASE OUTPUT' in line:
                in_table = False
        match = re.search(r'DISP CONVERGENCE VALUE\s*=\s*(' + _FLOAT + r')\s+CRITERION=\s*(' + _FLOAT + r')', line)
        if match and current_ls in STAGES:
            value, criterion = _number(match[1]), _number(match[2])
            if value < 0 or criterion <= 0:
                raise ValueError('Invalid actual displacement convergence scalar.')
            pending.append((line_number, value, criterion))
        match = re.search(r'\*\*\* LOAD STEP\s+(\d+)\s+SUBSTEP\s+(\d+)\s+COMPLETED', line)
        if match:
            ls, ss = int(match[1]), int(match[2])
            if ls in STAGES:
                if not pending:
                    errors.append({'line': line_number, 'missing_actual_U_iteration_rows': [ls, ss]})
                criteria = [v[2] for v in pending]
                high = max(pending, key=lambda v: v[2]) if pending else None
                record = {
                    'load_step': ls, 'substep': ss, 'completed_line': line_number,
                    'time': None, 'iteration_U_rows': len(pending),
                    'criterion_min_mm': min(criteria) if criteria else None,
                    'criterion_max_mm': max(criteria) if criteria else None,
                    'criterion_values_mm': sorted(set(criteria)),
                    'largest_criterion_line': high[0] if high else None,
                    'last_U_iteration_value_mm': pending[-1][1] if pending else None,
                    'last_U_iteration_line': pending[-1][0] if pending else None,
                }
                substeps.append(record)
                waiting_time = record
            pending = []
        match = re.search(r'^\s*\*\*\* TIME\s*=\s*(' + _FLOAT + r')', line)
        if match and waiting_time is not None:
            waiting_time['time'] = _number(match[1])
            waiting_time = None
    if pending:
        errors.append({'uncompleted_U_iteration_rows': len(pending)})
    identities = [(v['load_step'], v['substep']) for v in substeps]
    if len(identities) != len(set(identities)) or identities != sorted(identities):
        errors.append({'nonunique_or_unordered_completed_substeps': True})
    expected = {'reference': 0., 'tolerance': 1e-9, 'norm': 0, 'minref': 1.}
    stage_results = {}
    for stage in STAGES:
        values = tables[str(stage)]
        rows = [row for row in substeps if row['load_step'] == stage]
        table_ok = bool(values) and all(all(v[k] == expected[k] for k in expected) for v in values)
        criteria = [v for row in rows for v in row['criterion_values_mm']]
        trajectory_ok = bool(rows) and bool(criteria) and all(row['time'] is not None and row['iteration_U_rows'] > 0 for row in rows)
        stage_results[str(stage)] = {
            'actual_solver_tables': values, 'expected_table_matches': table_ok,
            'completed_substeps': len(rows), 'actual_U_iteration_rows': sum(row['iteration_U_rows'] for row in rows),
            'observed_criterion_values_mm': sorted(set(criteria)),
            'max_actual_U_criterion_mm': max(criteria) if criteria else None,
            'complete_actual_iteration_evidence': trajectory_ok,
            'actual_criterion_within_absolute_ceiling': trajectory_ok and max(criteria) <= ceiling,
        }
    passed = version_seen and not errors and all(v['expected_table_matches'] and v['actual_criterion_within_absolute_ceiling'] for v in stage_results.values())
    return {
        'version': VERSION, 'official_v261_header_seen': version_seen,
        'actual_control_tables_and_iteration_rows_used': True, 'input_ACK_used_as_control_evidence': False,
        'expected_table_U': expected, 'max_allowed_printed_U_criterion_mm': ceiling,
        'stages': stage_results, 'substeps': substeps, 'parse_or_solver_error_evidence': errors,
        'actual_controls_verified': passed, 'passed': passed,
        'criterion_precision_basis': 'Actual solve.out printed decimals; not an unrounded internal float identity assertion.',
        'iteration_rows_basis': 'Rows before each completed substep, including any preceding cutback attempts; not all rows are accepted Newton corrections.',
        'solver_exit_acceptance_or_physical_equivalence_granted': False,
        'qualified': False, 'formal_generation_unlocked': False,
    }


def audit_log(folder_orpath, *, max_absolute_U_criterion_mm=MAX_U_CRITERION_MM):
    """Read actual control tables and iterations; no ACK/metadata shortcuts."""
    if type(max_absolute_U_criterion_mm) not in (int, float) or not math.isfinite(max_absolute_U_criterion_mm) or not 0 < max_absolute_U_criterion_mm <= MAX_U_CRITERION_MM:
        raise ValueError('Finite positive nonboolean U ceiling no larger than 1e-7 mm required.')
    path = Path(folder_orpath)
    if path.is_dir():
        path = path / 'solve.out'
    before = path.stat()
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        def lines():
            for raw in stream:
                digest.update(raw)
                yield raw.decode('ascii', errors='replace')
        result = _parse_lines(lines(), float(max_absolute_U_criterion_mm))
    after = path.stat()
    if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
        raise ValueError('Actual log changed during read; do not bind a mixed snapshot.')
    result['source'] = {'path': str(path.resolve()), 'sha256': digest.hexdigest(), 'bytes': after.st_size, 'mtime_ns': after.st_mtime_ns}
    result['audit_source_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    return result


def compare_logs(cold_folder_orpath, warm_folder_orpath):
    """Actual effective U controls at matching completed substeps, not physics."""
    cold, warm = audit_log(cold_folder_orpath), audit_log(warm_folder_orpath)
    a, b = cold['substeps'], warm['substeps']
    schedule = len(a) == len(b) and all(x['load_step'] == y['load_step'] and x['substep'] == y['substep'] and x['time'] is not None and y['time'] is not None and abs(x['time'] - y['time']) <= 1e-10 for x, y in zip(a, b))
    same = schedule and all(x['criterion_values_mm'] == y['criterion_values_mm'] for x, y in zip(a, b))
    return {
        'version': VERSION, 'cold_audit': cold, 'warm_audit': warm,
        'actual_completed_substep_schedule_matches': schedule,
        'actual_printed_U_criteria_match_at_each_substep': same,
        'actual_controls_pair_verified': cold['actual_controls_verified'] and warm['actual_controls_verified'] and same,
        'passed': cold['actual_controls_verified'] and warm['actual_controls_verified'] and same,
        'original_material_field_force_shape_history_budgets_still_required': True,
        'actual_fixed_candidate_comparison_passed': False,
        'qualified': False, 'formal_generation_unlocked': False,
    }


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('log_or_folder')
    args = parser.parse_args()
    print(json.dumps(audit_log(args.log_or_folder), ensure_ascii=False, allow_nan=False))
