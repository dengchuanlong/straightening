"""V003 wrapper: identical U control and restored support boundary precision.

The frozen V002 remains unmodified. Only pure input derivation and readonly
actual log/field audits are exposed; no native execution or qualification.
"""
from pathlib import Path
import hashlib
import json
import math
import re
import restart_control_v002 as controls

VERSION = 'RESTART_AUTOREF_SUPPORT_PRECISION_V003'
VARIANT = VERSION
CONTROL = controls.CONTROL
SUPPORT_PRECISION_MM = 1e-9
FROZEN_V002_SHA256 = '76dbc16c3ad44853f20864c198995f1832051024c7d6891978302434b22fb0fe'


def _guard_v002():
    digest = hashlib.sha256(Path(controls.__file__).read_bytes()).hexdigest()
    if digest != FROZEN_V002_SHA256:
        raise ValueError('Frozen V002 transformer changed.')
    return digest


def support_pilot(text):
    start, end = '\ntime,10\n', '\ntime,11\n'
    if text.count(start) != 1 or text.count(end) != 1 or text.index(start) >= text.index(end):
        raise ValueError('Unique ordered native LS10..11 support block required.')
    block = text.split(start, 1)[1].split(end, 1)[0]
    matches = re.findall(r'^d,(\d+),uy,supuy\+[^\r\n]+$', block, re.M)
    if len(matches) != 1 or int(matches[0]) <= 0:
        raise ValueError('Exactly one positive support pilot in original LS10 required.')
    return int(matches[0])


def derive_input(original, kind):
    transformer_sha = _guard_v002()
    pilot = support_pilot(original)
    intermediate, first = controls.derive_input(original, kind)
    command = f'd,{pilot},uy,supuy\n'
    stage7 = original.split('\ntime,7\n', 1)[1].split('\ntime,8\n', 1)[0]
    if re.search(r'^d,\d+,uy,supuy\s*$', stage7, re.M):
        raise ValueError('Original already contains a support precision variant.')
    anchor = '\ntime,7\n'
    derived = intermediate.replace(anchor, '\n' + command + anchor[1:], 1)
    if derived.replace('\n' + command + 'time,7\n', anchor, 1) != intermediate:
        raise ValueError('Support precision derivation is not independently reversible.')
    prefix_length = original.index(anchor)
    if derived[:prefix_length] != original[:prefix_length]:
        raise ValueError('Original C0 prefix changed.')
    own_sha = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    lineage = {**first,
        'version': VERSION, 'variant': VARIANT,
        'modification': 'V002 five U controls plus one exact support UY reassertion before time7; no new SOLVE.',
        'native_insertion_count': 6,
        'actual_derived_input_sha256': hashlib.sha256(derived.encode('ascii')).hexdigest(),
        'derivative_source_sha256': own_sha, 'variant_source_sha256': own_sha,
        'variant_source_role': 'Pure V003 numerical/boundary transformer; execution worker SHA is separate.',
        'v002_transformer_sha256': transformer_sha, 'v002_derivation_lineage': first,
        'support_pilot_node': pilot, 'support_precision_reassertion_command': command.strip(),
        'support_boundary_precision_restoration': True,
        'support_precision_max_actual_error_mm': SUPPORT_PRECISION_MM,
        'support_precision_is_verified_from_actual_C_field_not_ACK': True,
        'nominal_support_position_is_existing_touch_parameter': True,
        'actual_old_rounded_boundary_is_changed_explicitly': True,
        'new_SOLVE_added': False,
        'actual_unchanged_state_and_pair_verification_required': True,
    }
    return derived, lineage


def _read(path):
    path = Path(path)
    before = path.stat()
    raw = path.read_bytes()
    after = path.stat()
    if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
        raise ValueError('Actual source changed during read.')
    source = {'path': str(path.resolve()), 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': after.st_size, 'mtime_ns': after.st_mtime_ns}
    return raw.decode('utf-8'), source


def _numbers(text, expected):
    values = [float(v.replace('D', 'E').replace('d', 'e')) for v in text.split()]
    if len(values) != expected or not all(math.isfinite(v) for v in values):
        raise ValueError('Actual numeric field dimensions or finite values invalid.')
    return values


def _support_precision(folder):
    sources = {}
    native, sources['executed_native_input'] = _read(folder / 'input.inp')
    pilot = support_pilot(native)
    text, sources['actual_C_tool_vectors'] = _read(folder / 'state_C_tool_vectors.txt')
    values = _numbers(text, 32)
    rows = [values[i:i+8] for i in range(0, 32, 8)]
    ids = [row[0] for row in rows]
    if len(set(ids)) != 4 or any(v <= 0 or not v.is_integer() for v in ids):
        raise ValueError('Four actual pilot identities required.')
    matches = [row for row in rows if int(row[0]) == pilot]
    if len(matches) != 1:
        raise ValueError('Actual C support pilot missing/duplicated.')
    actual_uy = matches[0][1]
    if (folder / 'warm_metadata.json').is_file():
        raw, sources['warm_metadata'] = _read(folder / 'warm_metadata.json')
        meta = json.loads(raw)
        expected = meta['original_touch_parameters'][2]
        if type(expected) not in (int, float) or not math.isfinite(expected):
            raise ValueError('Original warm touch support value invalid.')
        base = Path(meta['base_folder'])
        text, sources['original_base_touch_field'] = _read(base / 'touch_geometry.txt')
        base_expected = _numbers(text, 6)[2]
        if abs(expected - base_expected) > 1e-12:
            raise ValueError('Original warm metadata/base support touch sources differ.')
        metadata_pilot = meta['core_metadata']['tools']['support']['pilot_node']
        target_basis = 'Full precision saved original_touch_parameters[2], crosschecked against immutable actual base touch_geometry third column.'
    else:
        raw, sources['model_metadata'] = _read(folder / 'model_metadata.json')
        meta = json.loads(raw)
        metadata_pilot = meta['tools']['support']['pilot_node']
        text, sources['actual_cold_touch_field'] = _read(folder / 'touch_geometry.txt')
        expected = _numbers(text, 6)[2]
        target_basis = 'Actual cold touch_geometry third column, printed E24.16.'
    if type(metadata_pilot) is not int or metadata_pilot != pilot:
        raise ValueError('Native and actual metadata support pilot identities differ.')
    error = abs(actual_uy - expected)
    return {
        'support_pilot_node': pilot, 'expected_full_precision_support_UY_mm': expected,
        'actual_C_support_UY_mm': actual_uy, 'max_allowed_support_error_mm': SUPPORT_PRECISION_MM,
        'actual_support_error_mm': error, 'passed': error <= SUPPORT_PRECISION_MM,
        'target_basis': target_basis, 'actual_field_basis': 'state_C_tool_vectors actual pilot UY; no input ACK substituted.',
        'sources': sources,
    }


def audit_log(folder_orpath, *, max_absolute_U_criterion_mm=controls.MAX_U_CRITERION_MM):
    _guard_v002()
    result = controls.audit_log(folder_orpath, max_absolute_U_criterion_mm=max_absolute_U_criterion_mm)
    result['control_audit_version'] = result['version']
    result['version'] = VERSION
    result['control_audit_passed'] = result['passed']
    path = Path(folder_orpath)
    folder = path if path.is_dir() else path.parent
    try:
        result['support_precision'] = _support_precision(folder)
        result['support_precision_verified'] = result['support_precision']['passed']
    except Exception as error:
        result['support_precision'] = {'passed': False, 'error': repr(error)}
        result['support_precision_verified'] = False
    result['passed'] = result['control_audit_passed'] and result['support_precision_verified']
    result['v002_transformer_sha256'] = FROZEN_V002_SHA256
    result['boundary_audit_source_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    return result


def compare_logs(cold_folder_orpath, warm_folder_orpath):
    _guard_v002()
    result = controls.compare_logs(cold_folder_orpath, warm_folder_orpath)
    result['control_pair_version'] = result['version']
    result['version'] = VERSION
    result['control_pair_passed'] = result['passed']
    cold, warm = audit_log(cold_folder_orpath), audit_log(warm_folder_orpath)
    result['cold_audit'], result['warm_audit'] = cold, warm
    a, b = cold['support_precision'], warm['support_precision']
    complete = a.get('passed') is True and b.get('passed') is True
    target_delta = abs(a['expected_full_precision_support_UY_mm'] - b['expected_full_precision_support_UY_mm']) if complete else None
    actual_delta = abs(a['actual_C_support_UY_mm'] - b['actual_C_support_UY_mm']) if complete else None
    same_pilot = complete and a['support_pilot_node'] == b['support_pilot_node']
    result['support_precision_pair'] = {
        'same_actual_support_pilot': same_pilot, 'touch_target_difference_mm': target_delta,
        'actual_C_support_difference_mm': actual_delta, 'budget_mm': SUPPORT_PRECISION_MM,
        'passed': complete and same_pilot and target_delta <= SUPPORT_PRECISION_MM and actual_delta <= SUPPORT_PRECISION_MM,
    }
    result['passed'] = result['control_pair_passed'] and result['support_precision_pair']['passed']
    result['actual_fixed_candidate_comparison_passed'] = False
    result['boundary_audit_source_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    return result
