"""Finite, actual L4 local challenges of a completed B-mesh search.

Import and the pure helpers never launch a solver. run_challenge delegates at
most twelve fresh candidates to the owner's four explicit backend callbacks.
It does not repeat coarse screening, qualify labels, or claim a fine global
search. Actual receipt/source/profile errors stop rather than becoming J data.
"""
from pathlib import Path
import json
import math
import re
import traceback

import rect_model as core
import search_cases as rules
import optimized_stroke_search_v002 as engine
import stroke_search_engine_v001 as common
import shape_candidate_proposer_v001 as shape
from solver_runner import ROOT

VERSION = 'ACTUAL_L4_LOCAL_CHALLENGE_V001'
BUDGETS = {'best_stroke_difference_mm': .02, 'best_objective_difference_mm': .01,
           'peak_force_relative_difference': .02}
FEATURES = engine.FEATURES


class PendingEvidence(Exception):
    """Known incompleteness is retained separately from unknown source errors."""


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def sha(path):
    return common.sha(path)


def write_owned(path, value):
    # Serialize before creating/replacing our own stage receipt. Original B and
    # backend candidate receipts are never written by this module.
    content = json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)+'\n'
    path = Path(path)
    temporary = path.with_suffix(path.suffix+'.writing')
    with temporary.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(content)
    temporary.replace(path)


def _get(backend, key):
    if isinstance(backend, dict):
        value = backend[key]
    else:
        value = getattr(backend, 'mode' if key == 'execution_mode' else key)
    # Actual OptimizedFEBackend exposes a contract() method and mode attribute;
    # preconstructed dictionaries may contain the same already-read contract.
    return value() if key == 'backend_contract' and callable(value) else value


def _arguments(max_trials, resolution, timeout):
    if (type(max_trials) is not int or not 3 <= max_trials <= 12
            or not engine.number(resolution) or not 2e-6 <= resolution <= .02
            or not engine.number(timeout) or not 0 < timeout <= 7200):
        raise ValueError('Use 3..12 requests, total bracket <=.02mm and a finite timeout <=7200s.')


def _mesh_pair(B_config, fine_config):
    if (B_config.get('ny'), B_config.get('nz'), B_config.get('dx_mm')) != (14, 4, 1.):
        raise ValueError('Expected the registered B mesh ny14/nz4/dx1.')
    if (fine_config.get('ny'), fine_config.get('nz'), fine_config.get('dx_mm')) != (14, 7, 1.):
        raise ValueError('Expected the registered L4 mesh ny14/nz7/dx1.')
    ignored = {'case_id', 'stroke_mm', 'ny', 'nz', 'dx_mm'}
    a = {k: v for k, v in B_config.items() if k not in ignored}
    b = {k: v for k, v in fine_config.items() if k not in ignored}
    if common.json_sha(a) != common.json_sha(b):
        raise ValueError('B/L4 physical and numerical configuration differs beyond the declared mesh/case/stroke.')
    if (fine_config.get('case_id') == B_config.get('case_id')
            or not isinstance(fine_config.get('case_id'), str)
            or not re.fullmatch(r'[A-Za-z0-9_-]{1,100}', fine_config['case_id'])):
        raise ValueError('A distinct simple L4 case_id is required.')
    if any(not engine.number(fine_config.get(k)) or fine_config[k] <= 0 for k in FEATURES):
        raise ValueError('All six physical features must be explicit finite positive values.')


def _cache(records):
    cache = {}
    for row in records:
        s = row.get('stroke_mm')
        if not engine.number(s) or s < 0 or round(s, 6) != s or s in cache:
            raise ValueError('Duplicate, nonfinite, negative or noncanonical actual candidate stroke.')
        cache[s] = row
    return cache


def _registered_window(valley, triple, identified):
    # Explicit parent membership, not a new coarse screen or extrapolated
    # global interval. Prefer containment of the full registered child valley;
    # otherwise require containment of all three actual original B seeds.
    parents = [v for v in identified if v['low_mm'] <= valley['low_mm'] and valley['high_mm'] <= v['high_mm']]
    if not parents:
        parents = [v for v in identified if v['low_mm'] <= triple[0] and triple[2] <= v['high_mm']]
    parent = min(parents, key=lambda v:(v['high_mm']-v['low_mm'], v['low_mm'], v['high_mm'])) if parents else None
    return dict(original_B_valley_low_mm=valley['low_mm'], original_B_valley_high_mm=valley['high_mm'],
                original_B_local_bracket_mm=list(triple),
                registered_parent_screening_valley=parent,
                low_mm=parent['low_mm'] if parent else valley['low_mm'],
                high_mm=parent['high_mm'] if parent else valley['high_mm'],
                challenge_window_basis='registered parent screening valley' if parent else 'original registered B valley; no parent invented')


def seed_plan(B, resolution=.02):
    """Pure selection of existing B triples; it never makes actual fine records."""
    if (B.get('complete') is not True or B.get('search_acceptance_passed') is not True
            or B.get('bracket_resolution_met') is not True
            or B.get('all_identified_valleys_resolved') is not True
            or B.get('search_boundary') is not False or not isinstance(B.get('label'), dict)):
        raise PendingEvidence('The source B search is not a complete interior, resolved actual search.')
    cache = _cache(B.get('trials', []))
    if not cache:
        raise PendingEvidence('No actual B candidate ledger.')
    identified = B.get('identified_screening_valleys') or B.get('initial_coarse_screening_valleys')
    if not identified:
        raise PendingEvidence('No B-identified competing interior valley.')
    regions, seen = [], set()
    # Keep original screening valleys and final competing refined valleys.
    # observed_valleys is a historical discovery ledger, including transient
    # valleys that disappeared after real refinement; it is not an extra gate.
    # Shared triples execute once but retain each final valley witness.
    candidates = [*identified, *B.get('refined_valleys', [])]
    for valley in candidates:
        low, high, middle = (valley.get(k) for k in ('low_mm', 'high_mm', 'screening_stroke_mm'))
        if any(not engine.number(v) for v in (low, high, middle)) or not 0 <= low < middle < high:
            raise ValueError('Malformed actual B valley interval.')
        key = (low, high, middle)
        if key in seen:
            continue
        seen.add(key)
        status = engine.hole_free_neighborhood(rules._valley_status(valley, cache, resolution), cache)
        if status.get('resolved') is not True or status.get('boundary') is not False:
            raise PendingEvidence('An identified B valley lacks a legal actual two-sided <=.02mm bracket.')
        triple = [status['left_mm'], status['best_mm'], status['right_mm']]
        regions.append(dict(region_id=f'B_valley_{len(regions)+1}', origin='B_identified_valley',
                            original_valley_id=valley.get('valley_id'), **_registered_window(valley, triple, identified),
                            screening_stroke_mm=middle, seed_strokes_mm=triple,
                            B_actual_best_stroke_mm=status['best_mm'], B_actual_best_J_mm=status['best_error_mm']))
    usable, raw, selected, raw_near, selected_near = rules._selection(cache, resolution, 0.)
    if selected is None or B['label'].get('best_stroke_mm') != selected['stroke_mm']:
        raise ValueError('The B label is inconsistent with its actual J/tie-zero selection.')
    if B['label'].get('final_error_mm') != selected['metrics']['final_error_mm']:
        raise ValueError('The B label J differs from the actual selected candidate.')
    for name, record, neighborhood in (('B_raw_winner', raw, raw_near), ('B_selected_winner', selected, selected_near)):
        status = engine.hole_free_neighborhood(neighborhood, cache)
        if status.get('resolved') is not True or status.get('boundary') is not False:
            raise PendingEvidence('The source B raw/selected winner has no legal actual two-sided bracket.')
        triple = [status['left_mm'], record['stroke_mm'], status['right_mm']]
        # A winner triple already inside a registered valley needs no additional
        # window. Its explicit role remains in the required-winner evidence.
        if not any(r['seed_strokes_mm'] == triple for r in regions):
            regions.append(dict(region_id=name, origin=name, original_valley_id=None,
                                **_registered_window(dict(low_mm=triple[0],high_mm=triple[2]),triple,identified),
                                screening_stroke_mm=record['stroke_mm'],
                                seed_strokes_mm=triple, B_actual_best_stroke_mm=record['stroke_mm'],
                                B_actual_best_J_mm=record['metrics']['final_error_mm']))
    seeds = sorted({s for region in regions for s in region['seed_strokes_mm']})
    return dict(regions=regions, required_seed_strokes_mm=seeds,
                B_selected_stroke_mm=selected['stroke_mm'], B_raw_stroke_mm=raw['stroke_mm'])


def local_status(region, cache, resolution, known_holes=None):
    status = rules._valley_status(region, cache, resolution)
    return {**status, **engine.hole_free_neighborhood(status, {**(known_holes or {}), **cache})}


def local_proposals(status, cache, resolution, known_holes=None):
    """Finite actual midpoint/outward proposals, never a synthesized J."""
    if status.get('resolved') or status.get('known_rejected_strokes_inside_mm'):
        return []
    if not status.get('boundary'):
        return [round(s, 6) for s in status.get('proposals', []) if round(s, 6) not in cache]
    usable = rules._usable(cache, status['low_mm'], status['high_mm'])
    if not usable:
        return []
    best = rules._best(usable)['stroke_mm']
    half = math.floor(resolution*500000.)/1000000.
    proposals = []
    for s in (round(best-half, 6), round(best+half, 6)):
        if not status['low_mm'] <= s <= status['high_mm'] or s == best or s in cache:
            continue
        # Do not step across an actual solver/material hole even if the original
        # B valley has legal limits. No missing right bracket is fabricated.
        if any(min(best, s) <= bad <= max(best, s) and not rules.admissibility(row)[0]
               for bad, row in {**(known_holes or {}), **cache}.items()):
            continue
        proposals.append(s)
    return proposals


def compare_best(B_record, fine_record):
    values = [B_record['stroke_mm'], fine_record['stroke_mm'],
              B_record['metrics'].get('final_error_mm'), fine_record['metrics'].get('final_error_mm'),
              B_record['metrics'].get('peak_press_force_N'), fine_record['metrics'].get('peak_press_force_N')]
    if any(not engine.number(v) for v in values) or abs(values[4]) <= 0:
        raise PendingEvidence('Actual objective/positive reference peak-force comparison is unavailable.')
    ds, dj = abs(values[0]-values[1]), abs(values[2]-values[3])
    df = abs(values[4]-values[5])/abs(values[4])
    checks = {'best_stroke_difference_mm': ds <= BUDGETS['best_stroke_difference_mm']+1e-12,
              'best_objective_difference_mm': dj <= BUDGETS['best_objective_difference_mm']+1e-12,
              'peak_force_relative_difference': df <= BUDGETS['peak_force_relative_difference']+1e-12}
    return dict(passed=all(checks.values()), checks=checks, budgets=dict(BUDGETS),
                best_stroke_difference_mm=ds, best_objective_difference_mm=dj,
                peak_force_relative_difference=df,
                B_actual=dict(stroke_mm=values[0], J_mm=values[2], peak_press_force_N=values[4],
                              input_sha256=B_record['input_sha256'], directory=B_record['directory']),
                L4_actual=dict(stroke_mm=values[1], J_mm=values[3], peak_press_force_N=values[5],
                               input_sha256=fine_record['input_sha256'], directory=fine_record['directory']),
                comparison_scope='Different actual local-best candidates on B and L4; not an interpolated or global fine optimum.')


def run_challenge(B_search_path, *, backend, output_folder, max_trials=12, resolution=.02, timeout=7200):
    """Stable API: backend has config/contract/mode and the engine's 4 callbacks.

    plan_candidate(cfg,s), evaluate_candidate(cfg,s,timeout), check_sources(),
    validate_execution(record,plan)->proof. The owner retains Student locking,
    fresh actual trial folders, process cleanup and actual control verification.
    This module never calls run_solver directly and never updates main reports.
    """
    _arguments(max_trials, resolution, timeout)
    callbacks = {key: _get(backend, key) for key in
                 ('plan_candidate', 'evaluate_candidate', 'check_sources', 'validate_execution')}
    if not all(callable(cb) for cb in callbacks.values()):
        raise ValueError('Four callable explicit backend callbacks are required.')
    cfg = json.loads(json.dumps(_get(backend, 'config'), allow_nan=False))
    mode = _get(backend, 'execution_mode')
    contract = json.loads(json.dumps(_get(backend, 'backend_contract'), allow_nan=False))
    variant = engine.validate_contract(contract, mode)
    folder = Path(output_folder).resolve()
    if not folder.is_relative_to((ROOT/'optimized_cases').resolve()) or folder.exists():
        raise FileExistsError('Use a fresh local-challenge folder under optimized_cases.')
    B_path = Path(B_search_path).resolve()
    result = dict(version=VERSION, config=cfg, execution_mode=mode, backend_contract=contract,
                  B_search_path=str(B_path), scope='L4 local challenge of all B-identified valleys and winners only',
                  search_settings=dict(max_trials=max_trials, resolution_mm=resolution, timeout_s=timeout,
                                       no_repeated_seven_point_screening=True, tie_error_mm=0.),
                  budgets=dict(BUDGETS), regions=[], trials=[], candidate_plans=[], execution_proofs=[],
                  actual_trial_receipts=[], shape_proposals=[], comparisons=[], exceptions=[],
                  candidate_requests=0, callback_attempts=0, backend_return_witnesses=[],
                  newly_invoked_physical_FE_count=0, local_best=None,
                  complete_local_challenge=False, local_comparison_passed=False,
                  global_optimum_proven=False, full_fine_search_complete=False,
                  qualified_for_formal_dataset=False, formal_generation_unlocked=False,
                  formal_restart_enabled=False, machine_learning_run=False, backup_created=False,
                  incompletion_reasons=[])
    folder.mkdir(parents=True)
    sources = {str(Path(module.__file__).resolve()): sha(module.__file__)
               for module in (core, rules, engine, common, shape)}
    sources[str(Path(__file__).resolve())] = sha(__file__)
    sources.update(contract['source_pins'])
    sources.update({item['path']: item['sha256'] for item in contract['method_evidence']})
    cache, proofs, profiles, tried = {}, {}, {}, set()

    def save():
        result['candidate_requests'] = len(result['candidate_plans'])
        result['newly_invoked_physical_FE_count'] = (sum(r['newly_invoked_physical_FE_count'] for r in result['trials'])
            if result['callback_attempts'] == len(result['trials']) else None)
        result['implementation_sources'] = dict(sources)
        write_owned(folder/'fine_local_challenge.json', result)

    def intact():
        engine.check_hashes(sources)
        engine.validate_contract(contract, mode)
        for proof in proofs.values():
            engine.check_hashes(proof['sources'])
            engine.check_hashes({proof['actual_receipt_path']: proof['actual_receipt_sha256']})
        callbacks['check_sources']()

    def sample(value, origin):
        if not engine.number(value):
            raise ValueError('Candidate must be finite and not bool.')
        s = round(value, 6)
        if not 0 <= s <= upper:
            raise ValueError('Finite candidate within the frozen B interval is required.')
        if s in cache or len(result['candidate_plans']) >= max_trials:
            return False
        intact()
        plan = callbacks['plan_candidate'](cfg, s)
        engine.validate_plan(plan, mode, s, contract)
        json.dumps(plan, allow_nan=False)
        result['candidate_plans'].append({**plan, 'proposed_by': origin})
        save()  # Plan/actual expected identity persists before the backend call.
        result['callback_attempts'] += 1
        save()
        row = callbacks['evaluate_candidate'](cfg, s, timeout)
        witness = dict(requested_stroke_mm=s, backend_return_is_dict=isinstance(row, dict),
                       guard_validation_passed=False)
        if isinstance(row, dict):
            for key in ('directory', 'input_sha256', 'case_id'):
                witness[key] = row.get(key) if isinstance(row.get(key), str) else None
            count = row.get('newly_invoked_physical_FE_count')
            witness['reported_newly_invoked_physical_FE_count'] = count if type(count) is int and count >= 0 else None
        result['backend_return_witnesses'].append(witness)
        save()  # A source/parser failure cannot hide the returned attempt location.
        intact()
        engine.validate_record(row, plan, mode, cfg, contract)
        proof = callbacks['validate_execution'](row, plan)
        engine.validate_proof(proof, row)
        json.dumps(row, allow_nan=False)
        json.dumps(proof, allow_nan=False)
        if type(row.get('newly_invoked_physical_FE_count')) is not int or row['newly_invoked_physical_FE_count'] != 1:
            raise RuntimeError('Each deduplicated L4 challenge must be one fresh actual FE, not an old cached record.')
        cache[s], proofs[s] = row, proof
        witness['guard_validation_passed'] = True
        result['trials'].append(row)
        result['execution_proofs'].append(dict(stroke_mm=s, proof=proof))
        result['actual_trial_receipts'].append(dict(stroke_mm=s, path=proof['actual_receipt_path'],
                                                  sha256=proof['actual_receipt_sha256'],
                                                  executed_input_sha256=row['input_sha256'],
                                                  accepted_solver=row['accepted_solver'], parsed=row['parsed']))
        save()
        if row['accepted_solver'] and not row['parsed']:
            raise RuntimeError('Successful solve with unknown/missing parser evidence; no automatic continuation.')
        return True

    def profile(s):
        if s not in profiles:
            profiles[s] = engine.read_actual_profile(proofs[s]['actual_receipt_path'], record=cache[s],
                                                     execution_proof=proofs[s], numerical_variant_id=variant)
        engine.check_hashes(profiles[s]['parent']['sources'])
        return profiles[s]

    try:
        sources[str(B_path)] = sha(B_path)
        B = read(B_path)
        result['B_search_sha256'] = sources[str(B_path)]
        seeds = seed_plan(B, resolution)
        if B.get('case_config_sha256') != common.json_sha(B['config']):
            raise ValueError('B normalized configuration source hash differs.')
        if B.get('search_settings_sha256') != common.json_sha(B['search_settings']):
            raise ValueError('B search settings source hash differs.')
        _mesh_pair(B['config'], cfg)
        B_contract = B['backend_contract']
        B_mode = B['execution_mode']
        if engine.validate_contract(B_contract, B_mode) != variant:
            raise ValueError('B and L4 numerical variants differ.')
        sources.update(B['implementation_sources'])
        result.update(regions=seeds['regions'], required_seed_strokes_mm=seeds['required_seed_strokes_mm'],
                      B_selected_stroke_mm=seeds['B_selected_stroke_mm'], B_raw_stroke_mm=seeds['B_raw_stroke_mm'],
                      B_historical_valley_ledger=B.get('observed_valleys', []),
                      historical_disappeared_valleys_are_additional_gate=False)
        B_cache = _cache(B['trials'])
        known_B_holes = {s: r for s, r in B_cache.items() if not rules.admissibility(r)[0]}
        result['known_B_rejected_strokes_mm'] = sorted(known_B_holes)
        B_plans = {p['stroke_mm']: p for p in B['candidate_plans']}
        B_proofs = {p['stroke_mm']: p['proof'] for p in B['execution_proofs']}
        if len(B_plans) != len(B['candidate_plans']) or len(B_proofs) != len(B['execution_proofs']):
            raise ValueError('Duplicate B plan/proof identities.')
        if set(B_cache) != set(B_plans) or set(B_cache) != set(B_proofs):
            raise ValueError('B actual records/plans/proofs do not have identical stroke coverage.')
        for s, row in B_cache.items():
            engine.validate_plan(B_plans[s], B_mode, s, B_contract)
            engine.validate_record(row, B_plans[s], B_mode, B['config'], B_contract)
            engine.validate_proof(B_proofs[s], row)
            sources.update(B_proofs[s]['sources'])
            sources[B_proofs[s]['actual_receipt_path']] = B_proofs[s]['actual_receipt_sha256']
        upper = B['search_settings']['upper_mm']
        if not engine.number(upper) or upper <= 0 or any(not 0 <= s <= upper for s in B_cache):
            raise ValueError('Missing/invalid actual source B interval.')
        intact()
        # Check the original actual seed-node geometry/identity before creating
        # any L4 FE. These are original readbacks, never reused L4 candidates.
        for s in seeds['required_seed_strokes_mm']:
            original = engine.read_actual_profile(B_proofs[s]['actual_receipt_path'], record=B_cache[s],
                                                 execution_proof=B_proofs[s], numerical_variant_id=variant)
            sources.update(original['parent']['sources'])
        if len(seeds['required_seed_strokes_mm']) > max_trials:
            raise PendingEvidence('All deduplicated competing-valley seed triples exceed the twelve-request budget.')
        save()
        for s in seeds['required_seed_strokes_mm']:
            sample(s, 'actual_L4_from_B_best_and_two_sided_seed')
        while len(result['candidate_plans']) < max_trials:
            statuses = [local_status(region, cache, resolution, known_B_holes) for region in result['regions']]
            usable, raw, selected, raw_near, selected_near = rules._selection(cache, resolution, 0.)
            near = engine.hole_free_neighborhood(selected_near, {**known_B_holes, **cache})
            if statuses and all(s.get('resolved') is True and s.get('boundary') is False for s in statuses) and near and near['resolved'] and not near['boundary']:
                break
            created = False
            for status in statuses:
                if status.get('resolved') or status.get('known_rejected_strokes_inside_mm'):
                    continue
                low, high = status.get('left_mm'), status.get('right_mm')
                proposal = None
                if low is not None and high is not None and (low, high) not in tried:
                    tried.add((low, high))
                    suggestion = engine.propose_profiles(profile(low), profile(high),
                        sampled_strokes_mm=list(cache),
                        failed_strokes_mm=[s for s, r in {**known_B_holes, **cache}.items() if not rules.admissibility(r)[0]])
                    suggestion['region_id'] = status['region_id']
                    result['shape_proposals'].append(suggestion)
                    save()
                    proposal = suggestion['stroke_or_None']
                if proposal is not None:
                    created = sample(proposal, 'actual_L4_D_shape_suggestion') or created
                    if proposal in cache and rules.admissibility(cache[proposal])[0]:
                        for s in engine.verified_neighbours(proposal, low, high, resolution):
                            created = sample(s, 'actual_L4_two_sided_shape_verification') or created
                else:
                    for s in local_proposals(status, cache, resolution, known_B_holes):
                        created = sample(s, 'actual_L4_local_midpoint_or_boundary_followup') or created
                if len(result['candidate_plans']) >= max_trials:
                    break
            if not created:
                break
        statuses = [local_status(region, cache, resolution, known_B_holes) for region in result['regions']]
        usable, raw, selected, raw_near, selected_near = rules._selection(cache, resolution, 0.)
        near = engine.hole_free_neighborhood(selected_near, {**known_B_holes, **cache})
        result.update(region_challenges=statuses, actual_local_best_neighborhood=near,
                      isolated_candidate_failures=[dict(stroke_mm=s, reason=rules.admissibility(row)[1],
                                                       actual_receipt_path=proofs[s]['actual_receipt_path'])
                                                   for s, row in cache.items() if not rules.admissibility(row)[0]])
        result['region_actual_witnesses'] = [dict(region_id=region['region_id'],
            seeds=[dict(stroke_mm=s, actual_record_present=s in cache,
                        admissible=rules.admissibility(cache[s])[0] if s in cache else False,
                        J_mm=cache[s].get('metrics', {}).get('final_error_mm') if s in cache else None,
                        peak_press_force_N=cache[s].get('metrics', {}).get('peak_press_force_N') if s in cache else None,
                        actual_receipt_path=proofs[s]['actual_receipt_path'] if s in proofs else None,
                        actual_receipt_sha256=proofs[s]['actual_receipt_sha256'] if s in proofs else None)
                   for s in region['seed_strokes_mm']]) for region in result['regions']]
        reasons = []
        if any(s not in cache for s in seeds['required_seed_strokes_mm']):
            reasons.append('Not every B-identified seed has its actual L4 candidate record.')
        if not statuses or any(s.get('resolved') is not True or s.get('boundary') is not False for s in statuses):
            reasons.append('A competing B valley remains locally unresolved/boundary/without legal actual left and right.')
        if selected is None or near is None or not near['resolved'] or near['boundary']:
            reasons.append('The actual local best lacks a legal actual two-sided total bracket <=.02mm.')
        if selected is not None:
            result['local_best'] = dict(stroke_mm=selected['stroke_mm'], J_mm=selected['metrics']['final_error_mm'],
                peak_press_force_N=selected['metrics']['peak_press_force_N'], directory=selected['directory'],
                executed_input_sha256=selected['input_sha256'], actual_receipt=proofs[selected['stroke_mm']],
                actual_bracket=near, qualified_for_formal_dataset=False)
            comparison = compare_best(B_cache[seeds['B_selected_stroke_mm']], selected)
            result['comparisons'].append(comparison)
        if reasons and len(result['candidate_plans']) >= max_trials:
            reasons.append('The twelve-request budget is exhausted; no new fine global search was performed.')
        result['incompletion_reasons'] = reasons
        result['complete_local_challenge'] = not reasons
        result['local_comparison_passed'] = not reasons and bool(result['comparisons']) and all(c['passed'] for c in result['comparisons'])
        intact()
    except PendingEvidence as error:
        result['incompletion_reasons'].append(str(error))
    except Exception as error:
        detail = dict(error=repr(error), traceback=traceback.format_exc(),
                      candidate_requests=len(result['candidate_plans']),
                      impact='Unknown/source/parser/interface error; stop stage, retain actual receipts, no automatic retry.')
        result['exceptions'].append(detail)
        result.update(exception=repr(error), complete_local_challenge=False, local_comparison_passed=False)
        result['incompletion_reasons'].append(detail['impact'])
    save()
    return result
