"""First actual unloaded FE stroke meeting a declared residual tolerance.

No solve or POST on import. The owner supplies the existing four explicit
actual-FE callbacks and an independently computed C0. Anchor lookup and signed
shape interpolation only propose candidates; labels always come from actual D.
No optimum, minimum stroke, bracket or seven-point coarse search is claimed.
"""
from pathlib import Path
import json
import math
import traceback

import numpy as np
import fine_local_challenge_v001 as fine
import rect_model as core
import search_cases as rules
import optimized_stroke_search_v002 as engine
import stroke_search_engine_v001 as common
import shape_candidate_proposer_v001 as shape
from solver_runner import ROOT

VERSION = 'ACTUAL_FIRST_FEASIBLE_STROKE_SEARCH_V003'
POLICY = 'first_actual_admissible_unloaded_candidate_below_threshold'
FEATURES = engine.FEATURES


def arguments(threshold, max_trials, timeout, upper):
    if (not engine.number(threshold) or not 0 < threshold <= 1.0
            or type(max_trials) is not int or not 1 <= max_trials <= 6
            or not engine.number(timeout) or not 0 < timeout <= 7200
            or not engine.number(upper) or upper <= 0):
        raise ValueError('Use positive threshold<=1.0, 1..6 candidates, timeout<=7200 and positive upper.')


def below_threshold(actual_J_mm, threshold):
    """Strict numerical predicate only, never a replacement for actual FE proof."""
    if not engine.number(actual_J_mm) or actual_J_mm < 0 or not engine.number(threshold) or threshold <= 0:
        raise ValueError('Finite nonnegative actual J and positive threshold required.')
    return actual_J_mm < threshold


def nearest_anchor(config, library):
    """Deterministic min-max six-feature lookup; no fitted or trained model."""
    if library.get('schema_version') != 'FEASIBLE_STROKE_ANCHORS_V002':
        raise ValueError('Unsupported anchor schema.')
    if tuple(library.get('features', [])) != FEATURES:
        raise ValueError('Anchor features differ from the six registered physical inputs.')
    anchors = library.get('anchors', [])
    if (len(anchors) != 4 or {a.get('anchor_id') for a in anchors} != {'B0001', 'P0008', 'R0004', 'FP0001'}):
        raise ValueError('Exactly the four declared actual anchors are required.')
    bounds = library.get('feature_bounds', {})
    scales = {}
    for key in FEATURES:
        low, high = bounds[key]['minimum'], bounds[key]['maximum']
        if (not engine.number(low) or not engine.number(high) or not low < high
                or not engine.number(config.get(key)) or config[key] <= 0):
            raise ValueError('Finite declared normalization bounds and physical inputs required.')
        scales[key] = high-low
    distances = []
    for anchor in anchors:
        if any(not engine.number(anchor['physical_inputs'].get(k)) or anchor['physical_inputs'][k] <= 0
               for k in FEATURES):
            raise ValueError('Invalid anchor physical inputs.')
        if any(not engine.number(anchor.get(k)) or anchor[k] < 0 for k in
               ('actual_initial_J_mm', 'actual_stroke_mm', 'actual_final_J_mm')):
            raise ValueError('Invalid actual anchor quantities.')
        if anchor['actual_initial_J_mm'] <= 0 or anchor['actual_stroke_mm'] <= 0:
            raise ValueError('Anchor initial J and actual stroke must be positive.')
        distance = math.sqrt(sum(((config[k]-anchor['physical_inputs'][k])/scales[k])**2 for k in FEATURES))
        distances.append({'anchor_id': anchor['anchor_id'], 'normalized_distance': distance})
    distances.sort(key=lambda item: (item['normalized_distance'], item['anchor_id']))
    selected = next(a for a in anchors if a['anchor_id'] == distances[0]['anchor_id'])
    return selected, {'method': 'nearest_fixed_actual_anchor_in_declared_minmax_six_feature_space',
        'distance': 'Euclidean', 'distances': distances,
        'selected_anchor_id': selected['anchor_id'], 'training_or_parameter_fit': False,
        'proposal_only': True, 'candidate_actual_J_mm': None}


def initial_proposal(config, library, upper, initial_error_mm=None):
    anchor, trace = nearest_anchor(config, library)
    ratio = 1.
    if initial_error_mm is not None:
        if not engine.number(initial_error_mm) or initial_error_mm < 0:
            raise ValueError('Actual initial error must be finite and nonnegative.')
        ratio = min(1.5, max(.5, initial_error_mm/anchor['actual_initial_J_mm']))
    stroke = round(min(upper, max(.000001, anchor['actual_stroke_mm']*ratio)), 6)
    trace.update(actual_anchor_stroke_mm=anchor['actual_stroke_mm'],
        actual_anchor_initial_J_mm=anchor['actual_initial_J_mm'],
        current_actual_initial_J_mm=initial_error_mm, initial_J_ratio_clipped_0p5_to_1p5=ratio,
        upper_mm=upper, proposed_stroke_mm=stroke)
    return stroke, trace


def signed_initial_proposal(record, profile, upper, sampled):
    """One-point signed residual cancellation using the actual B and D shapes.

    The scalar is a candidate heuristic, never an FE output or label. It keeps
    the direction that is lost if only unsigned J is used for a bisection.
    """
    state = record['metrics']['states']['B']
    refs = np.asarray(state['axis_reference_x_mm'], dtype=float)
    axis = np.asarray(state['axis_xyz_mm'], dtype=float)
    _, initial_residual, measured = shape._residual_vectors(axis, refs)
    if abs(measured-record['metrics']['initial_error_mm']) > 1e-10:
        raise ValueError('Saved actual B shape and actual initial error differ.')
    current = np.asarray(profile['residual_vectors_mm'], dtype=float)
    if initial_residual.shape != current.shape:
        raise ValueError('Actual initial/final residual section identity differs.')
    denominator = float(np.sum(initial_residual*initial_residual))
    if denominator <= 0:
        return None, {'method': 'signed_B_D_proposal', 'reason': 'zero initial residual', 'proposal_only': True}
    signed_ratio = float(np.sum(current*initial_residual)/denominator)
    cancellation = 1.-signed_ratio
    s = record['stroke_mm']
    factor = 1./cancellation if cancellation > 1e-8 else 1.25
    factor = min(1.5, max(.5, factor))
    candidate = round(min(upper, max(.000001, s*factor)), 6)
    trace = {'method': 'signed_actual_B_D_residual_cancellation', 'signed_projection_ratio': signed_ratio,
        'actual_parent_stroke_mm': s, 'actual_parent_J_mm': record['metrics']['final_error_mm'],
        'clipped_stroke_factor_0p5_to_1p5': factor, 'proposed_stroke_mm': candidate,
        'proposal_only': True, 'candidate_actual_J_mm': None}
    return (candidate if candidate not in sampled else None), trace


def next_proposal(cache, profiles, upper, first_stroke):
    """Use actual signed D parents, then deterministic local exploratory offsets."""
    ranked = sorted(cache.values(), key=lambda row: (row['metrics']['final_error_mm'], row['stroke_mm']))
    traces = []
    if len(ranked) >= 2:
        left, right = sorted(ranked[:2], key=lambda row: row['stroke_mm'])
        proposal = engine.propose_profiles(profiles[left['stroke_mm']], profiles[right['stroke_mm']],
            sampled_strokes_mm=list(cache), failed_strokes_mm=[])
        # The existing proposer text references old two-sided verification.
        # This search adopts only its candidate; no neighbour or optimum gate.
        proposal['reason'] = 'Candidate suggestion only; this search executes actual FE and stops at the declared threshold.'
        traces.append(proposal)
        if proposal['stroke_or_None'] is not None:
            return proposal['stroke_or_None'], traces
        a, b = profiles[left['stroke_mm']]['residual_vectors_mm'], profiles[right['stroke_mm']]['residual_vectors_mm']
        delta = b-a
        denominator = float(np.sum(delta*delta))
        if denominator > 1e-18:
            t = -float(np.sum(a*delta))/denominator
            raw = left['stroke_mm']+t*(right['stroke_mm']-left['stroke_mm'])
            best_s = ranked[0]['stroke_mm']
            candidate = round(min(upper, max(.000001, min(1.5*best_s, max(.5*best_s, raw)))), 6)
            trace = {'method': 'two_actual_signed_D_vector_secant_candidate',
                'actual_parent_strokes_mm': [left['stroke_mm'], right['stroke_mm']],
                'unclipped_t': t, 'unclipped_stroke_mm': raw, 'proposed_stroke_mm': candidate,
                'proposal_only': True, 'candidate_actual_J_mm': None}
            traces.append(trace)
            if candidate not in cache:
                return candidate, traces
    if ranked:
        candidate, trace = signed_initial_proposal(ranked[0], profiles[ranked[0]['stroke_mm']], upper, cache)
        traces.append(trace)
        if candidate is not None:
            return candidate, traces
    for factor in (1.15, .85, 1.3, .7, 1.45, .55):
        candidate = round(min(upper, max(.000001, first_stroke*factor)), 6)
        if candidate not in cache:
            traces.append({'method': 'deterministic_anchor_offset_fallback', 'factor': factor,
                'proposed_stroke_mm': candidate, 'proposal_only': True, 'candidate_actual_J_mm': None})
            return candidate, traces
    return None, traces


def _load_actual_anchors(path, config):
    path = Path(path).resolve()
    library = engine.read(path)
    nearest_anchor(config, library)
    pins = {str(path): engine.sha(path)}
    for anchor in library['anchors']:
        for name in ('search_source', 'trial_source'):
            item = anchor[name]
            engine.check_hashes({item['path']: item['sha256']})
            pins[item['path']] = item['sha256']
        trial_path = Path(anchor['trial_source']['path']).resolve()
        trial = engine.read(trial_path)
        if (trial.get('software_mock') or trial.get('accepted_solver') is not True
                or trial.get('parsed') is not True or not rules.admissibility(trial)[0]
                or trial.get('input_sha256') != anchor['actual_input_sha256']
                or trial.get('stroke_mm') != anchor['actual_stroke_mm']
                or trial['metrics'].get('initial_error_mm') != anchor['actual_initial_J_mm']
                or trial['metrics'].get('final_error_mm') != anchor['actual_final_J_mm']
                or any(trial['config'].get(k) != anchor['physical_inputs'][k] for k in FEATURES)):
            raise ValueError('Anchor source is not the unchanged actual FE quantities.')
        native = trial_path.parent/'input.inp'
        status = trial_path.parent/'solver_status.json'
        if engine.sha(native) != anchor['actual_input_sha256'] or engine.read(status) != trial['solver_status']:
            raise ValueError('Actual anchor native input/status differs.')
        pins[str(native)] = engine.sha(native)
        pins[str(status)] = engine.sha(status)
    return library, pins


def _initial_source(initial_metrics, cfg):
    if initial_metrics is None:
        return None, {}, None
    value = initial_metrics['initial_error_mm']
    path = Path(initial_metrics['source_path']).resolve()
    digest = initial_metrics['source_sha256']
    engine.check_hashes({str(path): digest})
    saved = engine.read(path)
    meta_path, input_path = path.parent/'warm_metadata.json', path.parent/'input.inp'
    meta = engine.read(meta_path)
    expected = {k: v for k, v in cfg.items() if k != 'stroke_mm'}
    actual = {k: v for k, v in meta['core_metadata']['config'].items() if k != 'stroke_mm'}
    if (saved.get('actual_FE') is not True or saved['states']['B']['fixed260_error_mm'] != value
            or not engine.number(value) or value < 0 or actual != expected
            or saved.get('input_sha256') != meta.get('input_sha256')
            or engine.sha(input_path) != saved.get('input_sha256')):
        raise ValueError('Initial J must come from this exact actual independent C0 history.')
    pins = {str(path): digest, str(meta_path): engine.sha(meta_path), str(input_path): engine.sha(input_path)}
    return value, pins, saved['input_sha256']


def search(config, *, backend, output_folder, anchors_path, threshold=.5,
           max_trials=6, timeout=7200, upper, initial_metrics=None):
    """Execute at most six fresh independent-C0 actual candidates, stopping first hit."""
    arguments(threshold, max_trials, timeout, upper)
    callbacks = {key: fine._get(backend, key) for key in
        ('plan_candidate', 'evaluate_candidate', 'check_sources', 'validate_execution')}
    if not all(callable(cb) for cb in callbacks.values()):
        raise ValueError('Four actual backend callbacks required.')
    cfg = json.loads(json.dumps(fine._get(backend, 'config'), allow_nan=False))
    _, normalized = core.build({**config, 'stroke_mm': 0., 'save_full_strain_trajectory': True})
    if {k: v for k, v in cfg.items() if k != 'stroke_mm'} != {
            k: v for k, v in normalized['config'].items() if k != 'stroke_mm'}:
        raise ValueError('Search config differs from the actual backend configuration.')
    mode = fine._get(backend, 'execution_mode')
    contract = json.loads(json.dumps(fine._get(backend, 'backend_contract'), allow_nan=False))
    variant = engine.validate_contract(contract, mode)
    if mode != 'warm_multiframe_continuation':
        raise ValueError('This bounded production pilot requires the verified independent-C0 method.')
    folder = Path(output_folder).resolve()
    if folder.exists() or not folder.is_relative_to((ROOT/'optimized_cases').resolve()):
        raise FileExistsError('Use a fresh output folder under optimized_cases.')
    result = dict(version=VERSION, policy=POLICY, config=cfg, threshold_mm=threshold,
        upper_mm=upper, max_trials=max_trials, timeout_s=timeout,
        execution_mode=mode, numerical_variant=variant, backend_contract=contract,
        status='prepared', complete=False, label=None, candidate_count=0,
        callback_attempts=0, newly_invoked_physical_FE_count=0,
        trials=[], candidate_plans=[], execution_proofs=[], actual_trial_receipts=[],
        proposal_ledger=[], backend_return_witnesses=[],
        no_seven_point_coarse_search=True, no_two_sided_neighbor_requirement=True,
        best_or_minimum_stroke_claimed=False, global_optimum_proven=False,
        qualified_for_formal_dataset=False, formal_generation_unlocked=False,
        machine_learning_run=False, backup_archive_cleanup=False,
        minimal_skip_status=None)
    folder.mkdir(parents=True)
    sources = {str(Path(module.__file__).resolve()): engine.sha(module.__file__)
               for module in (fine, core, rules, engine, common, shape)}
    sources[str(Path(__file__).resolve())] = engine.sha(__file__)
    sources.update(contract['source_pins'])
    sources.update({item['path']: item['sha256'] for item in contract['method_evidence']})
    cache, proofs, profiles = {}, {}, {}

    def save():
        result['candidate_count'] = len(result['candidate_plans'])
        result['newly_invoked_physical_FE_count'] = engine.invocation_count(result['trials'], result['callback_attempts'])
        result['implementation_sources'] = dict(sources)
        fine.write_owned(folder/'feasible_search_result.json', result)

    def intact():
        engine.check_hashes(sources)
        engine.validate_contract(contract, mode)
        callbacks['check_sources']()
        for proof in proofs.values():
            engine.check_hashes(proof['sources'])
            engine.check_hashes({proof['actual_receipt_path']: proof['actual_receipt_sha256']})

    try:
        library, pins = _load_actual_anchors(anchors_path, cfg)
        sources.update(pins)
        initial, pins, initial_input_sha = _initial_source(initial_metrics, cfg)
        search_base_input_sha = initial_input_sha
        sources.update(pins)
        result['initial_metrics'] = initial_metrics
        stroke, first_trace = initial_proposal(cfg, library, upper, initial)
        result['proposal_ledger'].append(first_trace)
        first_stroke = stroke
        intact()
        if initial is not None and below_threshold(initial, threshold):
            # This is not a zero-stroke D label; classify it separately and
            # avoid filling the straightening dataset with no-action cases.
            result.update(status='skipped_initially_within_tolerance',
                minimal_skip_status='actual_prebend_B_already_below_threshold_no_straightening_label')
            save()
            return result
        while len(result['candidate_plans']) < max_trials and stroke is not None:
            if not engine.number(stroke) or not 0 < stroke <= upper or round(stroke, 6) != stroke or stroke in cache:
                raise ValueError('Candidate must be a fresh positive canonical stroke within upper.')
            intact()
            plan = callbacks['plan_candidate'](cfg, stroke)
            engine.validate_plan(plan, mode, stroke, contract)
            if search_base_input_sha is None:
                search_base_input_sha = plan['base_executed_input_sha256']
            if plan.get('base_executed_input_sha256') != search_base_input_sha:
                raise ValueError('Candidate restore differs from the same actual independent C0 source.')
            result['candidate_plans'].append(plan)
            result['status'] = 'actual_candidate_running'
            save()
            result['callback_attempts'] += 1
            save()
            row = callbacks['evaluate_candidate'](cfg, stroke, timeout)
            result['backend_return_witnesses'].append({
                'requested_stroke_mm': stroke, 'returned_directory': row.get('directory') if isinstance(row, dict) else None,
                'returned_input_sha256': row.get('input_sha256') if isinstance(row, dict) else None})
            save()
            intact()
            engine.validate_record(row, plan, mode, cfg, contract)
            proof = callbacks['validate_execution'](row, plan)
            engine.validate_proof(proof, row)
            if type(row.get('newly_invoked_physical_FE_count')) is not int or row['newly_invoked_physical_FE_count'] != 1:
                raise RuntimeError('Each candidate must be one fresh actual FE, never an anchor/cached result.')
            cache[stroke], proofs[stroke] = row, proof
            result['trials'].append(row)
            result['execution_proofs'].append({'stroke_mm': stroke, 'proof': proof})
            result['actual_trial_receipts'].append({'stroke_mm': stroke,
                'path': proof['actual_receipt_path'], 'sha256': proof['actual_receipt_sha256'],
                'executed_input_sha256': row['input_sha256']})
            save()
            if row.get('accepted_solver') is not True:
                result.update(status='skipped_solver_failure', minimal_skip_status='actual_solver_rejected_no_retry')
                break
            if row.get('parsed') is not True:
                raise RuntimeError('Successful FE lacks required parsed evidence; stop shared pipeline.')
            if initial is not None and abs(row['metrics']['initial_error_mm']-initial) > 1e-10:
                raise ValueError('Candidate initial geometry differs from its actual C0 B source.')
            admissible, reason = rules.admissibility(row)
            if not admissible:
                # Missing/unknown extraction is a pipeline error. Measured
                # material/contact/load violations skip this condition.
                if any(word in reason for word in ('missing', 'nonfinite', 'unverified', 'cannot verify', 'could not')):
                    raise RuntimeError('Required physical evidence unavailable: ' + reason)
                result.update(status='skipped_inadmissible_candidate', minimal_skip_status=reason)
                break
            profile = engine.read_actual_profile(proof['actual_receipt_path'], record=row,
                execution_proof=proof, numerical_variant_id=variant)
            sources.update(profile['parent']['sources'])
            profiles[stroke] = profile
            j = row['metrics']['final_error_mm']
            if below_threshold(j, threshold):
                label = {k: cfg[k] for k in FEATURES}
                label.update(case_id=cfg['case_id'], feasible_stroke_mm=stroke,
                    initial_error_mm=row['metrics']['initial_error_mm'], final_error_mm=j,
                    threshold_mm=threshold, meets_threshold=True, selection_policy=POLICY,
                    candidate_count=len(result['trials']), peak_press_force_N=row['metrics'].get('peak_press_force_N'),
                    peak_prebend_force_N=row['metrics'].get('peak_prebend_force_N'),
                    max_ip_accumulated_plastic_strain=row['metrics']['max_ip_accumulated_plastic_strain'],
                    max_abs_ip_axial_total_strain=row['metrics']['max_abs_ip_axial_total_strain'],
                    actual_receipt_path=proof['actual_receipt_path'], actual_receipt_sha256=proof['actual_receipt_sha256'],
                    executed_input_sha256=row['input_sha256'], base_executed_input_sha256=row['base_executed_input_sha256'],
                    model_source_sha256=row['model_source_sha256'], execution_mode=mode,
                    numerical_variant=variant, protocol_version=cfg['protocol_version'],
                    qualified_for_formal_dataset=False, best_or_minimum_stroke_claimed=False,
                    actual_D_geometry_verified=True, final_tools_open_verified=True,
                    independent_initial_history_verified=True)
                result.update(status='first_feasible_found', complete=True, label=label)
                break
            if len(result['candidate_plans']) >= max_trials:
                break
            stroke, traces = next_proposal(cache, profiles, upper, first_stroke)
            result['proposal_ledger'].extend(traces)
            save()
        if result['status'] == 'actual_candidate_running':
            result.update(status='skipped_no_feasible_candidate_within_budget',
                minimal_skip_status='finite_candidate_budget_or_unique_proposals_exhausted')
        intact()
    except Exception as error:
        result.update(status='shared_pipeline_error', complete=False, label=None,
            exception=repr(error), traceback=traceback.format_exc(),
            minimal_skip_status='shared_source_parser_identity_or_control_error_stop_dependent_batch')
    save()
    return result
