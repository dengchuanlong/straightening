"""Actual-FE stroke search; unresolved/boundary results remain diagnostics.

Every candidate executes its own complete controlled history. This module does
not train a model or interpolate a label. Global formal qualification is owned
by the protocol/runner gates, not by the local search completing successfully.
"""
from pathlib import Path
from decimal import Decimal, ROUND_FLOOR
import argparse
import csv
import hashlib
import json
import math
import re
import time
import traceback

import numpy as np
from trial import BASE, run_trial
from solver_runner import ROOT, write_json

SEARCH_VERSION = 'RECT_SEARCH003_CONTACT_OPEN_EVIDENCE'
MODEL_SOURCE = Path(__file__).with_name('rect_model.py')
MATERIAL_DIR = ROOT.parent / 'auto_run_20261001' / 'material' / 'v002'
FIELDS = ['case_id','b_mm','h_mm','support_span_mm','punch_radius_mm','support_radius_mm','prebend_tool_stroke_mm','initial_error_mm','best_stroke_mm','final_error_mm','improvement_fraction','meets_0p05mm','stroke_bracket_width_mm','search_boundary','candidate_count','valid_candidate_count','max_ip_accumulated_plastic_strain','max_abs_ip_axial_total_strain','best_run','best_input_sha256','model_source_sha256','case_config_sha256','material_parameter_sha256','material_card_sha256','protocol_version','qualified_for_formal_dataset','search_version','search_settings_sha256','best_raw_sampled_stroke_mm','best_raw_sampled_final_error_mm']
TRIAL_FIELDS = ['case_id','stroke_mm','accepted_solver','parsed','admissible','initial_error_mm','final_error_mm','max_ip_accumulated_plastic_strain','max_abs_ip_axial_total_strain','seconds','directory','input_sha256','exclusion_reason','record_origin']
FAIL_FIELDS = ['case_id','stroke_mm','stage','problem','cause','impact','directory','case_excluded','record_origin']


def _json_sha(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode('utf-8')).hexdigest()


def _model_source_sha():
    return hashlib.sha256(MODEL_SOURCE.read_bytes()).hexdigest()


def _input_sha(config, stroke):
    from rect_model import build
    text,_ = build({**config,'stroke_mm':float(stroke)})
    return hashlib.sha256(text.encode('ascii')).hexdigest()


def csv_dump(path,fields,rows):
    path = Path(path)
    path.parent.mkdir(parents=True,exist_ok=True)
    temporary = path.with_suffix(path.suffix+'.writing')
    with temporary.open('w',encoding='utf-8-sig',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=fields,extrasaction='ignore')
        writer.writeheader()
        writer.writerows(rows)
    temporary.replace(path)


def admissibility(record):
    if not record.get('accepted_solver'):
        return False,'solver did not complete successfully'
    if not record.get('parsed'):
        return False,'required result quantities could not be extracted'
    m = record.get('metrics',{})
    required = ['initial_error_mm','final_error_mm','max_ip_accumulated_plastic_strain','max_abs_ip_axial_total_strain','final_press_force_N']
    try:
        if any(m.get(k) is None or not math.isfinite(float(m[k])) for k in required):
            return False,'missing or nonfinite required physical quantity'
    except (ValueError,TypeError):
        return False,'missing or nonfinite required physical quantity'
    if m['initial_error_mm']<0 or m['final_error_mm']<0:
        return False,'negative geometric deviation'
    if m['max_ip_accumulated_plastic_strain']>.0873690726826633+1e-8:
        return False,'local accumulated plastic strain exceeds declared calibration-history envelope'
    if m['max_abs_ip_axial_total_strain']>.02+1e-8:
        return False,'local axial total strain exceeds declared experimental axial envelope'
    for key in ('raw_IP_coverage_complete','raw_extrema_crosscheck_passed','contact_identity_verified',
                'initial_all_tools_open','final_all_tools_open'):
        if m.get(key) is not True:
            return False,'unverified raw field extraction: '+key
    # Far-field contact data are omitted by Ansys. Keep missing raw listings
    # as missing; positive nodal separation plus each tool's RF vector is an
    # independent proof of unloaded open contact, rather than fabricated zeros.
    trajectory=m.get('strain_trajectory',{})
    if trajectory.get('requested') is not True or trajectory.get('checkpoint_extrema_verified') is not True:
        return False,'complete converged-substep axial strain extraction is unverified'
    contact_pen=m.get('max_contact_penetration_mm')
    if contact_pen is None or not math.isfinite(float(contact_pen)) or float(contact_pen)>.02:
        return False,'available key-state local contact penetration exceeds or cannot verify pilot screen'
    force_bound=m.get('final_max_tool_force_vector_bound_N')
    if force_bound is None or not math.isfinite(float(force_bound)) or float(force_bound)>.1:
        return False,'final individual tool reaction vector is missing or remains loaded'
    if abs(m['final_press_force_N'])>.1:
        return False,'press still loaded in final state'
    state=m.get('states',{}).get('D',{})
    for key in ('punch_force_N','support_force_N','prebend_head_force_N','prebend_support_force_N'):
        value=state.get(key)
        if value is None or not math.isfinite(float(value)):
            return False,'missing final free-unload tool reaction: '+key
        if abs(float(value))>.1:
            return False,'tool still loaded in final free state: '+key
    return True,''


def _countable_search(result):
    label=result.get('label')
    return bool(label and result.get('complete') is True
                and result.get('search_acceptance_passed') is True
                and result.get('bracket_resolution_met') is True
                and result.get('all_identified_valleys_resolved') is True
                and result.get('search_boundary') is False)


def record_tables():
    """Summarize searches and all saved completed standalone trial attempts.

    A solver-only failed attempt is retained even if trial postprocessing never
    created trial_result.json. Running attempts are not invented as failures.
    """
    labels,trials,failures,diagnostics = [],[],[],[]
    seen=set()
    case_completion={}

    def include(item,origin,case_excluded):
        key=(item.get('directory',''),item.get('input_sha256',''),item.get('case_id'),item.get('stroke_mm'))
        if key in seen:
            return
        seen.add(key)
        valid,reason=admissibility(item)
        metric=item.get('metrics',{})
        summary={**item,**metric,'admissible':valid,'seconds':item.get('solver_status',{}).get('seconds'),'exclusion_reason':reason,'record_origin':origin}
        trials.append({key:summary.get(key) for key in TRIAL_FIELDS})
        if not valid:
            failures.append({'case_id':item.get('case_id'),'stroke_mm':item.get('stroke_mm'),'stage':'solve_or_postprocess_or_material_screen','problem':reason,'cause':item.get('parse_error') or item.get('exception') or item.get('solver_status',{}).get('exception') or 'Unknown; see preserved output and receipts. Nonconvergence alone does not identify a cause.','impact':'candidate/diagnostic excluded; no fabricated label','directory':item.get('directory',''),'case_excluded':case_excluded,'record_origin':origin})

    results=sorted((ROOT/'cases').glob('*/search_result.json')) if (ROOT/'cases').exists() else []
    for result_path in results:
        search=json.loads(result_path.read_text(encoding='utf-8-sig'))
        complete=_countable_search(search)
        case_completion[search['case_id']]=complete
        if complete:
            labels.append(search['label'])
        else:
            diagnostic=search.get('diagnostic_label') or search.get('label')
            if diagnostic:
                diagnostics.append({**diagnostic,'diagnostic_reasons':' | '.join(search.get('incompletion_reasons') or ['legacy/unaccepted search; not a complete label'])})
        for item in search.get('trials',[]):
            include(item,'stroke_search',not complete)
        if not complete and (search.get('exception') or search.get('incompletion_reasons')):
            failures.append({'case_id':search['case_id'],'stage':'search','problem':search.get('exception') or ' | '.join(search['incompletion_reasons']),'cause':'See search_result.json; search incompleteness is distinct from solver nonconvergence.','impact':'diagnostic only; case not counted as a completed label','case_excluded':True,'record_origin':'stroke_search'})
    for record_path in sorted((ROOT/'runs').glob('*/*/trial_result.json')) if (ROOT/'runs').exists() else []:
        item=json.loads(record_path.read_text(encoding='utf-8-sig'))
        include(item,'standalone_or_saved_candidate',not case_completion.get(item.get('case_id'),False))
    for status_path in sorted((ROOT/'runs').glob('*/*/solver_status.json')) if (ROOT/'runs').exists() else []:
        folder=status_path.parent
        if (folder/'trial_result.json').exists():
            continue
        status=json.loads(status_path.read_text(encoding='utf-8-sig'))
        if status.get('accepted_exit') is not False:
            continue
        config_path=folder/'config.json'
        config=json.loads(config_path.read_text(encoding='utf-8-sig')) if config_path.exists() else {}
        item={'case_id':config.get('case_id',folder.parent.name),'stroke_mm':config.get('stroke_mm'),'directory':str(folder.relative_to(ROOT)),'input_sha256':status.get('input_sha256'),'accepted_solver':False,'parsed':False,'solver_status':status}
        include(item,'solver_only_failed_attempt',True)
    csv_dump(ROOT/'dataset'/'labels.csv',FIELDS,labels)
    csv_dump(ROOT/'dataset'/'diagnostics.csv',FIELDS+['diagnostic_reasons'],diagnostics)
    csv_dump(ROOT/'dataset'/'trials.csv',TRIAL_FIELDS,trials)
    csv_dump(ROOT/'dataset'/'failures.csv',FAIL_FIELDS,failures)
    return labels,trials,failures


def _usable(cache,low=None,high=None):
    return sorted((r for s,r in cache.items() if (low is None or s>=low-1e-9)
                   and (high is None or s<=high+1e-9) and admissibility(r)[0]),key=lambda r:r['stroke_mm'])


def _best(usable):
    return min(usable,key=lambda r:(r['metrics']['final_error_mm'],r['stroke_mm']))


def _neighborhood(usable,selected,resolution):
    index=next(i for i,r in enumerate(usable) if r['stroke_mm']==selected['stroke_mm'])
    if index==0 or index==len(usable)-1:
        return {'boundary':True,'left_mm':None,'right_mm':None,'width_mm':None,'resolved':False,'proposals':[]}
    left,right=usable[index-1]['stroke_mm'],usable[index+1]['stroke_mm']
    width=right-left
    return {'boundary':False,'left_mm':left,'right_mm':right,'width_mm':width,'resolved':width<=resolution+1e-9,
            'proposals':[(left+selected['stroke_mm'])/2,(selected['stroke_mm']+right)/2]}


def _valleys(coarse,cache,noise):
    usable=[cache[round(float(s),6)] for s in coarse if admissibility(cache[round(float(s),6)])[0]]
    intervals=[]
    for i in range(1,len(usable)-1):
        a,b,c=usable[i-1:i+2]
        ea,eb,ec=[r['metrics']['final_error_mm'] for r in (a,b,c)]
        if eb<=ea+noise and eb<=ec+noise and eb<max(ea,ec)-noise:
            intervals.append({'valley_id':len(intervals)+1,'screening_stroke_mm':b['stroke_mm'],'low_mm':a['stroke_mm'],'high_mm':c['stroke_mm']})
    return intervals


def _valley_status(valley,cache,resolution):
    usable=_usable(cache,valley['low_mm'],valley['high_mm'])
    if len(usable)<3:
        return {**valley,'resolved':False,'boundary':True,'proposals':[],'reason':'fewer than three admissible local candidates'}
    best=_best(usable)
    neighborhood=_neighborhood(usable,best,resolution)
    return {**valley,**neighborhood,'best_mm':best['stroke_mm'],'best_error_mm':best['metrics']['final_error_mm']}


def _selection(cache,resolution,tie):
    usable=_usable(cache)
    if not usable:
        return usable,None,None,None,None
    raw_best=_best(usable)
    near=[r for r in usable if r['metrics']['final_error_mm']<=raw_best['metrics']['final_error_mm']+tie]
    representative=min(near,key=lambda r:r['stroke_mm'])
    return usable,raw_best,representative,_neighborhood(usable,raw_best,resolution),_neighborhood(usable,representative,resolution)


def _label(config,selected,raw_best,neighbors,result,cache):
    m=selected['metrics']
    initial=m['initial_error_mm']
    return {**config,'initial_error_mm':initial,'best_stroke_mm':selected['stroke_mm'],'final_error_mm':m['final_error_mm'],
            'improvement_fraction':1-m['final_error_mm']/initial if initial>0 else None,'meets_0p05mm':m['final_error_mm']<=.05,
            'stroke_bracket_width_mm':neighbors['width_mm'],'search_boundary':neighbors['boundary'],
            'candidate_count':len(cache),'valid_candidate_count':len(_usable(cache)),
            'max_ip_accumulated_plastic_strain':m['max_ip_accumulated_plastic_strain'],'max_abs_ip_axial_total_strain':m['max_abs_ip_axial_total_strain'],
            'best_run':selected['directory'],'best_input_sha256':selected['input_sha256'],'model_source_sha256':selected['model_source_sha256'],
            'case_config_sha256':result['case_config_sha256'],
            'material_parameter_sha256':hashlib.sha256((MATERIAL_DIR/'candidate_material.json').read_bytes()).hexdigest(),
            'material_card_sha256':hashlib.sha256((MATERIAL_DIR/'candidate_material.inp').read_bytes()).hexdigest(),
            'protocol_version':config.get('protocol_version','pilot_model_draft'),'qualified_for_formal_dataset':False,
            'search_version':SEARCH_VERSION,'search_settings_sha256':result['search_settings_sha256'],
            'best_raw_sampled_stroke_mm':raw_best['stroke_mm'],'best_raw_sampled_final_error_mm':raw_best['metrics']['final_error_mm']}


def search(config,upper=None,resolution=.02,max_trials=28,timeout=2400,*,screening_n=7,tie_error_mm=0.,screening_noise_mm=0.):
    config={**BASE,**config}
    case_id=str(config['case_id'])
    if not re.fullmatch(r'[A-Za-z0-9_-]{1,100}',case_id):
        raise ValueError('Case ID must contain only letters, digits, underscores or hyphens.')
    requested_upper=float(upper if upper is not None else max(8.,1.6*config['prebend_tool_stroke_mm']))
    if not math.isfinite(requested_upper):
        raise ValueError('Search upper limit must be finite.')
    # All actual candidate strokes have six decimal places. Quantize the upper
    # limit downward so rounding the screening endpoint never goes outside it.
    upper=float(Decimal(str(requested_upper)).quantize(Decimal('0.000001'),rounding=ROUND_FLOOR))
    settings={'version':SEARCH_VERSION,'requested_upper_mm':requested_upper,'upper_mm':upper,'resolution_mm':float(resolution),'max_trials':int(max_trials),
              'timeout_s':float(timeout),'screening_n':int(screening_n),'tie_error_mm':float(tie_error_mm),'screening_noise_mm':float(screening_noise_mm)}
    if any(not math.isfinite(settings[k]) for k in ('upper_mm','resolution_mm','timeout_s','tie_error_mm','screening_noise_mm')):
        raise ValueError('Search settings must be finite.')
    if upper<=0 or resolution<2e-6 or timeout<=0 or tie_error_mm<0 or screening_noise_mm<0:
        raise ValueError('Invalid search interval, precision, timeout or noise/tie allowance.')
    if screening_n!=int(screening_n) or screening_n<7 or max_trials!=int(max_trials) or max_trials<screening_n:
        raise ValueError('At least seven screening candidates and a sufficient integer trial budget are required.')
    folder=ROOT/'cases'/case_id
    previous=folder/'search_result.json'
    model_sha=_model_source_sha()
    config_sha=_json_sha(config)
    settings_sha=_json_sha(settings)
    source_sha=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    result={'case_id':case_id,'config':config,'case_config_sha256':config_sha,'search_version':SEARCH_VERSION,
            'search_source_sha256':source_sha,'model_source_sha256':model_sha,'search_settings':settings,
            'search_settings_sha256':settings_sha,'search_upper_mm':upper,'resolution_mm':float(resolution),
            'trials':[],'label':None,'diagnostic_label':None,'complete':False,'search_acceptance_passed':False,
            'qualified_for_formal_dataset':False,'global_optimum_proven':False,'incompletion_reasons':[]}
    cache={}
    if previous.exists():
        saved=json.loads(previous.read_text(encoding='utf-8-sig'))
        if saved.get('case_config_sha256')!=config_sha:
            raise RuntimeError('Preserved case ID has a different config; use a new case ID.')
        if saved.get('search_settings_sha256')!=settings_sha or saved.get('search_source_sha256')!=source_sha:
            raise RuntimeError('Preserved case ID has different search settings/algorithm source; use a new case ID rather than reuse an old decision.')
        if saved.get('model_source_sha256')!=model_sha:
            raise RuntimeError('Preserved case has another model/parser source; preserve it and use a new case ID.')
        for trial in saved.get('trials',[]):
            stroke=round(float(trial['stroke_mm']),6)
            if trial.get('input_sha256')!=_input_sha(config,stroke) or trial.get('model_source_sha256')!=model_sha:
                raise RuntimeError('Saved candidate input/model SHA does not match; preserve it and use a new case ID.')
            if stroke in cache:
                raise RuntimeError('Saved search has duplicate stroke records; inspect without overwriting.')
            cache[stroke]=trial
        result['trials']=saved.get('trials',[])
    folder.mkdir(parents=True,exist_ok=True)

    def publish_current():
        if ROOT.resolve()!=Path(__file__).resolve().parents[1]:return
        progress_path=ROOT/'progress.json'
        status=json.loads(progress_path.read_text(encoding='utf-8')) if progress_path.exists() else {}
        status.update(current_case=case_id,current_case_trials=len(cache),
                      current_case_admissible_trials=sum(admissibility(v)[0] for v in cache.values()))
        write_json(progress_path,status)
        from update_report import update
        update(scan_runs=False)

    def save(final=False):
        write_json(previous,result)
        curve=[]
        for item in result['trials']:
            valid,reason=admissibility(item)
            summary={**item,**item.get('metrics',{}),'admissible':valid,
                     'seconds':item.get('solver_status',{}).get('seconds'),
                     'exclusion_reason':reason,'record_origin':'stroke_search'}
            curve.append({key:summary.get(key) for key in TRIAL_FIELDS})
        csv_dump(folder/'candidate_curve.csv',TRIAL_FIELDS,curve)
        if final:record_tables()
        publish_current()

    def sample(s):
        stroke=round(float(s),6)
        if not -1e-9<=stroke<=upper+1e-9:
            raise ValueError('Candidate outside the declared range.')
        if stroke in cache:
            return False
        if len(cache)>=max_trials:
            return False
        signature=_input_sha(config,stroke)
        if ROOT.resolve()==Path(__file__).resolve().parents[1]:
            progress_path=ROOT/'progress.json'
            status=json.loads(progress_path.read_text(encoding='utf-8')) if progress_path.exists() else {}
            status.update(current_case=case_id,current_stroke_mm=stroke)
            write_json(progress_path,status)
            from update_report import update
            update(scan_runs=False)
        start=time.monotonic()
        integrity_failure=False
        try:
            item=run_trial(config,stroke,timeout)
            if item.get('input_sha256')!=signature or item.get('model_source_sha256')!=model_sha:
                integrity_failure=True
                raise RuntimeError('Candidate input/model source changed during the search; not accepted.')
        except Exception as error:
            item={'case_id':case_id,'stroke_mm':stroke,'directory':'','input_sha256':signature,'model_source_sha256':model_sha,
                  'accepted_solver':False,'parsed':False,'exception':repr(error),'traceback':traceback.format_exc(),
                  'solver_status':{'seconds':time.monotonic()-start,'exception':repr(error)}}
        cache[stroke]=item
        result['trials'].append(item)
        save()
        if integrity_failure:
            raise RuntimeError('Physical input/model integrity changed; stop this search rather than treating it as an isolated failed candidate.')
        return True

    try:
        coarse=np.round(np.linspace(0,upper,screening_n),6)
        for s in coarse:
            sample(float(s))
        result['coarse_screening_strokes_mm']=coarse.tolist()
        result['coarse_screening_exclusions']=[{'stroke_mm':float(s),'reason':admissibility(cache[float(s)])[1]}
            for s in coarse if not admissibility(cache[float(s)])[0]]
        valleys=_valleys(coarse,cache,screening_noise_mm)
        result['identified_screening_valleys']=valleys
        # Every frozen screening valley is refined in round-robin order.
        # A secondary valley cannot be dropped because the first valley looks
        # better. Actual points, including failures, remain in the cache/log.
        while True:
            statuses=[_valley_status(v,cache,resolution) for v in valleys]
            usable,raw_best,selected,raw_neighbors,selected_neighbors=_selection(cache,resolution,tie_error_mm)
            if not usable:
                break
            all_resolved=bool(statuses) and all(v['resolved'] for v in statuses)
            if all_resolved and raw_neighbors['resolved'] and selected_neighbors['resolved']:
                break
            if len(cache)>=max_trials:
                break
            created=False
            for status in statuses:
                if status['resolved']:
                    continue
                for proposal in status.get('proposals',[]):
                    created=sample(proposal) or created
            # Numerical ties may select a lower-stroke tested representative
            # outside the narrow raw-best bracket; it needs its own neighbors.
            for neighborhood in (raw_neighbors,selected_neighbors):
                if not neighborhood['resolved']:
                    for proposal in neighborhood.get('proposals',[]):
                        created=sample(proposal) or created
            if not created:
                break
        statuses=[_valley_status(v,cache,resolution) for v in valleys]
        usable,raw_best,selected,raw_neighbors,selected_neighbors=_selection(cache,resolution,tie_error_mm)
        reasons=[]
        if not usable:
            reasons.append('no admissible actual FE candidates')
        if not statuses:
            reasons.append('no interior valley identified by the actual coarse screening')
        if statuses and not all(v['resolved'] for v in statuses):
            reasons.append('one or more identified screening valleys are unresolved')
        if selected is not None:
            if raw_neighbors['boundary'] or selected_neighbors['boundary']:
                reasons.append('best or tie-selected candidate lies on the sampled/admissible boundary')
            if not raw_neighbors['resolved'] or not selected_neighbors['resolved']:
                reasons.append('actual two-sided selected/best neighborhood has not met the declared resolution')
        if reasons and len(cache)>=max_trials:
            reasons.append('trial budget exhausted before accepted completion')
        result['refined_valleys']=statuses
        result['all_identified_valleys_resolved']=bool(statuses) and all(v['resolved'] for v in statuses)
        result['search_boundary']=bool(selected is not None and (raw_neighbors['boundary'] or selected_neighbors['boundary']))
        result['bracket_resolution_met']=bool(selected is not None and raw_neighbors['resolved'] and selected_neighbors['resolved'])
        result['raw_best_neighborhood']=raw_neighbors
        result['selected_neighborhood']=selected_neighbors
        result['incompletion_reasons']=reasons
        if selected is not None:
            value=_label(config,selected,raw_best,selected_neighbors,result,cache)
            if not reasons:
                result.update(label=value,diagnostic_label=None,complete=True,search_acceptance_passed=True)
            else:
                result.update(label=None,diagnostic_label=value,complete=False,search_acceptance_passed=False)
    except Exception as error:
        result.update(exception=repr(error),traceback=traceback.format_exc(),label=None,complete=False,search_acceptance_passed=False)
        result['incompletion_reasons'].append('search exception; no complete label')
    save(final=True)
    return result


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--config')
    parser.add_argument('--case-id',default='BASE_SEARCH')
    parser.add_argument('--upper',type=float)
    parser.add_argument('--resolution',type=float,default=.02)
    parser.add_argument('--max-trials',type=int,default=28)
    parser.add_argument('--timeout',type=float,default=2400)
    parser.add_argument('--screening-n',type=int,default=7)
    parser.add_argument('--tie-error-mm',type=float,default=0.)
    parser.add_argument('--screening-noise-mm',type=float,default=0.)
    args=parser.parse_args()
    config=json.loads(Path(args.config).read_text(encoding='utf-8-sig')) if args.config else BASE.copy()
    config['case_id']=args.case_id
    result=search(config,args.upper,args.resolution,args.max_trials,args.timeout,
                  screening_n=args.screening_n,tie_error_mm=args.tie_error_mm,screening_noise_mm=args.screening_noise_mm)
    print(json.dumps({k:v for k,v in result.items() if k not in ('trials','traceback')},ensure_ascii=False,indent=2),flush=True)
    raise SystemExit(0 if result.get('complete') else 1)
