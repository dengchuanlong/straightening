"""Read-only reanalysis of the already solved C0; no FE/POST/branch creation.

Two narrowly scoped output-recognition adapters reuse the frozen parse_base
code object, with separate globals and captured writes. A new canonical base
receipt candidate is returned separately; this adapter never writes into BASE.
"""
import argparse
import ast
import copy
import hashlib
import json
import math
import os
import re
import traceback
import types
from datetime import datetime, timezone
from pathlib import Path
import numpy as np
import warm_restart as original

ROOT = original.ROOT
BASE = ROOT / 'warm/BASE_C0_EXEC001'
OUT = ROOT / 'report/warm_guard_recovery_v001'
PLAN = OUT / 'preparation.json'
CHECKS = OUT / 'software_checks.json'
RECEIPT = OUT / 'reanalysis_receipt.json'
FAILURE = ROOT / 'logs/warm_stage_v002.json'
BUDGETS = ROOT / 'protocol/pilot_acceptance_budgets_v001.json'
EXPECTED_ORIGINAL = '1d0f894e430505b6ccd862893076c75b100beace994d46c4a5c676ebfadf7f01'
HEADER_BYTES = 65536
MACHINE_HEADER = re.compile(rb'^\s*RELEASE\s*[=:]\s*(\d{4})\s+(R\d+)\s+BUILD\s*[=:]\s*([\d.]+)\s+(UP\d{8})\s+VERSION\s*[=:]\s*(WINDOWS\s+x64)\s*$', re.I | re.M)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def exclusive_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False).encode('utf-8')
    with path.open('xb') as stream:
        stream.write(payload)
    return hashlib.sha256(payload).hexdigest()


def header_evidence(raw):
    matches = list(MACHINE_HEADER.finditer(raw[:HEADER_BYTES]))
    if len(matches) != 1:
        raise ValueError('Require exactly one real release/build/platform machine header in the first 64 KiB.')
    match = matches[0]
    year, release, build, update, platform = [x.decode('ascii').strip() for x in match.groups()]
    if (year, release.upper(), build, re.sub(r'\s+', ' ', platform).upper()) != ('2026', 'R1', '26.1', 'WINDOWS X64'):
        raise ValueError('Actual machine header identifies a different release/build/platform.')
    line_start = raw.rfind(b'\n', 0, match.start()) + 1
    line_end = raw.find(b'\n', match.end())
    line_end = len(raw) if line_end < 0 else line_end
    # Regex whitespace can begin on preceding empty lines: evidence identifies
    # the exact RELEASE line, rather than relabeling those blank lines.
    marker = re.search(rb'RELEASE', match.group(), re.I)
    offset = match.start() + marker.start()
    line_start = raw.rfind(b'\n', 0, offset) + 1
    line_end = raw.find(b'\n', offset)
    line_end = len(raw) if line_end < 0 else line_end
    actual_line = raw[line_start:line_end].rstrip(b'\r')
    return dict(year=year, release=release, build=build, update=update, platform=platform,
                original_line_1based=raw[:offset].count(b'\n') + 1,
                release_byte_offset=offset, original_line_byte_offset=line_start,
                original_line=actual_line.decode('ascii'), original_line_sha256=hashlib.sha256(actual_line).hexdigest(),
                whole_output_sha256=hashlib.sha256(raw).hexdigest(), header_window_bytes=HEADER_BYTES,
                old_first5000_regex_matched=bool(re.search(rb'RELEASE\s+2026\s+R1', raw[:5000], re.I)))


def validate_status(status, meta):
    if status.get('software_mock') or status.get('accepted_exit') is not True:
        raise ValueError('The original actual solver did not accept this attempt.')
    if status.get('returncode') != 0 or status.get('error_count') != 0 or status.get('timed_out') is not False or status.get('exception') is not None:
        raise ValueError('Original solver failure/timeout/errors remain rejected.')
    if status.get('input_sha256') != meta.get('input_sha256'):
        raise ValueError('Actual original input identity differs.')
    if type(status.get('cores')) is not int or status['cores'] != meta.get('solver_cores'):
        raise ValueError('Core count differs from original preparation.')
    tree = status.get('process_tree', {})
    ids = tree.get('identities')
    if tree.get('tree_exit_confirmed') is not True or tree.get('live_identities') != [] or tree.get('identity_errors') != [] or not ids:
        raise ValueError('Actual original owned process tree exit is not verified.')
    if any(type(x.get('pid')) is not int or x['pid'] <= 0 or isinstance(x.get('create_time'), bool) or not math.isfinite(float(x.get('create_time', float('nan')))) for x in ids):
        raise ValueError('Invalid actual owned-process identity.')
    if not status.get('expected_files') or not all(value is True for value in status['expected_files'].values()):
        raise ValueError('Original expected-file acceptance is missing.')
    return status


def summary_records(text):
    """Actual v261 FILE_SUMMARY block format; explicit filenames, never guesses."""
    number = r'[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[EDed][+-]?\d+)?'
    row_pattern = re.compile(r'^\s*(' + number + r')\s+(' + number + r')\s+(' + number + r')\s+(' + number + r')\s+(' + number + r')\s*$')
    records, pending, header_seen = [], None, False
    for no, line in enumerate(text.splitlines(), 1):
        filename = re.fullmatch(r'\s*RESTART FILE INFO\s*-\s*FILENAME:\s*(solve\.r\d{3})\s*', line, re.I)
        if filename:
            if pending is not None:
                raise ValueError('Incomplete FILE_SUMMARY file block.')
            name = filename[1].lower()
            if not 1 <= int(name[-3:]) <= 999:
                raise ValueError('Invalid actual restart file number.')
            pending = dict(filename=name, filename_line_1based=no, filename_original_line=line)
            header_seen = False
            continue
        if pending is None:
            if records and line.strip():
                raise ValueError('Unexpected trailing data in actual FILE_SUMMARY.')
            continue
        if not line.strip():
            continue
        if not header_seen:
            if not re.fullmatch(r'\s*LOADSTEP\s+SUBSTEP\s+BEGINNING\s+TIME\s+CURRENT\s+TIME\s+END\s+TIME\s*', line, re.I):
                raise ValueError('Unrecognized actual FILE_SUMMARY column header.')
            header_seen = True
            pending.update(column_header_line_1based=no, column_header_original_line=line)
            continue
        row = row_pattern.fullmatch(line)
        if row is None:
            raise ValueError('Actual FILE_SUMMARY must contain all five numeric columns.')
        ls, ss, start, current, end = [float(x.replace('D', 'E').replace('d', 'e')) for x in row.groups()]
        if not all(math.isfinite(v) for v in (ls, ss, start, current, end)) or ls != int(ls) or ss != int(ss) or ls < 1 or ss < 1 or start < 0 or not start <= current <= end:
            raise ValueError('Invalid actual FILE_SUMMARY identity/time interval.')
        pending.update(load_step=int(ls), substep=int(ss), time=current, beginning_time=start, end_time=end,
                       original_line_1based=no, original_line=line)
        records.append(pending)
        pending = None
    if pending is not None or not records or len({r['filename'] for r in records}) != len(records):
        raise ValueError('Missing, incomplete or ambiguous actual FILE_SUMMARY.')
    return records


def strict_parse_file_summary(path):
    return summary_records(Path(path).read_text(encoding='ascii', errors='strict'))


def strict_solver_complete(folder, meta):
    folder = Path(folder).resolve()
    checked_folder, saved_meta = original._read_preparation(folder)
    if checked_folder != folder or saved_meta != meta or sha(original.__file__) != EXPECTED_ORIGINAL:
        raise ValueError('Actual original preparation/source differs from the supplied metadata.')
    status = validate_status(read(folder / 'solver_status.json'), meta)
    for name in meta['expected_files']:
        if status['expected_files'].get(name) is not True or not (folder / name).is_file() or (folder / name).stat().st_size == 0:
            raise ValueError('Actual original expected field/input file unavailable: ' + name)
    if sha(folder / 'input.inp') != meta['input_sha256']:
        raise ValueError('Actual input bytes changed.')
    if any('*** ERROR ***' in (folder / name).read_text(encoding='ascii', errors='replace') for name in ('solve.out', 'solve.err')):
        raise ValueError('Original solver output has an explicit ERROR; cannot repair physical failure.')
    if sha(Path(status['process_utility_source'])) != status['process_utility_sha256']:
        raise ValueError('Original owned-process utility source changed.')
    header_evidence((folder / 'solve.out').read_bytes())
    return status


def original_sources():
    folder, meta = original._read_preparation(BASE)
    if sha(original.__file__) != EXPECTED_ORIGINAL or meta['mode'] != 'base':
        raise ValueError('Require the original frozen warm V001 C0 preparation.')
    failure = read(FAILURE)
    if failure.get('finished') is not True or failure.get('actual_solver_runs_started') != 1 or failure.get('actual_solver_runs_successful') != 1 or failure.get('error') != "ValueError('Actual output does not identify the required 2026 R1 release.')":
        raise ValueError('Require preserved original version-guard failure; no generic failure bypass.')
    status = strict_solver_complete(folder, meta)
    if not any(x.get('actual_input_sha256') == meta['input_sha256'] and x.get('actual_solver_success_verified') is True and x.get('solver_status_sha256') == sha(BASE / 'solver_status.json') for x in failure.get('solver_attempts', [])):
        raise ValueError('Original failed API stage does not bind this successful solver attempt.')
    text, rebuilt = original.build_base(meta['core_metadata']['config'])
    if hashlib.sha256(text.encode('ascii')).hexdigest() != meta['input_sha256'] or rebuilt['physical_prefix_sha256'] != meta['physical_prefix_sha256']:
        raise ValueError('Frozen original physical generator does not reproduce actual C0 input.')
    material = Path(meta['core_metadata']['material_file'])
    if sha(material) != meta['core_metadata']['material_sha256']:
        raise ValueError('Actual original material card changed.')
    return folder, meta, status, material


def prepare():
    if PLAN.exists() or RECEIPT.exists() or (BASE / 'base_restart_receipt.json').exists():
        raise FileExistsError('Preserve original/new preparations and any existing canonical receipt.')
    folder, meta, status, material = original_sources()
    immutable = original._hashes(folder)
    sources = [Path(__file__), Path(original.__file__), original.CORE, original.EXE, material, FAILURE, BUDGETS,
               ROOT / 'report/warm_stage_preparation_v003.json', Path(status['process_utility_source'])]
    value = dict(schema_version='WARM_GUARD_RECOVERY_PREPARATION_V001', prepared_UTC=datetime.now(timezone.utc).isoformat(),
                 base=str(folder), original_input_sha256=meta['input_sha256'], original_failure=read(FAILURE)['error'],
                 source_pins={str(p): sha(p) for p in sources}, original_base_files=immutable,
                 version_header=header_evidence((folder / 'solve.out').read_bytes()),
                 actual_file_summary_records=strict_parse_file_summary(folder / 'restart_file_summary.txt'),
                 adapters=['strict actual release/build/platform header', 'strict actual FILE_SUMMARY block recognition'],
                 original_parse_base_code_sha256=hashlib.sha256(original.parse_base.__code__.co_code).hexdigest(),
                 canonical_publication_deferred_to_root=True, canonical_candidate_payload_only=True, FE_POST_ML_invocations=0, branches_prepared=0,
                 formal_restart_enabled=False, formal_generation_unlocked=False)
    exclusive_json(PLAN, value)
    return value


def software_checks():
    if CHECKS.exists():
        raise FileExistsError('Preserve prior software checks.')
    checks = []
    def test(name, action, rejection=False):
        try:
            value = action(); passed = not rejection and value is not False
        except Exception:
            passed = rejection
        checks.append(dict(check=name, passed=bool(passed)))
    good = b'Ansys Mechanical Enterprise Academic Student\n RELEASE= 2026 R1 BUILD= 26.1 UP20260202 VERSION=WINDOWS x64\n'
    test('machine_release_equals_real_format', lambda: header_evidence(good)['original_line_1based'] == 2)
    for name, bad in [('legal_year_only', b'ANSYS MAPDL 2026 R1 LEGAL NOTICES\n'), ('wrong_release', good.replace(b'2026', b'2025')), ('wrong_build', good.replace(b'26.1', b'26.2')), ('wrong_platform', good.replace(b'WINDOWS x64', b'LINUX x64')), ('body_only', b'x' * HEADER_BYTES + b'\n' + good), ('duplicate_header', good + good)]:
        test('reject_' + name, lambda bad=bad: header_evidence(bad), True)
    summary = '******* MULTIFRAME RESTART FILES SUMMARY ******\n\n RESTART FILE INFO - FILENAME: solve.r099\n LOADSTEP SUBSTEP BEGINNING TIME CURRENT TIME END TIME\n 6 2 5.0000 6.0000 6.0000\n'
    test('actual_block_explicit_filename_not_guessed_r006', lambda: summary_records(summary)[0]['filename'] == 'solve.r099')
    for name, bad in [('duplicate_filename', summary + summary.split('\n\n')[1]), ('missing_columns', summary.replace('6 2 5.0000 6.0000 6.0000', '6 2 6.0000')), ('bad_interval', summary.replace('5.0000', '7.0000')), ('noninteger_step', summary.replace('6 2 5.0000', '6.1 2 5.0000')), ('missing_filename', summary.replace('solve.r099', 'unknown.rdb'))]:
        test('reject_summary_' + name, lambda bad=bad: summary_records(bad), True)
    meta = {'input_sha256': 'a' * 64, 'solver_cores': 4}
    accepted = {'accepted_exit': True, 'input_sha256': 'a' * 64, 'returncode': 0, 'error_count': 0, 'timed_out': False, 'exception': None, 'cores': 4,
                'expected_files': {'solve.rst': True}, 'process_tree': {'tree_exit_confirmed': True, 'live_identities': [], 'identity_errors': [], 'identities': [{'pid': 42, 'create_time': 123.}]}}
    test('actual_status_requires_original_exit_proof', lambda: validate_status(accepted, meta))
    for name, changed in [('solver_error', {'error_count': 1}), ('wrong_input', {'input_sha256': 'b' * 64}), ('mock', {'software_mock': True}), ('wrong_cores', {'cores': 2}), ('live_tree', {'process_tree': {**accepted['process_tree'], 'live_identities': [{'pid': 42}]}}), ('missing_expected', {'expected_files': {}})]:
        test('reject_status_' + name, lambda changed=changed: validate_status({**accepted, **changed}, meta), True)
    original_guard = original._solver_complete
    cloned, captured = _receipt_clone(original.parse_base, BASE, 'base_restart_receipt.json')
    test('original_parse_code_object_preserved', lambda: cloned.__code__ is original.parse_base.__code__)
    test('original_module_globals_not_patched', lambda: original._solver_complete is original_guard and cloned.__globals__ is not original.parse_base.__globals__)
    test('unexpected_captured_write_rejected', lambda: cloned.__globals__['write_json'](BASE / 'input.inp', {}), True)
    comparison_reader, comparison_capture = _comparison_reader(BASE)
    test('single_cold_header_AST_clone_compiles_without_run', lambda: callable(comparison_reader) and comparison_capture == [])
    cold12 = read(ROOT / 'report/warm_stage_preparation_v003.json')['cold12_folder']
    test('existing_actual_cold12_header_and_source_guard', lambda: strict_cold_header(cold12))
    result = dict(schema_version='WARM_GUARD_ADAPTER_SOFTWARE_CHECKS_V001', adapter_sha256=sha(__file__), checks=checks,
                  passed=all(x['passed'] for x in checks), FE_POST_ML_invocations=0, software_checks_are_not_actual_FE=True)
    exclusive_json(CHECKS, result)
    return result


def verify_pins(plan):
    for path, digest in plan['source_pins'].items():
        if sha(path) != digest:
            raise ValueError('Frozen recovery source changed: ' + path)
    original._verify_hashes(BASE, plan['original_base_files'])


def physical_recheck(receipt, meta, folder=BASE):
    folder = Path(folder)
    r = original.rect_model
    budgets = read(BUDGETS)
    core = meta['core_metadata']
    domain = budgets['material_domain']
    states = receipt['states']
    if any(s['max_p'] > domain['maximum_accumulated_plastic_strain'] + 1e-8 for s in states.values()) or receipt['max_path_abs_axial_total_strain'] > domain['maximum_absolute_axial_total_strain'] + 1e-8:
        raise ValueError('Existing base is outside the declared material domain.')
    if not all(t['independently_open_by_geometry_and_RF'] for t in states['B']['contact_by_tool'].values()):
        raise ValueError('Actual B tools are not fully unloaded/open.')
    if states['B']['max_p'] <= 0:
        raise ValueError('Initial residual plastic history is absent.')
    loaded = []
    for state in ('A', 'C0'):
        for name, tool in states[state]['contact_by_tool'].items():
            value = tool['max_available_point_penetration_mm']
            if value is not None:
                if not math.isfinite(value) or value > budgets['loaded_contact']['maximum_penetration_mm']:
                    raise ValueError('Available original local penetration fails the declared screen.')
                loaded.append(dict(state=state, tool=name, max_available_point_penetration_mm=value))
    if not any(x['state'] == 'A' for x in loaded):
        raise ValueError('Actual loaded pre-bend contact evidence missing.')
    fields, axes = {}, {}
    for state in ('B', 'C0'):
        u = r._load(folder / f'state_{state}_nodes.txt', 3, core['mesh_count']['work_nodes'])
        axes[state] = r._centroid_axis(u, core)[0]
        fields[state] = {key: r._presol_records(folder / f'state_{state}_{suffix}.txt', columns)
                         for key, suffix, columns in [('p', 'p', ('EPEQ',)), ('sx', 'sx', ('SX',))]}
    if max(abs(v) for v in fields['B']['sx'].values()) <= 0:
        raise ValueError('Initial residual stress history absent.')
    zero = dict(axis_max_distance_mm=float(np.linalg.norm(axes['B'] - axes['C0'], axis=1).max()),
                accumulated_plastic_strain_max_difference=r._difference(fields['B']['p'], fields['C0']['p']),
                residual_axial_stress_max_difference_MPa=r._difference(fields['B']['sx'], fields['C0']['sx']))
    if any(zero[k] > budgets['zero_history'][k] for k in zero):
        raise ValueError('B to C0 material/geometry history changed.')
    history = r._load(folder / 'history.txt', 8)
    weak_unloaded = float(4 * core['config']['weak_spring_N_per_mm'] * max(abs(history[np.isin(history[:, 1], [5., 6.]), 6])))
    if weak_unloaded > budgets['weak_spring']['maximum_full_model_unloaded_force_N']:
        raise ValueError('Unloaded weak spring reaction exceeds declared screen.')
    return dict(material_domain_passed=True, B_all_tools_open=True, local_contact_screen=loaded, B_C0_preservation=zero,
                unloaded_weak_spring_force_N=weak_unloaded, full_SET_path_verified=True,
                full_SET_path_scope='Actual ETABLE axial extrema every converged SET, key-state raw copied-IP crosscheck; intermediate point-level raw export absent.',
                physical_screen_scope='Existing base A/B/C0 only; no C/D branches, restart equivalence, label or final mesh qualification.')


def _receipt_clone(function, folder, filename, extra_globals=None):
    folder = Path(folder).resolve()
    captured = []
    def capture(path, value):
        if Path(path).resolve() != (folder / filename).resolve() or captured:
            raise ValueError('Unexpected original-parser write; read-only clone captured no base/branch writes.')
        captured.append(copy.deepcopy(value))
    globals_copy = dict(function.__globals__)
    globals_copy.update(_solver_complete=strict_solver_complete, parse_file_summary=strict_parse_file_summary, write_json=capture)
    globals_copy.update(extra_globals or {})
    return types.FunctionType(function.__code__, globals_copy, 'read_only_' + function.__name__), captured


def parse_base_recovered(folder=BASE):
    """Reusable pure read-only base parser; never publishes a canonical file."""
    folder, meta = original._read_preparation(folder)
    strict_solver_complete(folder, meta)
    parser, captured = _receipt_clone(original.parse_base, folder, 'base_restart_receipt.json')
    result = parser(folder)
    if captured and (len(captured) != 1 or captured[0] != result):
        raise ValueError('Original base parser receipt capture differs.')
    if not captured and not (folder / 'base_restart_receipt.json').is_file():
        raise ValueError('Base parser neither captured nor verified an existing receipt.')
    return result


def parse_branch_recovered(folder):
    """Future read-only branch parse; called only on actual saved results."""
    folder, meta = original._read_preparation(folder)
    strict_solver_complete(folder, meta)
    parser, captured = _receipt_clone(original.parse_branch, folder, 'branch_restart_receipt.json')
    result = parser(folder)
    if len(captured) != 1 or captured[0] != result:
        raise ValueError('Original branch parser receipt capture differs.')
    return result


def strict_cold_header(folder):
    """Cold execution/source guard for the future unchanged comparison body."""
    folder = original._folder(folder)
    status = read(folder / 'solver_status.json')
    trial = read(folder / 'trial_result.json')
    meta = read(folder / 'model_metadata.json')
    validate_status(status, {'input_sha256': sha(folder / 'input.inp'), 'solver_cores': 4})
    if trial.get('input_sha256') != status['input_sha256'] or trial.get('accepted_solver') is not True or trial.get('parsed') is not True or trial.get('model_source_sha256') != sha(original.CORE):
        raise ValueError('Cold input/source/actual parsed trial identity differs.')
    command = read(folder / 'command.json')
    if Path(command[0]).resolve() != original.EXE.resolve() or sha(original.EXE) != read(BASE / 'warm_metadata.json')['solver_executable_sha256']:
        raise ValueError('Actual cold executable differs.')
    if command[command.index('-np') + 1] != '4':
        raise ValueError('Actual cold command core count differs.')
    generated, _ = original._core(meta['config'])
    if hashlib.sha256(generated.encode('ascii')).hexdigest() != status['input_sha256']:
        raise ValueError('Actual cold complete input differs from the frozen core generator.')
    if any('*** ERROR ***' in (folder / name).read_text(encoding='ascii', errors='replace') for name in ('solve.out', 'solve.err')):
        raise ValueError('Actual cold solver output has an explicit ERROR.')
    header_evidence((folder / 'solve.out').read_bytes())
    return True


def _comparison_reader(warm_folder):
    import inspect
    tree = ast.parse(inspect.getsource(original.compare_cold_warm))
    changed = 0
    for node in ast.walk(tree):
        if not isinstance(node, ast.If) or not isinstance(node.test, ast.UnaryOp) or not isinstance(node.test.op, ast.Not):
            continue
        call = node.test.operand
        if isinstance(call, ast.Call) and isinstance(call.func, ast.Attribute) and isinstance(call.func.value, ast.Name) and call.func.value.id == 're' and call.func.attr == 'search' and call.args and isinstance(call.args[0], ast.Constant) and call.args[0].value == r'RELEASE\s+2026\s+R1':
            node.test = ast.UnaryOp(op=ast.Not(), operand=ast.Call(func=ast.Name(id='strict_cold_header', ctx=ast.Load()), args=[ast.Name(id='cold', ctx=ast.Load())], keywords=[]))
            changed += 1
    if changed != 1:
        raise ValueError('Expected exactly one original cold version-header IF; source change requires review.')
    ast.fix_missing_locations(tree)
    folder = Path(warm_folder).resolve()
    captured = []
    def capture(path, value):
        if Path(path).resolve() != (folder / 'cold_warm_comparison.json').resolve() or captured:
            raise ValueError('Unexpected comparison output; no existing result may be changed.')
        captured.append(copy.deepcopy(value))
    globals_copy = dict(original.compare_cold_warm.__globals__)
    globals_copy.update(parse_branch=parse_branch_recovered, parse_base=parse_base_recovered, strict_cold_header=strict_cold_header, write_json=capture)
    exec(compile(tree, str(Path(__file__).resolve()) + ':single_cold_header_AST_adapter', 'exec'), globals_copy)
    return globals_copy['compare_cold_warm'], captured


def compare_cold_warm_recovered(cold_folder, warm_folder, budgets=None):
    """Future read-only comparison; sole AST edit replaces the cold header IF.

    All other original comparison statements and budgets remain unchanged.
    Its two original receipt-producing parse calls are read-only clones.
    """
    comparison, captured = _comparison_reader(warm_folder)
    result = comparison(cold_folder, warm_folder, budgets)
    if len(captured) != 1 or captured[0] != result:
        raise ValueError('Original comparison receipt capture differs.')
    return result


def audit():
    if RECEIPT.exists() or (BASE / 'base_restart_receipt.json').exists():
        raise FileExistsError('Never overwrite recovery/canonical receipts.')
    plan = read(PLAN)
    result = dict(schema_version='WARM_VERSION_FILESUMMARY_REANALYSIS_V001', generated_UTC=datetime.now(timezone.utc).isoformat(),
                  preparation_sha256=sha(PLAN), original_base=str(BASE), accepted_reanalysis=False,
                  new_FE_POST_ML_invocations=0, original_actual_FE_reused=True, branches_prepared=0,
                  formal_restart_enabled=False, formal_generation_unlocked=False, restart_equivalence_passed=False,
                  original_failure_source=str(FAILURE), original_failure_sha256=sha(FAILURE), canonical_created=False)
    try:
        verify_pins(plan)
        original_guards_before = (original._solver_complete, original.parse_file_summary, original.write_json)
        check = read(CHECKS)
        if check.get('passed') is not True or check['adapter_sha256'] != sha(__file__):
            raise ValueError('Current adapter software checks did not pass.')
        folder, meta, status, material = original_sources()
        payload = parse_base_recovered(folder)
        screening = physical_recheck(payload, meta)
        if (original._solver_complete, original.parse_file_summary, original.write_json) != original_guards_before:
            raise ValueError('An original module global was changed; do not publish recovery evidence.')
        verify_pins(plan)
        if original._hashes(BASE) != plan['original_base_files']:
            raise ValueError('An original base file changed during read-only reanalysis.')
        result.update(accepted_reanalysis=True, version_header=header_evidence((BASE / 'solve.out').read_bytes()),
                      actual_input_sha256=meta['input_sha256'], original_solver_seconds=status['seconds'],
                      old_parser_source_sha256=sha(original.__file__), adapter_source_sha256=sha(__file__),
                      original_parse_base_code_sha256=hashlib.sha256(original.parse_base.__code__.co_code).hexdigest(),
                      original_parse_base_code_reused=True, original_module_globals_unchanged=True,
                      recognition_changes_only=plan['adapters'], original_fields_checks=payload['states'],
                      actual_C0_SET=payload['actual_C0_SET'], actual_FILE_SUMMARY_frame=payload['actual_FILE_SUMMARY_frame'],
                      actual_file_summary_records=strict_parse_file_summary(BASE / 'restart_file_summary.txt'),
                      physical_recheck=screening, original_base_files_unchanged=True,
                      original_failure_preserved=True, software_checks_sha256=sha(CHECKS))
        payload['guard_reanalysis'] = dict(adapter_source=str(Path(__file__).resolve()), adapter_sha256=sha(__file__),
                                          reanalysis_receipt=str(RECEIPT), preparation_sha256=sha(PLAN),
                                          original_parser_sha256=sha(original.__file__), original_failure_sha256=sha(FAILURE),
                                          new_FE_POST_invocations=0, actual_FE_refers_to_original_solve=True,
                                          recognition_changes=plan['adapters'], original_fields_reaudited=True,
                                          original_failure_not_modified=True, formal_restart_enabled=False)
        result['canonical_receipt_path_if_later_published'] = str(BASE / 'base_restart_receipt.json')
        result['canonical_candidate_payload'] = payload
        result['canonical_publication_deferred_to_root'] = True
        original._verify_hashes(BASE, plan['original_base_files'])
        verify_pins(plan)
    except Exception as error:
        result.update(accepted_reanalysis=False, error=repr(error), traceback=traceback.format_exc())
        exclusive_json(RECEIPT, result)
        raise
    exclusive_json(RECEIPT, result)
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('prepare', 'check', 'audit'))
    args = parser.parse_args()
    value = {'prepare': prepare, 'check': software_checks, 'audit': audit}[args.action]()
    print(json.dumps(dict(action=args.action, passed=value.get('passed'), accepted_reanalysis=value.get('accepted_reanalysis'),
                          canonical_created=value.get('canonical_created'), new_FE_POST_invocations=0,
                          formal_restart_enabled=False), ensure_ascii=False), flush=True)
