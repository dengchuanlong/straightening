"""Read-only validation of real optimized native trials, not formal qualification.

Cold plans and independent C0 continuations retain their actual identities.
No solver, POST, producer parser, native-file copying or formal writer is called.
Only explicit --output creates a new report; no existing file is overwritten.
Large native RST/RDB files are checked for existence/size, never rehashed here.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
import sys
from datetime import datetime, timezone
from pathlib import Path

sys.dont_write_bytecode = True
import numpy as np
import rect_model as model
import numerical_acceptance as numeric
import optimized_stroke_search_v002 as engine
import restart_boundary_control_v003 as control
import search_cases as rules
import warm_trial_v001 as producer

ROOT = Path(__file__).resolve().parents[1]
VERSION = "OPTIMIZED_QUALIFICATION_READER_V001"
STATES = ("A", "B", "C0", "C", "D")
EXPECTED_NUMERICAL_SHA = "917bcd57c3432d7dadf2727b630066246bbab5369ebe15bb8425f3fb98a41447"
NATIVE_SUFFIXES = {".rst", ".rdb", ".db", ".emat", ".esav", ".full", ".ldhi"}
_SHA_CACHE = {}
LIMITATIONS = [
    "This is an execution/field/search evidence review; it never issues formal qualification.",
    "Native RST/checkpoint payload hashes are preserved from original execution receipts, not recomputed here.",
    "Five-state copied-IP EPEQ/SX/EPTOX plus all-SET axial extrema are the declared scalar/axial scope, not complete tensor/internal-state preservation proof.",
    "Partial available contact points and analytic withdrawn-tool geometry/RF are not complete continuous local contact fields.",
    "Fine comparisons are local challenges, not a complete fine-grid global search or mathematical global optimum proof.",
]


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"),
                      parse_constant=lambda x: (_ for _ in ()).throw(ValueError("Nonfinite JSON: " + x)))


def sha(path):
    p = Path(path).resolve()
    if p.suffix.lower() in NATIVE_SUFFIXES or re.fullmatch(r".+\.r\d+", p.name, re.I):
        raise ValueError("This review never hashes native checkpoint/result payloads: " + str(p))
    before = p.stat()
    key = (str(p), before.st_size, before.st_mtime_ns, before.st_ctime_ns)
    if key in _SHA_CACHE:
        return _SHA_CACHE[key]
    h = hashlib.sha256()
    with p.open("rb") as stream:
        for block in iter(lambda: stream.read(4 * 1024**2), b""):
            h.update(block)
    after = p.stat()
    require((before.st_size, before.st_mtime_ns, before.st_ctime_ns)
            == (after.st_size, after.st_mtime_ns, after.st_ctime_ns), "Source changed during read: " + str(p))
    _SHA_CACHE[key] = h.hexdigest()
    return _SHA_CACHE[key]


def canonical(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                     allow_nan=False).encode("utf-8")).hexdigest()


def require(value, detail):
    if not value:
        raise ValueError(detail)


def local(path):
    p = Path(path)
    return (p if p.is_absolute() else ROOT / p).resolve()


def source(path):
    p = local(path)
    return {"path": str(p), "sha256": sha(p), "size_bytes": p.stat().st_size}


def check(name, value=None, observed=None, detail=None):
    return {"check": name, "status": "pending" if value is None else "pass" if bool(value) else "fail",
            "observed": observed, "detail": detail}


def aggregate(checks):
    statuses = {c["status"] for c in checks}
    return "fail" if "fail" in statuses else "pending" if "pending" in statuses else "pass"


def same(a, b):
    """Exact structures with a strict numeric roundoff tolerance, never truthy booleans."""
    if type(a) is not type(b):
        return False
    if isinstance(a, dict):
        return a.keys() == b.keys() and all(same(a[k], b[k]) for k in a)
    if isinstance(a, list):
        return len(a) == len(b) and all(same(x, y) for x, y in zip(a, b))
    if type(a) is float:
        return math.isfinite(a) and math.isfinite(b) and abs(a-b) <= 1e-10
    return a == b


def pins(mapping):
    require(isinstance(mapping, dict) and bool(mapping), "No actual source pins")
    for name, digest in mapping.items():
        require(sha(local(name)) == digest, "Frozen source differs: " + name)


def raw_field_checks(folder, metadata, budgets):
    """Reuse the frozen numerical helpers, without their cold-only audit_case entry."""
    fields, axes, states = numeric._raw_arrays(folder, metadata, model)
    checks, contact = numeric._contact003_review(folder, metadata, model, budgets)
    diagnostic = [{**c, "status": "pending" if c["status"] == "inconclusive" else c["status"]}
                  for c in checks if c["check"] == "CONT_STAT_MAX_option_semantics_verified"]
    rows = [{**c, "status": "pending" if c["status"] == "inconclusive" else c["status"]}
            for c in checks if c["check"] != "CONT_STAT_MAX_option_semantics_verified"]
    for state, values in states.items():
        for quantity in ("p", "SX", "EX"):
            rows.append(check(f"{state}_{quantity}_identity", values[f"{quantity}_identity_complete"] is True))
            rows.append(check(f"{state}_{quantity}_load_step",
                              values["material_listing_load_steps"][quantity] == [values["expected_load_step"]]))
        rows.append(check(f"{state}_per_element_extrema_crosscheck",
                          values["per_element_extrema_max_difference"] is not None
                          and values["per_element_extrema_max_difference"] <= 1e-10,
                          values["per_element_extrema_max_difference"]))
        rows.append(check(f"{state}_nonnegative_EPEQ", values["raw_min_EPEQ"] >= 0))
    inside = np.asarray(metadata["x_mm"]) <= 130. + 1e-9
    distance = float(np.linalg.norm(axes["B"][inside]-axes["C0"][inside], axis=1).max())
    comparisons = {"axis_mm": distance,
                   "EPEQ": model._difference(fields["B"]["p"], fields["C0"]["p"]),
                   "SX_MPa": model._difference(fields["B"]["sx"], fields["C0"]["sx"])}
    for name, cap in (("axis_mm", budgets["zero_history"]["axis_max_distance_mm"]),
                      ("EPEQ", budgets["zero_history"]["accumulated_plastic_strain_max_difference"]),
                      ("SX_MPa", budgets["zero_history"]["residual_axial_stress_max_difference_MPa"])):
        rows.append(check("B_C0_" + name, comparisons[name] <= cap, comparisons[name]))
    rows.append(check("B_retained_plasticity", states["B"]["raw_max_EPEQ"] > 0))
    rows.append(check("B_retained_residual_SX", states["B"]["raw_max_abs_SX_MPa"] > 0))
    return rows, {"five_state_fields": states, "B_C0_difference": comparisons,
                  "diagnostics_not_method_requirements": diagnostic,
                  "contact": contact}, fields


def initial_history_checks(folder, outer, metadata, fields):
    """Read actual combined SET/history/fields; do not invoke native hashing parsers."""
    base = local(outer["base_folder"])
    base_receipt = load(base / "base_restart_receipt.json")
    require(base_receipt.get("actual_FE") is True, "Initial state lacks actual FE receipt")
    require(sha(base / "input.inp") == outer["base_input_sha256"] == base_receipt["input_sha256"],
            "Actual C0 native input identity differs")
    base_meta = load(base / "warm_metadata.json")
    require({k: v for k, v in base_meta["core_metadata"]["config"].items() if k != "stroke_mm"}
            == {k: v for k, v in metadata["config"].items() if k != "stroke_mm"},
            "Actual C0 physical/numerical settings differ")
    rows = []
    native = []
    for name, saved in outer["source_base_snapshot"].items():
        p = base / name
        require(p.is_file() and p.stat().st_size == saved["size_bytes"], "C0 immutable source size/missing: " + name)
        payload = p.suffix.lower() in NATIVE_SUFFIXES or re.fullmatch(r".+\.r\d+", p.name, re.I)
        if payload:
            native.append({"path": str(p), "size_bytes": p.stat().st_size,
                           "original_execution_sha256": saved["sha256"], "rehash_performed": False})
        else:
            require(sha(p) == saved["sha256"], "C0 original small-source hash differs: " + name)
    table = model._load(folder / "set_identity.txt", 4)
    original_table = model._load(base / "set_identity.txt", 4)
    initial = table[:, 1] <= 6
    rows.append(check("actual_initial_SET_identity", np.array_equal(table[initial], original_table)))
    for name, columns in (("history.txt", 8), ("strain_history.txt", 5)):
        current = model._load(folder / name, columns)
        original = model._load(base / name, columns)
        rows.append(check("actual_initial_" + name,
                          len(current) == len(table) and current[initial].shape == original.shape
                          and np.allclose(current[initial], original, atol=1e-10, rtol=0)))
    rows.append(check("actual_all_stage_SET_coverage",
                      np.array_equal(table[:, 0], np.arange(1, len(table)+1))
                      and set(table[:, 1]) == set(range(1, 12)) and np.all(np.diff(table[:, 3]) > 0)))
    differences = {}
    for state in ("A", "B", "C0"):
        differences[state] = {}
        for suffix, columns, count in (("nodes", 3, metadata["mesh_count"]["work_nodes"]),
                                       ("element_extrema", 4, metadata["mesh_count"]["solid_elements"])):
            a = model._load(folder / f"state_{state}_{suffix}.txt", columns, count)
            b = model._load(base / f"state_{state}_{suffix}.txt", columns, count)
            differences[state][suffix] = float(np.max(abs(a-b)))
        for suffix, columns in (("p", ("EPEQ",)), ("sx", ("SX",)), ("ex", ("EX", "EPTOX"))):
            a = fields[state][suffix]
            b = model._presol_records(base / f"state_{state}_{suffix}.txt", columns)
            require(a.keys() == b.keys() and model._ip_coverage(b, metadata), "C0 copied-IP identity differs")
            differences[state][suffix] = max(abs(a[k]-b[k]) for k in a)
        rows.append(check(state + "_actual_initial_fields", max(differences[state].values()) <= 1e-10,
                          differences[state]))
    return rows, {"base_folder": str(base), "base_receipt_source": source(base / "base_restart_receipt.json"),
                  "initial_field_differences": differences, "native_payloads": native}


def audit_candidate(record, plan, contract):
    """Validate one actual original optimized record, with no scientific-file writes."""
    rows = []
    result = {"stroke_mm": record.get("stroke_mm"), "directory": record.get("directory"),
              "input_sha256": record.get("input_sha256"), "checks": rows,
              "qualified_for_formal_dataset": False, "formal_generation_unlocked": False}
    try:
        folder = local(record["directory"])
        require(folder.is_relative_to(ROOT / "optimized_runs"), "Candidate must retain its actual optimized_runs folder")
        original = load(folder / "optimized_trial_result.json")
        require(original == record, "Saved trial differs from the actual search record")
        status = load(folder / "solver_status.json")
        require(status == record["solver_status"], "Native solver status differs from actual trial")
        require(sha(folder / "input.inp") == plan["executed_input_sha256"] == record["input_sha256"],
                "Actual branch/cold input SHA differs")
        engine.validate_record(record, plan, record["execution_mode"], record["config"], contract)
        rows.append(check("actual_record_plan_native_input_status_identity", True))
        generator = (folder / "generator_plan_input.inp").read_text(encoding="ascii")
        kind = "warm" if record["execution_mode"] == "warm_multiframe_continuation" else "cold"
        actual, lineage = control.derive_input(generator, kind)
        require(actual.encode("ascii") == (folder / "input.inp").read_bytes()
                and lineage == record["native_derivation_lineage"], "Native numerical derivation cannot be reconstructed")
        rows.append(check("actual_numerical_derivation", True))
        result["sources"] = [source(folder / n) for n in ("input.inp", "generator_plan_input.inp",
                              "native_derivation_lineage.json", "solver_status.json", "optimized_trial_result.json")]
        if record.get("accepted_solver") is not True:
            require(record.get("parsed") is False, "Rejected solver has parsed physics")
            result.update(status="excluded_physical_failure", admissible=False,
                          exclusion_reason=record.get("failure_cause") or "Preserved actual solver failure",
                          solver_status=status, failure_not_retried=True)
            return result
        require(record.get("parsed") is True, "Successful physical solve without usable fields is not excludable")
        audit = control.audit_log(folder)
        require(audit.get("passed") is True and same(audit, record["actual_control_audit"]),
                "Effective numerical controls differ or cannot be reread")
        rows.append(check("actual_effective_numerical_controls", True))
        outer = load(folder / ("warm_metadata.json" if kind == "warm" else "model_metadata.json"))
        metadata = outer["core_metadata"] if kind == "warm" else outer
        require(metadata["config"] == record["config"], "Actual metadata physical/numerical configuration differs")
        full, regenerated = model.build(record["config"])
        require(regenerated == {k: v for k, v in metadata.items() if k != "native_solution_control_variant"},
                "Normalized actual metadata cannot be reproduced by the frozen core")
        if kind == "warm":
            base = local(outer["base_folder"])
            base_receipt = load(base / "base_restart_receipt.json")
            require(sha(base / "base_restart_receipt.json") == record["base_receipt_sha256"], "C0 receipt SHA differs")
            expected = producer.expected_branch_input(full, regenerated, base_receipt)
        else:
            expected = full
        require(expected == generator, "Generator plan is not this actual configuration/C0")
        rows.append(check("actual_normalized_configuration_and_C0_plan", True))
        metrics = model.parse(folder, metadata)
        require(same(metrics, record["metrics"]), "Original raw fields and saved metrics differ")
        rows.append(check("actual_five_state_all_SET_metrics_reparsed", True))
        result["independent_metrics"] = {k: metrics[k] for k in ("initial_error_mm", "final_error_mm",
             "peak_press_force_N", "peak_prebend_force_N", "max_ip_accumulated_plastic_strain",
             "max_abs_ip_axial_total_strain", "initial_all_tools_open", "final_all_tools_open")}
        budgets = load(ROOT / "protocol/pilot_acceptance_budgets_v001.json")
        field_rows, detail, fields = raw_field_checks(folder, metadata, budgets)
        rows.extend(field_rows)
        result["field_review"] = detail
        if kind == "warm":
            history_rows, history_detail = initial_history_checks(folder, outer, metadata, fields)
            rows.extend(history_rows)
            result["actual_initial_history"] = history_detail
        spring = metrics["weak_spring_max_force_over_prebend_force"]
        rows.append(check("weak_spring_peak_force_fraction", spring is not None and spring <= budgets["weak_spring"]["maximum_peak_force_fraction"], spring))
        for state in ("B", "D"):
            m = metrics["states"][state]
            rows.append(check(state + "_weak_spring_force",
                              abs(m["weak_spring_force_N"]) <= budgets["weak_spring"]["maximum_full_model_unloaded_force_N"], m["weak_spring_force_N"]))
        valid, reason = rules.admissibility({**record, "metrics": metrics})
        require(valid is record["admissible"], "Actual admissibility differs from saved record")
        if not valid:
            require(reason.startswith(("local accumulated plastic strain", "local axial total strain",
                                       "available key-state local contact penetration")),
                    "Non-domain exclusion cannot silently count as usable candidate evidence: " + reason)
        result.update(admissible=valid, exclusion_reason=reason, status=aggregate(rows))
        result["sources"] += [source(folder / ("warm_metadata.json" if kind == "warm" else "model_metadata.json"))]
        result["raw_result_preserved"] = (folder / "solve.rst").is_file()
    except Exception as error:
        rows.append(check("actual_evidence_review", False, detail=repr(error)))
        result.update(status="fail", error=repr(error), admissible=False)
    return result


def audit_search(search_path, *, fine_path=None, candidate_scope="all"):
    """Return an independent review; shared production gates remain explicit pending."""
    require(candidate_scope in ("all", "winner"), "Candidate scope must be all or winner")
    path = local(search_path)
    rows = []
    result = {"schema_version": VERSION, "generated_utc": datetime.now(timezone.utc).isoformat(),
              "Ansys_invocations": 0, "POST_invocations": 0, "qualified_for_formal_dataset": False,
              "formal_generation_unlocked": False, "candidate_scope": candidate_scope,
              "checks": rows, "candidate_reviews": [], "limitations": LIMITATIONS,
              "source_receipts_modified": False, "dataset_CSVs_modified": False,
              "native_payload_rehash_performed": False, "backup_archive_cleanup": False}
    try:
        require(path.is_relative_to(ROOT / "optimized_cases"), "Use original optimized search evidence")
        search = load(path)
        require(sha(Path(numeric.__file__)) == EXPECTED_NUMERICAL_SHA, "Frozen numerical helper source differs")
        require(search.get("search_version") == engine.VERSION, "Unsupported optimized search schema")
        require(search.get("software_mock") is not True, "Software fixtures are not actual FE evidence")
        pins(search["implementation_sources"])
        variant = engine.validate_contract(search["backend_contract"], search["execution_mode"])
        require(canonical(search["config"]) == search["case_config_sha256"]
                and canonical(search["search_settings"]) == search["search_settings_sha256"], "Saved config/search SHA differs")
        result.update(case_id=search["case_id"], search_source=source(path),
                      reader_source=source(__file__), numerical_helper_source=source(numeric.__file__),
                      execution_mode=search["execution_mode"], numerical_variant=variant)
        rows.append(check("original_search_schema_sources_configuration", True))
        for ref in search["backend_contract"]["method_evidence"]:
            require(sha(ref["path"]) == ref["sha256"], "Actual fixed-method proof changed")
            method = load(ref["path"])
            require(method.get("finished") is True and method.get("error") is None
                    and all(method.get(k) is True for k in ("audited_U_method_pairs_passed", "actual_zero_pair_passed", "actual_12mm_pair_passed")),
                    "Actual fixed0/12 method proof has not passed")
        rows.append(check("actual_fixed0_12_method_proof", True,
                          detail="Preliminary fixed-point equivalence; complete-search equivalence is a separate shared gate."))
        plans = {p["executed_input_sha256"]: p for p in search["candidate_plans"]}
        proofs = {p["proof"]["actual_receipt_path"]: p["proof"] for p in search["execution_proofs"]}
        cache = {}
        for item in search["trials"]:
            require(item["stroke_mm"] not in cache, "Duplicate actual candidate stroke")
            plan = plans[item["input_sha256"]]
            proof = proofs[item["actual_receipt_path"]]
            pins(proof["sources"])
            require(sha(proof["actual_receipt_path"]) == proof["actual_receipt_sha256"], "Actual proof receipt hash differs")
            if item.get("accepted_solver") is True and item.get("parsed") is True:
                require(all(proof.get(k) is True for k in ("execution_evidence_verified", "independent_initial_history_verified", "numerical_variant_verified")),
                        "Original actual proof lacks owned execution/history/control verification")
            else:
                require(proof.get("candidate_failure_recorded") is True, "Rejected candidate lacks preserved failure evidence")
            engine.validate_record(item, plan, search["execution_mode"], search["config"], search["backend_contract"])
            cache[item["stroke_mm"]] = item
        rows.append(check("all_actual_candidate_input_status_and_proof_identities", True, len(cache)))
        label = search.get("label")
        require(isinstance(label, dict) and bool(label), "Search has no actual interior label")
        for item in search["trials"]:
            if candidate_scope == "winner" and item["input_sha256"] != label["best_input_sha256"]:
                continue
            result["candidate_reviews"].append(audit_candidate(item, plans[item["input_sha256"]], search["backend_contract"]))
        hard = [r for r in result["candidate_reviews"] if r["status"] == "fail"]
        pending = [r for r in result["candidate_reviews"] if r["status"] == "pending"]
        rows.append(check("actual_raw_candidate_reviews", False if hard else None if pending or candidate_scope != "all" else True,
                          {"fail": len(hard), "pending": len(pending), "reviewed": len(result["candidate_reviews"])}))
        usable, raw, selected, raw_near, selected_near = rules._selection(cache, search["search_settings"]["resolution_mm"], 0.)
        require(selected is not None and raw is not None, "No actual admissible candidate")
        raw_near = engine.hole_free_neighborhood(raw_near, cache)
        selected_near = engine.hole_free_neighborhood(selected_near, cache)
        matches = selected["input_sha256"] == label["best_input_sha256"] and selected["stroke_mm"] == label["best_stroke_mm"] and selected["metrics"]["final_error_mm"] == label["final_error_mm"]
        rows.append(check("actual_J_selection_and_label", matches))
        rows.append(check("actual_hole_free_two_sided_brackets", all(n.get("resolved") is True and n.get("boundary") is False for n in (raw_near, selected_near)), {"raw": raw_near, "selected": selected_near}))
        valleys = engine.refinement_statuses(search["observed_valleys"], cache, search["search_settings"]["resolution_mm"])
        rows.append(check("all_observed_valleys_reconstructed", bool(valleys) and all(v["resolved"] for v in valleys), valleys))
        result["actual_label"] = {"stroke_mm": selected["stroke_mm"], "J_mm": selected["metrics"]["final_error_mm"],
                                  "input_sha256": selected["input_sha256"], "best_run": selected["directory"],
                                  "process_meets_0p05mm": selected["metrics"]["final_error_mm"] <= .05}
        if fine_path:
            import fine_local_challenge_v001 as fine
            fp = local(fine_path)
            f = load(fp)
            require(local(f["B_search_path"]) == path, "Fine challenge belongs to another B search")
            pins(f["implementation_sources"])
            fine_record = load(f["local_best"]["actual_receipt"]["actual_receipt_path"])
            comparison = fine.compare_best(selected, fine_record)
            rows.append(check("actual_L4_local_best_budget", comparison["passed"], comparison))
            rows.append(check("L4_local_challenge_complete", f.get("complete_local_challenge") is True and f.get("local_comparison_passed") is True))
            result["fine_source"] = source(fp)
        else:
            rows.append(check("actual_L4_local_best_budget", None, detail="No fine receipt supplied"))
        result["shared_gates"] = [
            check("production_protocol_and_mode_adopted", None, detail="Registered V003 draft is not an adopted production protocol."),
            check("production_mesh_representative_cold_warm_search_equivalence", None, detail="Fixed0/12 proof does not establish complete-search label equivalence."),
            check("optimal_label_time_contact_sensitivity", None, detail="Existing fixed12 comparisons pass J/force screens but have no actual resolved labels; bounded local challenges are the next step."),
            check("formal_unique_design_registry_and_qualification_writer", None, detail="No formal source-matched registry/global gate has issued these pilot rows."),
            check("retained_volume_and_execution_lifecycle_for_1000", None, detail="Existing raw-size projection does not fit current local storage; new output policy needs explicit future execution version."),
        ]
        result["evidence_status"] = aggregate(rows)
        result["status"] = "fail" if result["evidence_status"] == "fail" else "pending_shared_gates"
    except Exception as error:
        rows.append(check("optimized_search_evidence_review", False, detail=repr(error)))
        result.update(status="fail", evidence_status="fail", error=repr(error))
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--search", required=True, type=Path)
    parser.add_argument("--fine", type=Path)
    parser.add_argument("--candidate-scope", choices=("all", "winner"), default="all")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = audit_search(args.search, fine_path=args.fine, candidate_scope=args.candidate_scope)
    if args.output:
        output = local(args.output)
        require(output.is_relative_to(ROOT / "report"), "New review reports must remain in report")
        output.parent.mkdir(parents=True, exist_ok=True)
        with output.open("x", encoding="utf-8", newline="\n") as stream:
            json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False)
            stream.write("\n")
        print(json.dumps({"output": str(output), "status": result["status"], "evidence_status": result.get("evidence_status"),
                          "candidate_reviews": len(result["candidate_reviews"]), "formal_generation_unlocked": False,
                          "Ansys_invocations": 0, "POST_invocations": 0}, ensure_ascii=False))
    else:
        print(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False))
    return 1 if result["status"] == "fail" else 0


if __name__ == "__main__":
    raise SystemExit(main())
