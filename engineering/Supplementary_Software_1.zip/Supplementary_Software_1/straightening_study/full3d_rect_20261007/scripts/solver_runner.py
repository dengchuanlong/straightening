"""Serial Student MAPDL runs. Inputs, failures and receipts are never archived.

Process-tree identity tracking is reused by import from the previously reviewed
utility. Its solver entry point is deliberately not called: it archives retries
and writes the old project's guards. This module owns all new paths instead.
"""
from pathlib import Path
import hashlib, importlib.util, json, msvcrt, os, shutil, subprocess, time

ROOT = Path(__file__).resolve().parents[1]
OLD = ROOT.parent / 'auto_run_20261001'
EXE = Path(r'G:\Program Files\ANSYS Inc\ANSYS Student\v261\ansys\bin\winx64\ANSYS261.exe')
SPEC = importlib.util.spec_from_file_location('reviewed_tree_utils', OLD/'scripts'/'mapdl_utils.py')
SHARED = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(SHARED)

class DiagnosticStop(Exception): pass

def wait_owned(process,tree,timeout,signature):
    deadline=time.monotonic()+timeout
    while True:
        tree.capture()
        if tree.identity_errors: raise RuntimeError('Owned process identity tracking failed.')
        stop=ROOT/'logs'/'stop_active_solver.json'
        if stop.exists():
            request=json.loads(stop.read_text(encoding='utf-8'))
            if request.get('input_sha256')==signature: raise DiagnosticStop(request.get('reason','Requested diagnostic stop'))
        code=process.poll()
        if code is not None and not tree.live(): return code
        if time.monotonic()>=deadline: raise subprocess.TimeoutExpired(process.args,timeout)
        time.sleep(.2)

def write_json(path, value):
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    temporary=path.with_suffix(path.suffix+'.writing')
    temporary.write_text(json.dumps(value,indent=2,ensure_ascii=False),encoding='utf-8')
    temporary.replace(path)

def run_solver(folder, text, expected, timeout=2400, cores=4):
    folder=Path(folder).resolve()
    if not folder.is_relative_to(ROOT.resolve()):
        raise ValueError('Run folder must be inside the new experiment.')
    if cores not in (1,2,3,4): raise ValueError('Student core setting outside 1..4')
    folder.mkdir(parents=True,exist_ok=True)
    signature=hashlib.sha256(text.encode('ascii')).hexdigest()
    prior_path=folder/'solver_status.json'
    if prior_path.exists():
        prior=json.loads(prior_path.read_text(encoding='utf-8'))
        if prior['input_sha256']==signature and prior.get('accepted_exit') and all((folder/p).exists() for p in expected):
            return prior
        raise RuntimeError('Existing attempt is preserved. Use a new attempt directory; no backup or overwrite.')
    logs=ROOT/'logs'; logs.mkdir(exist_ok=True)
    guard_path=logs/'active_solver.json'
    with (logs/'student_solver.lock').open('a+b') as lock:
        if lock.tell()==0: lock.write(b'0'); lock.flush()
        while True:
            lock.seek(0)
            try: msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1); break
            except OSError: time.sleep(.5)
        try:
            if guard_path.exists(): raise RuntimeError('An unresolved solver guard must be inspected before launching another job.')
            if shutil.disk_usage(ROOT).free < 8*1024**3: raise RuntimeError('Less than 8 GiB free before job launch.')
            (folder/'input.inp').write_bytes(text.encode('ascii'))
            command=[str(EXE),'-b','-smp','-np',str(cores),'-m','2048','-db','256','-p','ansys','-j','solve','-dir',str(folder),'-i',str(folder/'input.inp'),'-o',str(folder/'solve.out')]
            write_json(folder/'command.json',command)
            guard={'phase':'launching','folder':str(folder),'owner_pid':os.getpid(),'input_sha256':signature,'started_epoch':time.time()}
            write_json(guard_path,guard)
            start=time.monotonic(); timed_out=False; error=None; process=None; tree=None
            cleanup={'tree_exit_confirmed':False}
            with (folder/'launcher.log').open('w',encoding='utf-8') as stream:
                try:
                    process=subprocess.Popen(command,cwd=folder,stdout=stream,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
                    tree=SHARED._OwnedProcessTree(process); tree.capture()
                    write_json(guard_path,{**guard,'phase':'running',**tree.evidence()})
                    code=wait_owned(process,tree,timeout,signature)
                    evidence=tree.evidence()
                    cleanup={**evidence,'tree_exit_confirmed':not evidence['live_identities'] and not evidence['identity_errors']}
                except subprocess.TimeoutExpired: timed_out=True; code=-999
                except DiagnosticStop as exc: error=repr(exc);code=-997
                except BaseException as exc: error=repr(exc); code=-998
                finally:
                    if process is None: cleanup={'tree_exit_confirmed':True,'live_identities':[]}
                    elif not cleanup['tree_exit_confirmed']:
                        if tree is None: tree=SHARED._OwnedProcessTree(process)
                        cleanup=SHARED._terminate_owned_tree(process,tree,stream)
                    if cleanup['tree_exit_confirmed']: guard_path.unlink()
                    else: write_json(guard_path,{**guard,'phase':'tree_cleanup_failed','cleanup':cleanup})
            output=(folder/'solve.out').read_text(errors='replace') if (folder/'solve.out').exists() else ''
            error_log=(folder/'solve.err').read_text(errors='replace') if (folder/'solve.err').exists() else ''
            present={p:(folder/p).exists() and (folder/p).stat().st_size>0 for p in expected}
            receipt={'input_sha256':signature,'seconds':time.monotonic()-start,'returncode':code,'cores':cores,'timed_out':timed_out,'exception':error,
                     'main_output_error_count':output.count('*** ERROR ***'),
                     'error_log_error_count':error_log.count('*** ERROR ***'),
                     'error_count':max(output.count('*** ERROR ***'),error_log.count('*** ERROR ***')),
                     'warning_count':max(output.count('*** WARNING ***'),error_log.count('*** WARNING ***')),
                     'expected_files':present,'process_tree':cleanup,'process_utility_source':str(OLD/'scripts'/'mapdl_utils.py'),'process_utility_sha256':hashlib.sha256((OLD/'scripts'/'mapdl_utils.py').read_bytes()).hexdigest()}
            receipt['accepted_exit']=code==0 and not receipt['error_count'] and all(present.values()) and cleanup['tree_exit_confirmed']
            write_json(prior_path,receipt)
            print(json.dumps({'run':str(folder.relative_to(ROOT)),**receipt},ensure_ascii=False),flush=True)
            return receipt
        finally:
            lock.seek(0); msvcrt.locking(lock.fileno(),msvcrt.LK_UNLCK,1)
