"""Future, offline, per-case qualification; default is software validation only.

Never launches FE/POST, imports solver entry points, rewrites original receipts
or refreshes dataset CSVs. Issuance requires --issue plus all protocol-matched
global, source, registry, actual candidate and sampled-search criteria.
"""
from __future__ import annotations

import argparse
import ast
import csv
import hashlib
import importlib.util
import json
import math
import os
import re
import sys
import uuid
from datetime import datetime,timezone
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
PROTOCOL=ROOT/"protocol/protocol_v002.json"
BUDGETS=ROOT/"protocol/pilot_acceptance_budgets_v001.json"
OUTPUT=ROOT/"report/case_qualification"
NUMERICAL_SHA="917bcd57c3432d7dadf2727b630066246bbab5369ebe15bb8425f3fb98a41447"
FEATURES=("b_mm","h_mm","support_span_mm","punch_radius_mm","support_radius_mm","prebend_tool_stroke_mm")
FIXED=("length_mm","prebend_outer_span_mm","prebend_inner_span_mm","prebend_radius_mm")
STATES=("A","B","C0","C","D")
TOOLS=("prehead","prebase","support","punch")
SOURCE_FILES=("rect_model.py","search_cases.py","numerical_acceptance.py","trial.py","solver_runner.py","design_cases.py","qualify_case.py")
NUMERICAL_SETTINGS=("ny","nz","dx_mm","FKN_factor","FTOLN_factor","max_tool_increment_mm","unload_increment_mm","weak_spring_N_per_mm","friction","fine_withdrawal_clearance_mm","tool_far_gap_mm","save_full_strain_trajectory")
METHODS={
    "unloaded_contact":"KEYOPT4_2_all_mapped_nodes_analytic_cylinder_gap_plus_quarter_RF_xyz_bound",
    "loaded_contact":"available_key_state_raw_contact_points_plus_actual_contact_sensitivity",
    "material_domain":"all_converged_SET_EPTOX_ETABLE_crosschecked_by_five_state_raw_copied_IP_and_accumulated_p",
    "candidate_history":"all_cold_B_C0_axis_EPEQ_SX_identity_and_common_pre_corrective_input",
    "weak_spring":"unloaded_and_peak_reaction_screens_plus_actual_J_sensitivity_0p001mm",
}
DIAGNOSTIC_NAMES={"CONT_STAT_MAX_option_semantics_verified","complete_local_contact_result_coverage","intermediate_SET_copied_IP_identity_coverage","B_available_contact_penetration_screen","D_available_contact_penetration_screen","actual_weak_spring_influence_comparison","actual_mesh_time_contact_and_label_sensitivity"}


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def canonical_sha(value):return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(",",":"),allow_nan=False).encode("utf-8")).hexdigest()
def load(path):return json.loads(Path(path).read_text(encoding="utf-8-sig"),parse_constant=lambda v: (_ for _ in ()).throw(ValueError("Nonfinite JSON constant: "+v)))
def finite(value):return float(value) if not isinstance(value,bool) and isinstance(value,(int,float)) and math.isfinite(float(value)) else None
def valid_sha(value):return isinstance(value,str) and re.fullmatch(r"[0-9a-fA-F]{64}",value) is not None
def source(path):
    path=Path(path).resolve()
    return {"path":str(path),"exists":path.is_file(),"sha256":sha(path) if path.is_file() else None}
def gate(name,value,category,detail=None):return {"check":name,"category":category,"status":"inconclusive" if value is None else ("pass" if value is True else "fail"),"detail":detail}
def status(checks):return "fail" if any(c["status"]=="fail" for c in checks) else ("inconclusive" if not checks or any(c["status"]!="pass" for c in checks) else "pass")
def inside(path,base):
    path=Path(path).resolve()
    if not path.is_relative_to(Path(base).resolve()):raise ValueError("Path outside declared study directory: "+str(path))
    return path
def local_path(path):
    path=Path(path)
    return path if path.is_absolute() else ROOT/path
def signature(path):return hashlib.sha256(Path(path).read_text(encoding="ascii").replace("\r\n","\n").encode("ascii")).hexdigest()


def numerical():
    path=ROOT/"scripts/numerical_acceptance.py"
    if sha(path)!=NUMERICAL_SHA:raise RuntimeError("Frozen numerical_acceptance source differs; explicit new qualification version required")
    sys.dont_write_bytecode=True
    spec=importlib.util.spec_from_file_location("frozen_case_numerical_acceptance",path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module


def recheck_search(n,search,protocol_path,budgets_path):
    """Keep every original search audit intact; this qualifier owns a new file."""
    destination=n.OUTPUT/"qualification_rechecks"/(canonical_sha(search)[:16]+"_"+uuid.uuid4().hex)/"search_review.json"
    return n.audit_search(search,protocol_path,budgets_path,receipt_path=destination)


def admissibility_function():
    """Call the exact pure frozen function without importing search/solver."""
    path=ROOT/"scripts/search_cases.py"
    tree=ast.parse(path.read_text(encoding="utf-8-sig"),filename=str(path))
    functions=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=="admissibility"]
    if len(functions)!=1:raise ValueError("Expected exactly one saved admissibility function")
    safe={"abs":abs,"float":float,"any":any,"all":all,"bool":bool,"ValueError":ValueError,"TypeError":TypeError}
    namespace={"math":math,"__builtins__":safe}
    exec(compile(ast.Module(body=functions,type_ignores=[]),str(path),"exec"),namespace)
    return namespace["admissibility"],{"source":source(path),"function":"admissibility","first_line":functions[0].lineno,"last_line":functions[0].end_lineno,"module_imported":False,"solver_imported":False}


def required_candidate_checks():
    """Explicit names: missing/duplicate checks cannot pass via all([])."""
    names={"metadata_numeric_input_values_finite","physical_error_log_has_no_explicit_ERROR","solver_accepted_exit","solver_zero_errors_and_returncode","input_signature_matches_status","material_card_bytes_match_saved_metadata","software_checks_match_current_parser","five_state_exports_present","five_stage_mapping_present","saved_substep_history_identity_and_order","postprocessor_unchanged_during_review","B_nonzero_retained_plastic_state","B_nonzero_retained_residual_axial_stress","B_C0_fixed_axis_preservation","B_C0_EPEQ_preservation","B_C0_SX_preservation","complete_contact_mesh_identity","weak_spring_peak_force_fraction_screen","all_converged_SET_strain_ETABLE_extraction_screen","all_converged_SET_axial_EX_ETABLE_domain_screen"}
    for s in STATES:
        for q in ("p","SX","EX"):
            names|={f"{s}_{q}_exact_element_node_identity",f"{s}_{q}_PRESOL_stage_identity"}
        names|={f"{s}_every_element_ETABLE_vs_PRESOL",f"{s}_material_EPEQ_screen",f"{s}_material_axial_EX_screen",f"{s}_nonnegative_EPEQ",f"{s}_contact_result_exact_integer_EID",f"{s}_tool_vector_exact_integer_pilot_identity",f"{s}_available_local_contact_identity"}
        for t in TOOLS:names.add(f"{s}_{t}_analytic_cylinder_axis_extent")
    for s in ("A","C0","C"):names.add(f"{s}_available_contact_penetration_screen")
    for s in ("B","D"):
        names|={f"{s}_complete_four_tool_identity",f"{s}_all_four_tools_open_by_geometry_and_RF",f"{s}_weak_spring_force_screen"}
        for t in TOOLS:names|={f"{s}_{t}_full_tool_RF_vector_bound_N",f"{s}_{t}_all_contact_nodes_radial_gap_mm"}
        for key in ("prebend_head_force_N","prebend_support_force_N","support_force_N","punch_force_N"):names.add(f"{s}_withdrawn_{key}")
    return names


def classify_candidate_review(review):
    required=required_candidate_checks();rows=review.get("checks",[]);out=[];diagnostics=[]
    byname={name:[c for c in rows if c.get("check")==name] for name in required}
    for name,hits in sorted(byname.items()):
        if len(hits)!=1:
            out.append(gate(name,None,"required_case_method",{"occurrences":len(hits),"reason":"Required exact check missing or duplicated"}))
        else:
            row=hits[0]
            out.append({**row,"category":"required_case_method","status":row.get("status") if row.get("status") in ("pass","fail","inconclusive") else "inconclusive"})
    for c in rows:
        if c.get("check") in DIAGNOSTIC_NAMES:
            diagnostics.append({**c,"qualification_use":"not_used_as_complete_field_proof","status_preserved":c.get("status")})
            if c.get("status")=="fail":out.append({**c,"category":"reported_hard_failure_not_ignored"})
        elif c.get("check") not in required and c.get("status")=="fail":
            out.append({**c,"category":"unanticipated_hard_failure_not_ignored"})
    return out,diagnostics


def excludable_budget_failure(name):
    """Only a measured material/loaded-contact domain violation may exclude.

Withdrawn B/D contact contradiction, missing identity/extraction, lost history
or force/geometry failure always blocks qualification rather than hiding it.
"""
    return bool(re.fullmatch(r"(?:A|B|C0|C|D)_material_(?:EPEQ|axial_EX)_screen",name)
                or name=="all_converged_SET_axial_EX_ETABLE_domain_screen"
                or re.fullmatch(r"(?:A|C0|C)_available_contact_penetration_screen",name)
                or re.fullmatch(r"(?:A|C0|C)_(?:prehead|prebase|support|punch)_available_element_mean_PENE_screen",name))


def comparison_evidence(spec,kind,protocol_sha,budget_sha,current_sources,budget_values,accepted_settings,protocol_path=PROTOCOL,budgets_path=BUDGETS):
    checks=[];record={"kind":kind}
    if not isinstance(spec,dict) or not spec.get("path") or not valid_sha(spec.get("sha256")):
        return [gate(kind+"_actual_global_evidence",None,"global_actual_evidence","Missing path/SHA reference")],record
    try:
        path=inside(local_path(spec["path"]),ROOT/"report");record["source"]=source(path)
        checks.append(gate(kind+"_evidence_bytes_match_gate",sha(path)==spec["sha256"],"global_actual_evidence"))
        value=load(path)
        checks.append(gate(kind+"_evidence_kind_and_status",value.get("kind")==kind and value.get("overall_status")=="pass","global_actual_evidence"))
        checks.append(gate(kind+"_evidence_protocol_and_budgets",value.get("protocol",{}).get("sha256_bytes")==protocol_sha and value.get("budgets",{}).get("sha256_bytes")==budget_sha,"global_actual_evidence"))
        names={"same_physical_inputs_except_declared_comparison","actual_comparison_setting_changed","same_material_bytes","record_1_solver_accepted","record_2_solver_accepted","record_1_material_fields_reparsed","record_2_material_fields_reparsed","record_1_no_saved_numerical_failure","record_2_no_saved_numerical_failure","residual_objective_change_mm"}
        if kind!="weak_spring":names|={"peak_corrective_force_relative_change","resolved_actual_label_stroke_change_mm"}
        for name in sorted(names):
            hits=[c for c in value.get("checks",[]) if c.get("check")==name]
            checks.append(gate(kind+"_"+name,len(hits)==1 and hits[0].get("status")=="pass" if hits else None,"global_actual_evidence"))
        dirs=value.get("directories",[]);sigs=value.get("input_signatures",[])
        checks.append(gate(kind+"_two_actual_physical_runs",len(dirs)==len(sigs)==2 and len(set(dirs))==2 and len(set(sigs))==2,"global_actual_evidence"))
        actual_configs=[];actual_J=[];actual_force=[];source_files=[];n=numerical();actual_model=n.model()
        for i,(directory,digest) in enumerate(zip(dirs,sigs)):
            folder=inside(local_path(directory),ROOT/"runs");s=load(folder/"solver_status.json");meta=load(folder/"model_metadata.json")
            trial=load(folder/"trial_result.json");actual_configs.append(meta["config"])
            accepted=s.get("accepted_exit") is True and s.get("returncode")==0 and s.get("error_count")==0 and not meta.get("recovery_mode")
            checks.append(gate(f"{kind}_source_{i}_actual_solver",accepted,"global_actual_evidence"))
            checks.append(gate(f"{kind}_source_{i}_physical_process_complete",s.get("process_tree",{}).get("tree_exit_confirmed") is True and s.get("timed_out") is False and s.get("exception") is None,"global_actual_evidence"))
            checks.append(gate(f"{kind}_source_{i}_actual_input_SHA",valid_sha(digest) and signature(folder/"input.inp")==digest==s.get("input_sha256"),"global_actual_evidence"))
            rebuilt,_=actual_model.build(meta["config"])
            checks.append(gate(f"{kind}_source_{i}_frozen_model_rebuild_matches_input",hashlib.sha256(rebuilt.encode("ascii")).hexdigest()==digest,"global_actual_evidence"))
            checks.append(gate(f"{kind}_source_{i}_current_model_and_parse",trial.get("model_source_sha256")==current_sources["rect_model.py"] and trial.get("parsed") is True and trial.get("accepted_solver") is True and trial.get("input_sha256")==digest,"global_actual_evidence"))
            for name in ("rect_model.py","trial.py","solver_runner.py"):
                checks.append(gate(f"{kind}_source_{i}_implementation_"+name,trial.get("implementation_source_hashes",{}).get(name)==current_sources[name],"global_actual_evidence"))
            review=n.audit_case(folder,protocol_path,budgets_path)
            required,diagnostics=classify_candidate_review(review)
            checks.extend([{**c,"check":f"{kind}_source_{i}_raw_"+c["check"],"category":"global_actual_raw_evidence"} for c in required])
            metric=review.get("independently_parsed_metrics",{})
            actual_J.append(finite(metric.get("final_error_mm")));actual_force.append(finite(metric.get("peak_press_force_N")))
            for key in ("final_error_mm","peak_press_force_N"):
                raw=finite(metric.get(key));saved=finite(trial.get("metrics",{}).get(key))
                checks.append(gate(f"{kind}_source_{i}_saved_{key}_matches_raw",abs(raw-saved)<=1e-10 if raw is not None and saved is not None else None,"global_actual_raw_evidence"))
            record.setdefault("source_raw_reviews",[]).append({"directory":str(folder),"required_method_status":status(required),"independent_J_mm":actual_J[-1],"independent_peak_force_N":actual_force[-1],"original_numeric_status_preserved":review.get("overall_status"),"diagnostic_limits":diagnostics})
            source_files.extend(c for c in [*review.get("raw_file_sources",[]),review.get("physical_error_log_source"),review.get("material_card_source"),review.get("postprocessor_source"),review.get("software_checks_source"),review.get("solver_log_source")] if isinstance(c,dict) and c.get("exists") is True)
            source_files.extend(source(folder/name) for name in ("input.inp","model_metadata.json","solver_status.json","trial_result.json"))
        allowed={"mesh":{"ny","nz","dx_mm"},"time":{"max_tool_increment_mm","unload_increment_mm"},"contact":{"FKN_factor","FTOLN_factor"},"weak_spring":{"weak_spring_N_per_mm"}}[kind]
        if len(actual_configs)==2:
            changed={key for key in set(actual_configs[0])|set(actual_configs[1]) if actual_configs[0].get(key)!=actual_configs[1].get(key)}
            ignored={"case_id","protocol_version","protocol_sha256"}|allowed|({"stroke_mm"} if kind!="weak_spring" else set())
            checks.append(gate(kind+"_actual_numerical_setting_changed",bool(changed&allowed) and not(changed-ignored),"global_actual_evidence",sorted(changed)))
            checks.append(gate(kind+"_reference_uses_accepted_numerical_settings",bool(accepted_settings) and all(actual_configs[0].get(key)==accepted_settings.get(key) for key in NUMERICAL_SETTINGS),"global_actual_evidence"))
        observation=value.get("observed",{});reported_J=observation.get("objective_values_mm")
        checks.append(gate(kind+"_actual_trial_J_matches_comparison",isinstance(reported_J,list) and len(reported_J)==2 and None not in actual_J and all(finite(q) is not None and abs(finite(q)-j)<=1e-10 for q,j in zip(reported_J,actual_J)),"global_actual_evidence"))
        cap=budget_values["weak_spring"]["sensitivity_objective_change_mm"] if kind=="weak_spring" else budget_values["mesh_time_contact_sensitivity"]["objective_change_mm"]
        checks.append(gate(kind+"_actual_objective_budget",abs(actual_J[1]-actual_J[0])<=cap if len(actual_J)==2 and None not in actual_J else None,"global_actual_evidence",{"budget_mm":cap}))
        if kind!="weak_spring":
            relative=abs(actual_force[1]-actual_force[0])/abs(actual_force[0]) if len(actual_force)==2 and None not in actual_force and abs(actual_force[0])>.1 else None
            force_cap=budget_values["mesh_time_contact_sensitivity"]["peak_force_relative_change"]
            checks.append(gate(kind+"_actual_force_budget",relative<=force_cap if relative is not None else None,"global_actual_evidence",{"budget_relative":force_cap}))
            receipts=value.get("independent_search_receipts",[])
            checks.append(gate(kind+"_two_actual_search_reconstruction_receipts",len(receipts)==2,"global_actual_evidence"))
            label_strokes=[]
            for i,reference in enumerate(receipts):
                qpath=inside(local_path(reference["receipt_path"]),ROOT/"report");q=load(qpath);source_files.append(source(qpath))
                selected=q.get("independent_actual_neighborhoods",{}).get("selected",{})
                label_strokes.append(finite(selected.get("stroke_mm")))
                winner=q.get("winner_numerical_review",{})
                checks.append(gate(f"{kind}_search_{i}_actual_winner_source",q.get("search_reconstruction_status")=="pass" and winner.get("input_sha256_text_ascii_lf")==sigs[i] if i<len(sigs) else False,"global_actual_evidence"))
                original_search=q.get("search_source",{}).get("path")
                bound_search=spec.get("search_sources",[])
                if not original_search and i<len(bound_search):
                    binding=bound_search[i]
                    original_search=binding.get("path") if isinstance(binding,dict) else None
                    checks.append(gate(f"{kind}_search_{i}_source_SHA_bound_by_gate",valid_sha(binding.get("sha256")) and original_search is not None and sha(inside(local_path(original_search),ROOT/"cases"))==binding.get("sha256"),"global_actual_evidence"))
                if original_search:
                    original_search=inside(local_path(original_search),ROOT/"cases");search=n.load(original_search);source_files.append(source(original_search))
                    checks.append(gate(f"{kind}_search_{i}_original_canonical_SHA_matches_receipt",canonical_sha(search)==q.get("search_record_sha256_canonical"),"global_actual_evidence"))
                    rebuilt_search=recheck_search(n,search,protocol_path,budgets_path)
                    source_files.append(source(rebuilt_search["receipt_path"]))
                    rebuilt_selected=rebuilt_search.get("independent_actual_neighborhoods",{}).get("selected",{})
                    checks.append(gate(f"{kind}_search_{i}_raw_reconstruction_matches_receipt",rebuilt_search.get("search_reconstruction_status")=="pass" and rebuilt_search.get("candidate_history_status")=="pass" and rebuilt_selected==selected,"global_actual_evidence"))
                    for candidate in rebuilt_search.get("candidates",[]):
                        source_files.extend(c for c in [candidate.get("metadata_source"),candidate.get("solver_status_source"),candidate.get("actual_trial_receipt_source"),*candidate.get("initial_field_sources",[])] if isinstance(c,dict) and c.get("exists") is True)
                else:checks.append(gate(f"{kind}_search_{i}_raw_reconstruction_matches_receipt",None,"global_actual_evidence","Original file source absent; canonical in-memory search receipt alone is insufficient."))
            stroke_cap=budget_values["mesh_time_contact_sensitivity"]["label_stroke_change_mm"]
            checks.append(gate(kind+"_actual_label_stroke_budget",abs(label_strokes[1]-label_strokes[0])<=stroke_cap if len(label_strokes)==2 and None not in label_strokes else None,"global_actual_evidence",{"budget_mm":stroke_cap}))
        record["source_files"]=[{**c,"sha256":c.get("sha256",c.get("sha256_bytes"))} for c in source_files]
        record["status"]=status(checks)
    except Exception as error:
        checks.append(gate(kind+"_actual_global_evidence",None,"global_actual_evidence",repr(error)))
    return checks,record


def global_checks(protocol,gate_record,protocol_sha,budget_sha,current_sources,budget_values,protocol_path=PROTOCOL,budgets_path=BUDGETS):
    checks=[gate("formal_generation_unlocked",gate_record.get("formal_generation_unlocked"),"global_gate"),gate("gate_protocol_SHA_matches",gate_record.get("protocol_sha256")==protocol_sha,"global_gate"),gate("gate_protocol_version_matches",gate_record.get("protocol_version")==protocol.get("protocol_version"),"global_gate")]
    required=list(protocol["gates"]["required_passes"])
    restart=protocol.get("history",{}).get("restart_used")
    if restart is True:required.append("restart_equivalence")
    checks.append(gate("restart_policy_declared",type(restart) is bool,"global_gate"))
    for name in required:checks.append(gate("global_pass_"+name,gate_record.get("passes",{}).get(name),"global_gate"))
    if restart is False:
        checks.append(gate("cold_restart_not_applicable_recorded",gate_record.get("restart_equivalence_status")=="not_applicable_restart","global_gate"))
    for name,value in METHODS.items():
        checks.append(gate("global_method_"+name,gate_record.get("accepted_case_methods",{}).get(name)==value if gate_record.get("accepted_case_methods",{}).get(name) is not None else None,"declared_method_acceptance"))
    checks.append(gate("global_preserves_unverified_field_limits",gate_record.get("unverified_diagnostics_preserved"),"declared_method_acceptance"))
    accepted=gate_record.get("accepted_numerical_config",{})
    checks.append(gate("global_accepted_numerical_settings_explicit",isinstance(accepted,dict) and all(key in accepted for key in NUMERICAL_SETTINGS) and accepted.get("save_full_strain_trajectory") is True and all(finite(accepted.get(key)) is not None and finite(accepted[key])>=0 for key in NUMERICAL_SETTINGS if key!="save_full_strain_trajectory"),"declared_method_acceptance"))
    for name,digest in current_sources.items():
        expected=gate_record.get("source_hashes",{}).get(name)
        checks.append(gate("gate_frozen_source_"+name,valid_sha(expected) and expected==digest if expected is not None else None,"global_source"))
    evidence=[]
    for key,kind in (("mesh_sensitivity","mesh"),("time_sensitivity","time"),("contact_sensitivity","contact"),("weak_spring_influence","weak_spring")):
        rows,ref=comparison_evidence(gate_record.get("evidence",{}).get(key),kind,protocol_sha,budget_sha,current_sources,budget_values,accepted,protocol_path,budgets_path);checks+=rows;evidence.append(ref)
    return checks,evidence


def physical_key(values,protocol):
    features={k:round(float(values[k]),6) for k in FEATURES}
    fixed={k:float(protocol["fixed_geometry"][k]) for k in FIXED}
    body={"physical_inputs":features,"fixed_geometry":fixed,"material_parameter_sha256":protocol["material"]["parameter_source_sha256"],"controlled_history":"public-type four-point prebend, unload, reverse three-point straightening"}
    return canonical_sha(body),body


def registry_checks(path,receipt_path,protocol,protocol_sha,config,design_case_id):
    rows=[];checks=[];info={"registry_source":source(path),"registry_receipt_source":source(receipt_path)}
    try:
        inside(path,ROOT/"protocol");inside(receipt_path,ROOT/"protocol")
        with Path(path).open(encoding="utf-8-sig",newline="") as stream:rows=list(csv.DictReader(stream))
        receipt=load(receipt_path)
        checks.append(gate("formal_design_receipt_protocol",receipt.get("phase")=="formal_candidate_design_only_no_solver" and receipt.get("protocol_sha256")==protocol_sha and receipt.get("protocol_version")==protocol["protocol_version"],"formal_design"))
        checks.append(gate("formal_design_generator_and_seed",receipt.get("generator_sha256")==sha(ROOT/"scripts/design_cases.py") and receipt.get("seed")==protocol["design"]["formal_seed"] and receipt.get("solver_started") is False and receipt.get("target_complete_final_conditions")==protocol["design"]["formal_minimum_complete_distinct_final_cases"],"formal_design"))
        ids=[r.get("case_id") for r in rows]
        checks.append(gate("formal_registry_unique_case_ids",bool(rows) and all(ids) and len(set(ids))==len(ids),"formal_design"))
        key,body=physical_key(config,protocol)
        bounds={r["name"]:(r["minimum"],r["maximum"]) for r in protocol["variable_inputs"]}
        checks.append(gate("case_within_protocol_physical_range",all(finite(config.get(k)) is not None and bounds[k][0]<=finite(config[k])<=bounds[k][1] for k in FEATURES),"formal_design"))
        checks.append(gate("case_fixed_geometry_matches_protocol",all(finite(config.get(k))==finite(protocol["fixed_geometry"].get(k)) and finite(config.get(k)) is not None for k in FIXED),"formal_design"))
        matched=[];keys=[]
        for row in rows:
            rowkey,_=physical_key(row,protocol);keys.append(rowkey)
            rowvalid=all(math.isfinite(float(row[k])) and bounds[k][0]<=float(row[k])<=bounds[k][1] for k in FEATURES) and all(math.isfinite(float(row[k])) and float(row[k])==float(protocol["fixed_geometry"][k]) for k in FIXED) and row.get("phase")=="formal_candidate" and row.get("protocol_version")==protocol["protocol_version"] and row.get("material_version")==protocol["material"]["version"] and row.get("design_parameter_sha256")==rowkey
            if not rowvalid:checks.append(gate("formal_registry_row_valid_"+str(row.get("case_id")),False,"formal_design"))
            if (row.get("case_id")==design_case_id if design_case_id else rowkey==key):matched.append(row)
        checks.append(gate("formal_registry_distinct_physical_conditions",len(set(keys))==len(keys),"formal_design"))
        checks.append(gate("formal_design_case_unique_match",len(matched)==1,"formal_design"))
        if len(matched)==1:
            row=matched[0];rowkey,_=physical_key(row,protocol)
            checks.append(gate("design_registered_phase_protocol_material",row.get("phase")=="formal_candidate" and row.get("protocol_version")==protocol["protocol_version"] and row.get("material_version")==protocol["material"]["version"],"formal_design"))
            checks.append(gate("case_matches_registered_physical_inputs",rowkey==key and all(float(row[k])==float(config[k]) for k in (*FEATURES,*FIXED)),"formal_design"))
            checks.append(gate("design_parameter_SHA_recomputed",valid_sha(row.get("design_parameter_sha256")) and row["design_parameter_sha256"]==rowkey,"formal_design"))
            info.update(design_case_id=row["case_id"],design_row=row,physical_condition_sha256=key,physical_condition_definition=body)
        checks.append(gate("formal_registry_declared_count_matches",receipt.get("distinct_candidate_conditions")==len(rows),"formal_design"))
        checks.append(gate("formal_registry_minimum_planned_count",len(rows)>=protocol["design"]["formal_minimum_complete_distinct_final_cases"],"formal_design"))
    except Exception as error:checks.append(gate("formal_registry_available_and_parseable",None,"formal_design",repr(error)))
    return checks,info


def actual_search_geometry(valid,search,budgets):
    """Rebuild resolution using only independently accepted candidate methods."""
    checks=[];summary={};label=search.get("label") or {}
    ordered=sorted(valid,key=lambda r:r["stroke_mm"])
    hits=[r for r in ordered if r["input_sha256"]==label.get("best_input_sha256")]
    checks.append(gate("selected_actual_candidate_individually_valid",len(hits)==1,"actual_search"))
    if len(hits)!=1:return checks,summary
    selected=hits[0];raw=min(ordered,key=lambda r:(r["metrics"]["final_error_mm"],r["stroke_mm"]))
    settings=search.get("search_settings",{});resolution=finite(settings.get("resolution_mm"));tie=finite(settings.get("tie_error_mm"));noise=finite(settings.get("screening_noise_mm"))
    checks.append(gate("actual_search_numeric_settings",resolution is not None and resolution>0 and resolution<=budgets["mesh_time_contact_sensitivity"]["label_stroke_change_mm"] and tie is not None and tie>=0 and noise is not None and noise>=0,"actual_search"))
    if status(checks)!="pass":return checks,summary
    expected=min((r for r in ordered if r["metrics"]["final_error_mm"]<=raw["metrics"]["final_error_mm"]+tie),key=lambda r:r["stroke_mm"])
    checks.append(gate("actual_tie_representative",selected["input_sha256"]==expected["input_sha256"],"actual_search"))
    for role,item in (("selected",selected),("raw_best",raw)):
        i=ordered.index(item);width=ordered[i+1]["stroke_mm"]-ordered[i-1]["stroke_mm"] if 0<i<len(ordered)-1 else None
        checks.append(gate(role+"_actual_valid_two_sided_bracket",width<=resolution+1e-9 if width is not None else False,"actual_search",{"width_mm":width,"budget_mm":resolution,"float_epsilon_mm":1e-9}))
        summary[role]={"input_sha256":item["input_sha256"],"stroke_mm":item["stroke_mm"],"final_error_mm":item["metrics"]["final_error_mm"],"bracket_width_mm":width}
    expected_stroke=finite(label.get("best_stroke_mm",label.get("best_sampled_stroke_mm")))
    label_J=finite(label.get("final_error_mm",label.get("best_residual_error_mm")))
    checks.append(gate("label_is_actual_selected_stroke_and_J",expected_stroke==selected["stroke_mm"] and label_J is not None and abs(label_J-selected["metrics"]["final_error_mm"])<=1e-10,"actual_search"))
    coarse=[next((r for r in ordered if r["stroke_mm"]==s),None) for s in search.get("coarse_screening_strokes_mm",[])];coarse=[r for r in coarse if r]
    valleys=[]
    for i in range(1,len(coarse)-1):
        a,c,d=coarse[i-1:i+2];ea,ec,ed=[r["metrics"]["final_error_mm"] for r in (a,c,d)]
        if ec<=ea+noise and ec<=ed+noise and ec<max(ea,ed)-noise:valleys.append((a["stroke_mm"],d["stroke_mm"],c["stroke_mm"]))
    declared={(v.get("low_mm"),v.get("high_mm"),v.get("screening_stroke_mm")) for v in search.get("identified_screening_valleys",[])}
    checks.append(gate("all_individually_valid_coarse_valleys_accounted",bool(valleys) and set(valleys)==declared,"actual_search"))
    for lo,hi,screen in valleys:
        local=[r for r in ordered if lo-1e-9<=r["stroke_mm"]<=hi+1e-9];best=min(local,key=lambda r:(r["metrics"]["final_error_mm"],r["stroke_mm"]))
        i=local.index(best);width=local[i+1]["stroke_mm"]-local[i-1]["stroke_mm"] if 0<i<len(local)-1 else None
        checks.append(gate("valid_valley_"+str(screen),width<=resolution+1e-9 if width is not None else False,"actual_search",{"width_mm":width,"budget_mm":resolution}))
    summary["process_tolerance_pass"]=selected["metrics"]["final_error_mm"]<=.05
    summary["process_tolerance_note"]="A process miss remains an accepted numerical condition; it is reported false, not a fictitious straightness success."
    return checks,summary


def candidate_integrity(item,folder,meta,physical_status,search,current_sources,model):
    checks=[];record=load(folder/"trial_result.json");actual_input=signature(folder/"input.inp")
    computed,_=model.build(meta["config"])
    expected=hashlib.sha256(computed.encode("ascii")).hexdigest()
    matches=valid_sha(item.get("input_sha256")) and actual_input==item["input_sha256"]==record.get("input_sha256")==physical_status.get("input_sha256")==expected
    checks.append(gate("exact_actual_and_rebuilt_input_SHA",matches,"candidate_source"))
    _,registered_meta=model.build({**search.get("config",{}),"stroke_mm":finite(item.get("stroke_mm"))})
    checks.append(gate("actual_candidate_config_matches_registered_search",meta.get("config")==registered_meta.get("config"),"candidate_source","A self-consistent run cannot be assigned to a different physical design condition. Both configs use the frozen model's normalization."))
    checks.append(gate("search_trial_actual_source_chain",record.get("model_source_sha256")==item.get("model_source_sha256")==search.get("model_source_sha256")==current_sources["rect_model.py"],"candidate_source"))
    checks.append(gate("actual_trial_success_flags_match_search",record.get("accepted_solver") is True and record.get("parsed") is True and item.get("accepted_solver") is True and item.get("parsed") is True,"candidate_source"))
    for name in ("rect_model.py","trial.py","solver_runner.py"):
        checks.append(gate("trial_source_"+name,record.get("implementation_source_hashes",{}).get(name)==current_sources[name],"candidate_source"))
    checks.append(gate("actual_cold_physical_run_not_POST",not meta.get("recovery_mode") and not record.get("post_only"),"candidate_source"))
    checks.append(gate("actual_solver_process_tree_exited",physical_status.get("process_tree",{}).get("tree_exit_confirmed"),"candidate_source"))
    checks.append(gate("actual_solver_no_timeout_or_exception",physical_status.get("timed_out") is False and physical_status.get("exception") is None,"candidate_source"))
    checks.append(gate("actual_candidate_stroke_matches",finite(item.get("stroke_mm"))==finite(record.get("stroke_mm"))==finite(meta["config"].get("stroke_mm")) and finite(item.get("stroke_mm")) is not None,"candidate_source"))
    return checks,{"input_sha256":actual_input,"rebuilt_input_sha256":expected,"input_source":source(folder/"input.inp"),"trial_receipt_source":source(folder/"trial_result.json"),"metadata_source":source(folder/"model_metadata.json"),"solver_status_source":source(folder/"solver_status.json")}


def preserved_failure(item,search,current_sources,model):
    checks=[gate("excluded_attempt_flags_declared",all(type(item.get(k)) is bool for k in ("accepted_solver","parsed")),"excluded_attempt")];info={};stroke=finite(item.get("stroke_mm"))
    checks.append(gate("successful_solver_missing_extraction_cannot_be_skipped",None if item.get("accepted_solver") is True and item.get("parsed") is not True else item.get("accepted_solver") is False,"excluded_attempt","Unknown domain/field extraction after a successful physical solve blocks case qualification; it is not a certified inadmissible candidate."))
    if stroke is None:return [gate("excluded_attempt_finite_stroke",None,"excluded_attempt")],info
    text,_=model.build({**search["config"],"stroke_mm":stroke});expected=hashlib.sha256(text.encode("ascii")).hexdigest()
    checks.append(gate("excluded_attempt_expected_input_and_source",valid_sha(item.get("input_sha256")) and item["input_sha256"]==expected and item.get("model_source_sha256")==current_sources["rect_model.py"],"excluded_attempt"))
    directory=item.get("directory")
    folder=inside(local_path(directory),ROOT/"runs") if directory else ROOT/"runs"/str(search["case_id"])/f"S{stroke:.6f}_{expected[:12]}"
    trial_path=folder/"trial_result.json"
    if trial_path.is_file():
        actual=load(trial_path);info["actual_trial_receipt_source"]=source(trial_path)
        for name in ("solve.out","solve.err"):
            if (folder/name).is_file():info["preserved_"+name+"_source"]=source(folder/name)
        checks.append(gate("excluded_attempt_receipt_flags_match",actual.get("accepted_solver") is item.get("accepted_solver") and actual.get("parsed") is item.get("parsed") and actual.get("input_sha256")==expected,"excluded_attempt"))
        for name in ("rect_model.py","trial.py","solver_runner.py"):
            checks.append(gate("excluded_attempt_source_"+name,actual.get("implementation_source_hashes",{}).get(name)==current_sources[name],"excluded_attempt"))
        input_path=folder/"input.inp";info["actual_input_source"]=source(input_path)
        checks.append(gate("excluded_attempt_actual_input_SHA",signature(input_path)==expected if input_path.is_file() else None,"excluded_attempt"))
        if (folder/"solver_status.json").is_file():
            s=load(folder/"solver_status.json");info["actual_solver_status_source"]=source(folder/"solver_status.json")
            checks.append(gate("excluded_attempt_actual_solver_flag_matches",s.get("accepted_exit") is actual.get("accepted_solver") and s.get("input_sha256")==expected,"excluded_attempt"))
            checks.append(gate("excluded_attempt_physical_process_complete",s.get("process_tree",{}).get("tree_exit_confirmed"),"excluded_attempt"))
        else:checks.append(gate("excluded_attempt_actual_solver_status_preserved",None,"excluded_attempt"))
    elif directory:
        checks.append(gate("excluded_attempt_actual_receipt_preserved",None,"excluded_attempt","A named actual directory lacks the completed attempt receipt"))
    else:
        checks.append(gate("excluded_pre_trial_exception_recorded",isinstance(item.get("exception"),str) and bool(item["exception"].strip()),"excluded_attempt","No FE success inferred; failed-before-receipt exception retained as unknown mechanism"))
    return checks,info


def qualify_case(search_path,*,protocol_path=PROTOCOL,budgets_path=BUDGETS,gate_path=None,
                 design_registry=None,design_receipt=None,design_case_id=None,issue=False):
    """Future invocation returns (receipt, independent augmented label).

Default review never grants qualification. --issue still requires all gates;
callers must count unique physical_condition_sha256, never receipt/run count.
"""
    checks=[];record={"schema_version":"RECT_CASE_QUALIFICATION_V001","generated_utc":datetime.now(timezone.utc).isoformat(),"mode":"issue_requested" if issue else "review_only","qualified_for_formal_dataset":False,"countable_distinct_condition":False,"Ansys_invocations":0,"POST_invocations":0,"dataset_CSVs_modified":False,"source_receipts_modified":False,"checks":checks,"candidates":[],"excluded_candidates":[],"diagnostic_limits":[],"qualification_source":source(__file__)}
    label=None;snapshot={}
    try:
        protocol_path=inside(local_path(protocol_path),ROOT/"protocol");budgets_path=inside(local_path(budgets_path),ROOT/"protocol")
        protocol=load(protocol_path);budgets=load(budgets_path);protocol_sha=sha(protocol_path);budget_sha=sha(budgets_path)
        search_path=inside(local_path(search_path),ROOT/"cases");search=load(search_path);search_sha=sha(search_path)
        gate_path=inside(local_path(gate_path or protocol["gates"]["gate_receipt"]),ROOT/"protocol")
        gate_record=load(gate_path) if gate_path.is_file() else {}
        current_sources={name:sha(ROOT/"scripts"/name) for name in SOURCE_FILES}
        record.update(case_id=search.get("case_id"),search_source=source(search_path),global_gate_source=source(gate_path),protocol_source=source(protocol_path),budgets_source=source(budgets_path),source_hashes=current_sources)
        snapshot={str(protocol_path):protocol_sha,str(budgets_path):budget_sha,str(search_path):search_sha,**({str(gate_path):sha(gate_path)} if gate_path.is_file() else {}),**{str(ROOT/"scripts"/name):digest for name,digest in current_sources.items()}}
        numerical_module=numerical();_,_,budget_checks=numerical_module.settings(protocol_path,budgets_path)
        checks.extend([{**row,"category":"declared_budget_consistency"} for row in budget_checks])
        material_parameters=local_path(protocol["material"]["parameter_source"])
        checks.append(gate("protocol_material_parameter_bytes",sha(material_parameters)==protocol["material"]["parameter_source_sha256"] if material_parameters.is_file() else None,"material_source"))
        if material_parameters.is_file():snapshot[str(material_parameters)]=sha(material_parameters)
        global_rows,evidence=global_checks(protocol,gate_record,protocol_sha,budget_sha,current_sources,budgets,protocol_path,budgets_path);checks+=global_rows;record["global_actual_evidence"]=evidence
        for ref in evidence:
            for item in [ref.get("source"),*ref.get("source_files",[])]:
                if item and item.get("exists") is True:snapshot[item["path"]]=item["sha256"]
        # No case output is read or approval issued while the global gate is locked.
        if status(checks)!="pass":
            record["blocked_before_case_review"]=True;record["status"]=status(checks)
            return _finish(record,label,issue,snapshot)
        admissibility,admissibility_ref=admissibility_function();record["admissibility_function"]=admissibility_ref
        model=numerical_module.model();label=search.get("label")
        _,normalized_search=model.build({**search.get("config",{}),"stroke_mm":0.})
        checks.append(gate("case_uses_globally_accepted_numerical_settings",all(normalized_search["config"].get(key)==gate_record.get("accepted_numerical_config",{}).get(key) for key in NUMERICAL_SETTINGS),"source_protocol"))
        checks.append(gate("search_protocol_SHA_and_version",search.get("config",{}).get("protocol_sha256")==protocol_sha and search.get("config",{}).get("protocol_version")==protocol["protocol_version"],"source_protocol"))
        checks.append(gate("search_frozen_model_and_algorithm_sources",search.get("model_source_sha256")==current_sources["rect_model.py"] and search.get("search_source_sha256")==current_sources["search_cases.py"],"source_protocol"))
        checks.append(gate("case_config_SHA",search.get("case_config_sha256")==canonical_sha(search.get("config",{})),"source_protocol"))
        design_registry=inside(local_path(design_registry or (ROOT/protocol["design"]["formal_output_directory"] /"formal_candidate_cases.csv")),ROOT/"protocol")
        design_receipt=inside(local_path(design_receipt or design_registry.with_name("formal_design_receipt.json")),ROOT/"protocol")
        registry_rows,registry=registry_checks(design_registry,design_receipt,protocol,protocol_sha,search.get("config",{}),design_case_id);checks+=registry_rows;record["formal_design_link"]=registry
        for path in (design_registry,design_receipt):
            if path.is_file():snapshot[str(path)]=sha(path)
        if status(checks)!="pass":record["status"]=status(checks);return _finish(record,label,issue,snapshot)
        search_audit=recheck_search(numerical_module,search,protocol_path,budgets_path)
        record["independent_search_audit"]={"receipt_path":search_audit["receipt_path"],"sha256":sha(search_audit["receipt_path"]),"search_reconstruction_status":search_audit.get("search_reconstruction_status"),"candidate_history_status":search_audit.get("candidate_history_status"),"overall_status_preserved":search_audit.get("overall_status")}
        snapshot[search_audit["receipt_path"]]=sha(search_audit["receipt_path"])
        checks.append(gate("independent_search_reconstruction",search_audit.get("search_reconstruction_status")=="pass","actual_search"))
        checks.append(gate("all_candidate_B_C0_initial_history",search_audit.get("candidate_history_status")=="pass","candidate_history"))
        valid=[]
        for i,item in enumerate(search.get("trials",[])):
            entry={"index":i,"stroke_mm":item.get("stroke_mm"),"directory":item.get("directory"),"input_sha256":item.get("input_sha256")}
            if item.get("accepted_solver") is not True or item.get("parsed") is not True:
                failure_checks,failure_sources=preserved_failure(item,search,current_sources,model)
                checks.extend([{**row,"candidate_index":i} for row in failure_checks])
                for ref in failure_sources.values():
                    if ref.get("exists") is True:snapshot[ref["path"]]=ref["sha256"]
                entry.update(excluded=True,reason=item.get("parse_error") or item.get("exception") or "Preserved solver/parse failure; no retry",qualification_contribution=False,source_checks=failure_checks,source_evidence=failure_sources)
                record["excluded_candidates"].append(entry);continue
            try:
                _,folder,_,_=numerical_module.resolve_record(item);meta=load(folder/"model_metadata.json");physical_status=load(folder/"solver_status.json")
                integrity,provenance=candidate_integrity(item,folder,meta,physical_status,search,current_sources,model)
                review=numerical_module.audit_case(folder,protocol_path,budgets_path)
                for item_source in [*provenance.values(),*review.get("raw_file_sources",[]),review.get("physical_error_log_source"),review.get("material_card_source"),review.get("software_checks_source"),review.get("solver_log_source")]:
                    if isinstance(item_source,dict) and item_source.get("exists") is True:
                        snapshot[item_source["path"]]=item_source.get("sha256",item_source.get("sha256_bytes"))
                method_checks,diagnostics=classify_candidate_review(review)
                metric=review.get("independently_parsed_metrics")
                for row in integrity:checks.append({**row,"candidate_index":i})
                actual={**item,"accepted_solver":physical_status.get("accepted_exit"),"parsed":metric is not None,"metrics":metric or {}}
                admissible,reason=admissibility(actual)
                # Every saved admissibility quantity is checked against actual output.
                metric_match=[]
                for key in ("initial_error_mm","final_error_mm","max_ip_accumulated_plastic_strain","max_abs_ip_axial_total_strain","final_press_force_N"):
                    a=finite((metric or {}).get(key));old=finite(item.get("metrics",{}).get(key))
                    metric_match.append(gate("saved_metric_matches_actual_"+key,abs(a-old)<=1e-10 if a is not None and old is not None else None,"candidate_source"))
                for row in metric_match:checks.append({**row,"candidate_index":i})
                entry.update(provenance=provenance,method_checks=method_checks,diagnostics=diagnostics,admissibility=bool(admissible),admissibility_reason=reason,independent_metrics=metric,source_status=status(integrity+metric_match),method_status=status(method_checks),numeric_overall_preserved=review.get("overall_status"))
                record["diagnostic_limits"].extend([{**d,"candidate_index":i} for d in diagnostics])
                missing_method=any(c["status"]=="inconclusive" for c in method_checks)
                # Only verified physical budget violations can be excluded. Source,
                # extraction, zero-history and other unexplained failures block case.
                hard_fail=[c for c in method_checks if c["status"]=="fail" and not excludable_budget_failure(c["check"])]
                if entry["source_status"]!="pass" or missing_method or hard_fail:
                    checks.append(gate(f"candidate_{i}_independent_evidence_complete",False if hard_fail else None,"candidate_method",{"hard_failures":[c["check"] for c in hard_fail],"incomplete":missing_method}))
                    entry["qualification_contribution"]=False
                elif any(c["status"]=="fail" for c in method_checks):
                    entry.update(excluded=True,reason=reason or "Verified material/penetration budget violation",qualification_contribution=False)
                    record["excluded_candidates"].append(entry)
                elif not admissible:
                    checks.append(gate(f"candidate_{i}_independent_admissibility_consistent",None,"candidate_method",{"reason":reason,"note":"A derived rejection without a separately measured excludable budget violation is not silently dropped."}))
                    entry["qualification_contribution"]=False
                else:
                    entry["qualification_contribution"]=True;valid.append(actual)
                record["candidates"].append(entry)
            except Exception as error:
                entry.update(error=repr(error),qualification_contribution=False);record["candidates"].append(entry)
                checks.append(gate(f"candidate_{i}_independent_evidence_complete",None,"candidate_method",repr(error)))
        record["independently_valid_candidate_n"]=len(valid)
        curve_checks,curve=actual_search_geometry(valid,search,budgets);checks+=curve_checks;record["actual_valid_search"]=curve
        checks.append(gate("all_global_and_case_sources_unchanged",all(Path(path).is_file() and sha(path)==digest for path,digest in snapshot.items()),"source_stability"))
        record["status"]=status(checks)
        record["limitations_preserved"]=["This is a fixed-pose symmetric node-to-analytic-cylinder simulation domain, not a full public mounting-structure or real-machine validation.","Available raw contact points and element averages do not establish a complete continuous local contact field. CONT STAT MAX is not used as a highest-point-status proof.","All converged SET EPTO-X ETABLE envelope plus five raw copied-IP checkpoints is the explicitly accepted domain method; intermediate raw point identity remains unverified.","Label is an actually sampled, resolved interior stroke with recorded tie rule, not a continuous global optimum.","EPEQ/SX preservation does not directly measure every backstress/internal-variable field."]
    except Exception as error:
        checks.append(gate("qualification_review_available",None,"review_error",repr(error)));record["status"]=status(checks)
    return _finish(record,label,issue,snapshot)


def split_source_snapshots(snapshot):
    derived_root=(ROOT/"report/numerical_acceptance/qualification_rechecks").resolve()
    derived={path:digest for path,digest in snapshot.items() if Path(path).resolve().is_relative_to(derived_root)}
    original={path:digest for path,digest in snapshot.items() if path not in derived}
    return original,derived


def _finish(record,label,issue,snapshot):
    if snapshot:
        record["checks"].append(gate("source_snapshot_still_matches_at_receipt",all(Path(path).is_file() and valid_sha(digest) and sha(path)==digest for path,digest in snapshot.items()),"source_stability"))
        record["status"]=status(record["checks"])
    record.setdefault("status",status(record["checks"]))
    record["ready_for_future_qualification"]=record["status"]=="pass"
    record["qualified_for_formal_dataset"]=bool(issue and record["ready_for_future_qualification"])
    record["countable_distinct_condition"]=False
    record["source_snapshot"]=snapshot
    record["frozen_original_source_snapshot"],record["derived_audit_snapshot"]=split_source_snapshots(snapshot)
    physical=record.get("formal_design_link",{}).get("physical_condition_sha256")
    record["physical_condition_sha256"]=physical
    search_sha=record.get("search_source",{}).get("sha256") or "missing"
    gate_sha=record.get("global_gate_source",{}).get("sha256") or "missing"
    identity=canonical_sha({"search":search_sha,"gate":gate_sha,"qualification_source":record["qualification_source"]["sha256"],"registry":record.get("formal_design_link",{}).get("registry_source",{}).get("sha256")})[:16]
    case=re.sub(r"[^A-Za-z0-9_-]","_",str(record.get("formal_design_link",{}).get("design_case_id") or record.get("case_id") or "missing"))[:70]
    destination=OUTPUT/case/identity/("qualification_receipt.json" if issue else "review_receipt.json")
    record["receipt_path"]=str(destination)
    if issue:
        # Small local issuance lock. It does not claim or touch the FE lock.
        OUTPUT.mkdir(parents=True,exist_ok=True);lock=OUTPUT/"qualification_issue.lock";token=uuid.uuid4().hex
        fd=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY)
        try:
            os.write(fd,token.encode("ascii"));os.close(fd)
            record["checks"].append(gate("source_snapshot_matches_inside_issuance_lock",all(Path(path).is_file() and valid_sha(digest) and sha(path)==digest for path,digest in snapshot.items()),"source_stability"))
            record["status"]=status(record["checks"])
            record["ready_for_future_qualification"]=record["status"]=="pass"
            record["qualified_for_formal_dataset"]=record["ready_for_future_qualification"]
            previous=[]
            for path in OUTPUT.glob("*/*/qualification_receipt.json"):
                receipt=load(path)
                if receipt.get("qualified_for_formal_dataset") is True and receipt.get("physical_condition_sha256")==physical and path!=destination:previous.append(str(path))
            record["duplicate_physical_qualification_receipts"]=sorted(previous)
            record["countable_distinct_condition"]=record["qualified_for_formal_dataset"] and physical is not None and not previous
            if destination.exists():
                saved=load(destination)
                if saved.get("frozen_original_source_snapshot")!=record.get("frozen_original_source_snapshot") or saved.get("physical_condition_sha256")!=physical:
                    raise RuntimeError("Existing independent receipt has different frozen sources; preserve it")
                if saved.get("status")!=record.get("status") or saved.get("qualified_for_formal_dataset") is not record.get("qualified_for_formal_dataset"):
                    raise RuntimeError("Current review contradicts preserved receipt; preserve both evidence and investigate")
                record=saved
            else:save(record,destination,replace=False)
        finally:
            try:os.close(fd)
            except OSError:pass
            if lock.exists() and lock.read_text(encoding="ascii")==token:lock.unlink()
    else:save(record,destination,replace=True)
    augmented={**label,"qualified_for_formal_dataset":record["qualified_for_formal_dataset"],"qualification_receipt":str(destination),"qualification_receipt_sha256":sha(destination),"physical_condition_sha256":physical,"registered_design_case_id":record.get("formal_design_link",{}).get("design_case_id"),"source_search_case_id":record.get("case_id"),"countable_distinct_condition":record["countable_distinct_condition"]} if label else None
    return record,augmented


def save(record,path,replace=False):
    path=inside(path,OUTPUT);path.parent.mkdir(parents=True,exist_ok=True)
    text=json.dumps(record,ensure_ascii=False,indent=2,allow_nan=False)+"\n"
    with path.open("w" if replace else "x",encoding="utf-8") as stream:stream.write(text)


def validate_only(protocol_path=PROTOCOL,budgets_path=BUDGETS):
    n=numerical();p,b,settings=n.settings(protocol_path,budgets_path);admissibility,ref=admissibility_function()
    expected=required_candidate_checks();synthetic={"checks":[{"check":name,"status":"pass"} for name in expected]}
    tests=[gate("frozen_numerical_source",sha(ROOT/"scripts/numerical_acceptance.py")==NUMERICAL_SHA,"software"),gate("required_names_explicit_nonempty",len(expected)>100,"software"),gate("complete_synthetic_whitelist",status(classify_candidate_review(synthetic)[0])=="pass","software"),gate("empty_whitelist_not_pass",status(classify_candidate_review({"checks":[]})[0])=="inconclusive","software"),gate("duplicate_check_not_pass",status(classify_candidate_review({"checks":synthetic["checks"]+[synthetic["checks"][0]]})[0])=="inconclusive","software"),gate("missing_physical_solver_check_not_pass",status(classify_candidate_review({"checks":[c for c in synthetic["checks"] if c["check"]!="solver_accepted_exit"]})[0])=="inconclusive","software"),gate("admissibility_rejects_failed_solver",admissibility({"accepted_solver":False})[0] is False,"software"),gate("NaN_not_finite",finite(float("nan")) is None,"software"),gate("boolean_not_finite_number",finite(True) is None,"software")]
    result={"mode":"software_validation_only_not_actual_case_review","schema_version":"RECT_CASE_QUALIFICATION_V001","status":status(tests+settings),"qualified_for_formal_dataset":False,"Ansys_invocations":0,"POST_invocations":0,"checks":tests+settings,"qualification_source":source(__file__),"admissibility_function":ref,"required_case_method_check_n":len(expected),"global_gate_schema_needed":{"protocol_sha256":"exact current protocol file SHA","protocol_version":p["protocol_version"],"formal_generation_unlocked":False,"passes":{k:False for k in p["gates"]["required_passes"]},"restart_equivalence_status":"not_applicable_restart","accepted_case_methods":METHODS,"accepted_numerical_config":{name:"explicit frozen, sensitivity-checked setting" for name in NUMERICAL_SETTINGS},"unverified_diagnostics_preserved":False,"source_hashes":{name:sha(ROOT/"scripts"/name) for name in SOURCE_FILES},"evidence":{name:{"path":"reviewed actual comparison receipt inside report","sha256":"exact receipt SHA",**({"search_sources":[{"path":"left actual search_result.json inside cases","sha256":"exact original search file SHA"},{"path":"right actual search_result.json inside cases","sha256":"exact original search file SHA"}]} if name!="weak_spring_influence" else {})} for name in ("mesh_sensitivity","time_sensitivity","contact_sensitivity","weak_spring_influence")}},"note":"Method strings describe the proposed qualifier scope. False gate flags must not be promoted by software tests."}
    save(result,OUTPUT/"software_validation.json",replace=True)
    return result


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--validate-only",action="store_true");parser.add_argument("--search",type=Path)
    parser.add_argument("--protocol",type=Path,default=PROTOCOL);parser.add_argument("--budgets",type=Path,default=BUDGETS)
    parser.add_argument("--gate",type=Path);parser.add_argument("--design-registry",type=Path);parser.add_argument("--design-receipt",type=Path);parser.add_argument("--design-case-id");parser.add_argument("--issue",action="store_true",help="Future only: still requires every real gate and individual criterion")
    args=parser.parse_args()
    if args.validate_only or args.search is None:
        result=validate_only(args.protocol,args.budgets);path=OUTPUT/"software_validation.json"
    else:
        result,_=qualify_case(args.search,protocol_path=args.protocol,budgets_path=args.budgets,gate_path=args.gate,design_registry=args.design_registry,design_receipt=args.design_receipt,design_case_id=args.design_case_id,issue=args.issue);path=result["receipt_path"]
    print(json.dumps({"status":result["status"],"receipt":str(path),"qualified_for_formal_dataset":result["qualified_for_formal_dataset"],"Ansys_invocations":0,"POST_invocations":0},ensure_ascii=False),flush=True)
    return 0 if result["status"]=="pass" else (1 if result["status"]=="fail" else 2)


if __name__=="__main__":raise SystemExit(main())
