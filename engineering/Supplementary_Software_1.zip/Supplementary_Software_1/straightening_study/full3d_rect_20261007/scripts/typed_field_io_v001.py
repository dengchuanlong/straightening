"""Uncompressed, identity-preserving scientific field format; no solver/cleanup.

read_text_field -> (structured array, metadata); encode/decode use bytes in RAM.
write_new is an opt-in future writer and refuses every existing destination.
One file stores every value of one named quantity (EPEQ, SX or EPTOX), not
the other components printed beside it. This scope is explicit in metadata.
"""
from __future__ import annotations

from collections import defaultdict
import hashlib
import io
import json
import math
from pathlib import Path
import re
import numpy as np

VERSION = "TYPED_FIELD_IO_V001"
DTYPE = np.dtype([("EID", "<i8"), ("node", "<i8"), ("occurrence", "<i8"),
                  ("value", "<f8"), ("source_line", "<i8")], align=False)
FLOAT = r"[-+]?(?:\d+\.?\d*|\.\d+)(?:[EeDd][-+]?\d+)?"
QUANTITIES = {"p": (("EPEQ",), "dimensionless", "accumulated equivalent plastic strain", "coordinate invariant scalar"),
              "SX": (("SX",), "MPa", "axial Cauchy stress", "initial global Cartesian X (RSYS 0)"),
              "EPTO": (("EPTOX", "EX"), "dimensionless", "axial total mechanical strain", "initial global Cartesian X (RSYS 0)")}


def sha_bytes(blob):return hashlib.sha256(blob).hexdigest()
def canonical_sha(value):return sha_bytes(json.dumps(value,sort_keys=True,separators=(",",":"),allow_nan=False).encode("utf-8"))


def read_text_field(path, quantity, source_context):
    """Keep duplicate (EID,node) rows as distinct occurrence-indexed records."""
    if quantity not in QUANTITIES:raise ValueError("Unsupported named quantity")
    context=dict(source_context)
    if context.get("ERESX") != "NO" or not context.get("source_input_sha256") or not context.get("model_source_sha256"):
        raise ValueError("Explicit source input/model/ERESX evidence is required")
    if quantity != "p" and context.get("RSYS") != 0:
        raise ValueError("This version supports actual RSYS0 axial component exports only")
    path=Path(path).resolve(); before=path.stat(); blob=path.read_bytes(); after=path.stat()
    if (before.st_size,before.st_mtime_ns)!=(after.st_size,after.st_mtime_ns):raise RuntimeError("Original changed during read")
    text=blob.decode("ascii",errors="strict")
    if "*** ERROR ***" in text:raise ValueError("Explicit ERROR in original field listing")
    choices,units,meaning,frame=QUANTITIES[quantity]
    rows=[]; repeats=defaultdict(int); element=None; index=None; column=None; stages=set(); times=set(); coordinates=set(); printed_columns=set()
    for line_number,line in enumerate(text.splitlines(),1):
        stage=re.search(r"LOAD STEP\s*=\s*(\d+)\s+SUBSTEP\s*=\s*(\d+)",line,re.I)
        if stage:stages.add((int(stage[1]),int(stage[2])))
        t=re.search(r"^\s*TIME\s*=\s*("+FLOAT+")",line,re.I)
        if t:times.add(float(t[1].replace("D","E").replace("d","e")))
        if "COORDINATES" in line.upper():coordinates.add(line.strip())
        header=re.search(r"\bELEMENT\s*(?:=|NUMBER\s*=?)\s*(\d+)",line,re.I)
        if header:element=int(header[1]);continue
        labels=re.findall(r"\b[A-Z][A-Z0-9]*\b",line.upper())
        if labels and labels[0]=="NODE":
            candidates=[(i,label) for i,label in enumerate(labels) if label in choices]
            if len(candidates)!=1:raise ValueError("Missing/ambiguous named field column")
            index,column=candidates[0];printed_columns.add(tuple(labels[1:]));continue
        if element is None or index is None or not re.match(r"^\s*\d+\s+[-+\d.]",line):continue
        values=[float(v.replace("D","E").replace("d","e")) for v in re.findall(FLOAT,line)]
        if len(values)<=index:raise ValueError("Truncated actual field row")
        node=int(values[0]); value=values[index]
        if node!=values[0] or node<=0 or element<=0 or not math.isfinite(value):raise ValueError("Invalid actual field identity/value")
        pair=(element,node); occurrence=repeats[pair];repeats[pair]+=1
        rows.append((element,node,occurrence,value,line_number))
    if not rows or len(stages)!=1 or len(times)!=1:raise ValueError("Empty or mixed/unknown stage field")
    if quantity!="p" and not any("GLOBAL" in h.upper() for h in coordinates):
        raise ValueError("Actual component listing does not identify global coordinates")
    stage=next(iter(stages)); declared=context.get("load_step")
    if declared is not None and declared!=stage[0]:raise ValueError("Declared stage differs from original listing")
    substep=context.get("substep")
    if substep is not None and substep!=stage[1]:raise ValueError("Declared substep differs from original listing")
    a=np.asarray(rows,dtype=DTYPE)
    metadata={"schema_version":VERSION,"quantity":quantity,"selected_original_column":column,"units":units,"meaning":meaning,
        "coordinate_system":frame,"actual_coordinate_headers":sorted(coordinates),
        "ERESX":"NO","identity_semantics":"Unaveraged per-element EID/node/occurrence copied integration-point records at corner-node labels; these labels are not actual IP coordinates",
        "source_SET":{"NSET":context.get("NSET"),"load_step":stage[0],"substep":stage[1],
                      "time_printed_in_original_header":next(iter(times)),"precise_time_from_source_context":context.get("time")},
        "source_context":context,"original_text_path":str(path),"original_text_sha256":sha_bytes(blob),
        "original_text_bytes":len(blob),"original_text_mtime_ns":after.st_mtime_ns,
        "original_line_numbers":"Each array row source_line is the 1-based original text line number",
        "original_total_line_n":len(text.splitlines()),"original_printed_columns":sorted(printed_columns),
        "record_n":len(a),"duplicate_pair_occurrence_n":sum(n-1 for n in repeats.values()),
        "transformation_version":VERSION,"value_transformation":"ASCII numeric token -> IEEE754 float64, same parser semantics as current reader; no averaging, tensor rotation, downcast, compression or row removal",
        "stored_scope":"All records/values of this ONE named original quantity only; adjacent printed columns are not in this file",
        "stored_array_fields":list(DTYPE.names),"array_dtype_descr":DTYPE.descr,"array_itemsize":DTYPE.itemsize,
        "storage_format":"standard uncompressed .npy; no npz/ZIP/pickle","formal_generation_unlocked":False}
    validate_array(a,metadata)
    return a,metadata


def validate_array(a,metadata):
    if not isinstance(a,np.ndarray) or a.ndim!=1 or a.dtype!=DTYPE or a.dtype.hasobject:
        raise ValueError("Typed field dtype/dimension mismatch")
    if metadata.get("schema_version")!=VERSION or metadata.get("record_n")!=len(a) or len(a)==0:
        raise ValueError("Typed field schema/row count mismatch")
    if not np.isfinite(a["value"]).all() or np.any(a["EID"]<=0) or np.any(a["node"]<=0) or np.any(a["occurrence"]<0):
        raise ValueError("Invalid typed field values or identity")
    if np.any(a["source_line"]<=0) or np.any(np.diff(a["source_line"])<=0):raise ValueError("Original line ordering lost")
    if a["source_line"][-1]>metadata["original_total_line_n"]:raise ValueError("Line identity outside original text")
    seen=defaultdict(int)
    for row in a:
        pair=(int(row["EID"]),int(row["node"]))
        if int(row["occurrence"])!=seen[pair]:raise ValueError("Duplicate occurrence sequence lost or reordered")
        seen[pair]+=1
    if metadata.get("duplicate_pair_occurrence_n")!=sum(n-1 for n in seen.values()):raise ValueError("Duplicate identity count mismatch")


def encode(a,metadata):
    validate_array(a,metadata)
    buf=io.BytesIO();np.save(buf,a,allow_pickle=False);blob=buf.getvalue()
    if not blob.startswith(b"\x93NUMPY"):raise ValueError("Encoding is not native uncompressed NPY")
    output={**metadata,"array_data_sha256":sha_bytes(a.tobytes(order="C")),"npy_sha256":sha_bytes(blob),
            "npy_bytes":len(blob),"array_numeric_payload_bytes":a.nbytes,
            "npy_magic_hex":blob[:6].hex(),"uncompressed":True,"pickle":False}
    return blob,output


def decode(blob,metadata):
    if not isinstance(blob,bytes) or not blob.startswith(b"\x93NUMPY"):
        raise ValueError("Expected standard NPY magic, not compressed/container bytes")
    if metadata.get("uncompressed") is not True or metadata.get("pickle") is not False:
        raise ValueError("Uncompressed nonpickle declaration missing")
    if sha_bytes(blob)!=metadata.get("npy_sha256") or len(blob)!=metadata.get("npy_bytes"):
        raise ValueError("Frozen NPY bytes/hash mismatch")
    buf=io.BytesIO(blob);a=np.load(buf,allow_pickle=False)
    if buf.tell()!=len(blob):raise ValueError("Unexpected trailing NPY bytes")
    validate_array(a,metadata)
    if a.nbytes!=metadata.get("array_numeric_payload_bytes") or sha_bytes(a.tobytes(order="C"))!=metadata.get("array_data_sha256"):
        raise ValueError("Decoded actual numeric data differ")
    return a


def write_new(directory,a,metadata):
    """Future opt-in writer. New directory only; no overwrite or cleanup calls."""
    blob,metadata=encode(a,metadata);directory=Path(directory).resolve()
    directory.mkdir(parents=True,exist_ok=False)
    with (directory/"field.npy").open("xb") as f:f.write(blob)
    with (directory/"metadata.json").open("x",encoding="utf-8",newline="\n") as f:
        f.write(json.dumps(metadata,ensure_ascii=False,indent=2,allow_nan=False)+"\n")
    return {"array_path":str(directory/"field.npy"),"metadata_path":str(directory/"metadata.json"),
            "npy_sha256":metadata["npy_sha256"],"record_n":len(a),"formal_generation_unlocked":False}


def read_saved(directory):
    directory=Path(directory)
    metadata=json.loads((directory/"metadata.json").read_text(encoding="utf-8"))
    return decode((directory/"field.npy").read_bytes(),metadata),metadata


def compare_original(a,metadata):
    """Full same-point/source check, when original text is still available."""
    actual,m=read_text_field(metadata["original_text_path"],metadata["quantity"],metadata["source_context"])
    if m["original_text_sha256"]!=metadata["original_text_sha256"] or actual.tobytes()!=a.tobytes():
        raise ValueError("Original text or actual identity/line/value differs")
    return True
