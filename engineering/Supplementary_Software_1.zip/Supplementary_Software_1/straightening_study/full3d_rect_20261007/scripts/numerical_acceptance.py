"""Offline pilot numerical review. Never imports a solver entry point.

audit_case(record_or_folder) and compare_records(left,right,kind=...) read
actual saved outputs. A successful parse is not solver acceptance or approval
of formal generation. Missing/inactive contact listings remain inconclusive.
"""
from __future__ import annotations
import argparse
import hashlib
import importlib.util
import json
import math
import re
import sys
from datetime import datetime, timezone
from pathlib import Path
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
PROTOCOL=ROOT/"protocol/protocol_v002.json"
BUDGETS=ROOT/"protocol/pilot_acceptance_budgets_v001.json"
CORE_CHECKS=ROOT/"report/core_software_checks.json"
OUTPUT=ROOT/"report/numerical_acceptance"
STATES=("A","B","C0","C","D")
TOOL_FIELDS=("prebend_head_force_N","prebend_support_force_N","support_force_N","punch_force_N")
OFFICIAL_CONTACT_REFERENCE="https://ansyshelp.ansys.com/public/Views/Secured/corp/v261/en/ans_elem/Hlp_E_CONTA174.html"
OPEN_GAP_EPS_MM=1e-6  # Declared RECT3D003 geometric method epsilon, not a fitted stiffness/budget.
CONTACT_MODEL_VERSIONS=("RECT3D003","RECT3D004")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"),parse_constant=lambda s: (_ for _ in ()).throw(ValueError("Non-finite JSON: "+s)))


def number(value):
    if isinstance(value,bool) or not isinstance(value,(int,float,np.integer,np.floating)):
        return None
    return float(value) if math.isfinite(float(value)) else None


def finite_gate(name,value,limit,detail=None):
    v=number(value); lim=number(limit)
    if v is None or lim is None:
        return {"check":name,"status":"inconclusive","observed":None,"budget":lim,"reason":"Missing, non-numeric, boolean or non-finite quantity/budget","detail":detail}
    return {"check":name,"status":"pass" if v<=lim else "fail","observed":v,"budget":lim,"detail":detail}


def lower_gate(name,value,limit,detail=None):
    v=number(value);lim=number(limit)
    if v is None or lim is None:return finite_gate(name,None,limit,detail)
    return {"check":name,"status":"pass" if v>lim else "fail","observed":v,"minimum_exclusive":lim,"detail":detail}


def truth_gate(name,value,detail=None,missing=False):
    return {"check":name,"status":"inconclusive" if missing or value is None else ("pass" if value is True else "fail"),"observed":value,"detail":detail}


def aggregate(checks):
    status=[c["status"] for c in checks]
    return "fail" if "fail" in status else ("inconclusive" if "inconclusive" in status else "pass")


def source(path):
    path=Path(path)
    return {"path":str(path.resolve()),"exists":path.is_file(),"sha256_bytes":sha(path) if path.is_file() else None}


def canonical_json_sha(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(",",":"),allow_nan=False).encode("utf-8")).hexdigest()


def valid_sha(value):
    return isinstance(value,str) and re.fullmatch(r"[0-9a-fA-F]{64}",value) is not None


def bracket_gate(name,width,resolution):
    gate=finite_gate(name,width,resolution,detail="Actual rounded-stroke neighbors; 1e-9 mm float-comparison epsilon is the search implementation's numeric precision")
    if number(width) is not None and number(resolution) is not None:
        gate["status"]="pass" if width<=resolution+1e-9 else "fail"
        gate["numeric_comparison_epsilon_mm"]=1e-9
    return gate


def model():
    # rect_model only builds text/parses files. It has no solver import or entry.
    sys.dont_write_bytecode=True
    path=ROOT/"scripts/rect_model.py"
    spec=importlib.util.spec_from_file_location("rect_numerical_review_model",path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module


def resolve_record(record):
    """Resolve trials or a search's actual winner; never synthesize a label."""
    label=None; search=None
    if isinstance(record,(str,Path)):
        path=Path(record)
        if not path.is_absolute():path=ROOT/path
        if path.is_dir():
            folder=path
            receipt=next((folder/name for name in ("trial_result.json","recovery_result.json") if (folder/name).is_file()),None)
            record=load(receipt) if receipt else {}
        else:
            record=load(path);folder=None
    else:
        record=dict(record);folder=None
    if "trials" in record:
        search=record; label=search.get("label")
        if not label:
            raise ValueError("Search has no actual selected FE label")
        hits=[r for r in search["trials"] if r.get("input_sha256")==label.get("best_input_sha256")]
        if len(hits)!=1:raise ValueError("Selected label does not map uniquely to an actual trial")
        record=hits[0]
    if folder is None:
        directory=record.get("directory")
        if not directory:raise ValueError("Actual saved run directory is missing")
        folder=Path(directory)
        if not folder.is_absolute():folder=ROOT/folder
    folder=folder.resolve()
    if not folder.is_relative_to(ROOT/"runs"):
        raise ValueError("Numerical review must reference a run in the new study")
    return record,folder,label,search


def settings(protocol,budgets):
    p=load(protocol);b=load(budgets)
    tests=[truth_gate("pilot_budgets_not_formal_approval",b.get("status")=="declared_pilot_checks_not_formal_approval")]
    for key in ("objective_change_mm","label_stroke_change_mm","peak_force_relative_change"):
        tests.append(truth_gate("budget_matches_protocol_"+key,b["mesh_time_contact_sensitivity"][key]==p["gates"]["suggested_pilot_error_budgets"][key]))
    tests.append(truth_gate("material_p_budget_matches_protocol",b["material_domain"]["maximum_accumulated_plastic_strain"]==p["material"]["generation_p_cap"]))
    tests.append(truth_gate("material_EX_budget_matches_protocol",b["material_domain"]["maximum_absolute_axial_total_strain"]==p["material"]["generation_axial_total_strain_abs_cap"]))
    return p,b,tests


def _element_crosscheck(records_p,records_ex,vector,ne):
    """Every element's MAX/MIN is checked, not merely global extrema."""
    groups_p={i:[] for i in range(1,ne+1)};groups_ex={i:[] for i in range(1,ne+1)}
    for (e,n,o),v in records_p.items():
        if e in groups_p:groups_p[e].append(v)
    for (e,n,o),v in records_ex.items():
        if e in groups_ex:groups_ex[e].append(v)
    if any(len(groups_p[i])!=8 or len(groups_ex[i])!=8 for i in groups_p):return None
    return max(max(abs(max(groups_p[i])-vector[i-1,0]),abs(min(groups_p[i])-vector[i-1,1]),abs(max(groups_ex[i])-vector[i-1,2]),abs(min(groups_ex[i])-vector[i-1,3])) for i in groups_p)


def _raw_arrays(folder,meta,r):
    records={};axes={};out={}
    for state in STATES:
        p=r._presol_records(folder/f"state_{state}_p.txt",("EPEQ",))
        sx=r._presol_records(folder/f"state_{state}_sx.txt",("SX",))
        ex=r._presol_records(folder/f"state_{state}_ex.txt",("EX","EPTOX"))
        pen=r._presol_records(folder/f"state_{state}_penetration.txt",("PENE",))
        pressure=r._presol_records(folder/f"state_{state}_pressure.txt",("PRES",))
        load_steps={quantity:sorted(set(int(v) for v in re.findall(r"LOAD\s+STEP\s*=\s*(\d+)",(folder/f"state_{state}_{suffix}.txt").read_text(encoding="ascii",errors="replace"),flags=re.I))) for quantity,suffix in (("p","p"),("SX","sx"),("EX","ex"))}
        u=r._load(folder/f"state_{state}_nodes.txt",3,meta["mesh_count"]["work_nodes"])
        vector=r._load(folder/f"state_{state}_element_extrema.txt",4,meta["mesh_count"]["solid_elements"])
        axis,areas=r._centroid_axis(u,meta);axes[state]=axis
        records[state]={"p":p,"sx":sx,"ex":ex}
        expected=8*meta["mesh_count"]["solid_elements"]
        out[state]={"solid_record_expected_n":expected,"p_record_n":len(p),"SX_record_n":len(sx),"EX_record_n":len(ex),"p_identity_complete":r._ip_coverage(p,meta),"SX_identity_complete":r._ip_coverage(sx,meta),"EX_identity_complete":r._ip_coverage(ex,meta),"material_listing_load_steps":load_steps,"expected_load_step":meta["state_stages"][state],"per_element_extrema_max_difference":_element_crosscheck(p,ex,vector,meta["mesh_count"]["solid_elements"]),"raw_max_EPEQ":max(p.values()) if p else None,"raw_min_EPEQ":min(p.values()) if p else None,"raw_max_abs_SX_MPa":max(abs(v) for v in sx.values()) if sx else None,"raw_max_abs_EX":max(abs(v) for v in ex.values()) if ex else None,"section_area_min_mm2":float(areas.min()),"area_centroid_error_fixed_260_mm":r._chord_error(axis,np.asarray(meta["x_mm"]),130.),"contact_available_PENE_n":len(pen),"contact_available_PRES_n":len(pressure),"contact_total_corner_identity_expected_n":4*meta["mesh_count"]["contact_elements"],"available_contact_keys_agree":bool(pen and pen.keys()==pressure.keys()),"available_contact_max_PENE_mm":max(pen.values()) if pen else None,"available_contact_max_PRES_MPa":max(pressure.values()) if pressure else None,"contact_note":"PRESOL can omit far-field elements. A subset/empty listing is missing full contact evidence, not automatically a physical failure and not zero."}
    return records,axes,out


def _contact003_review(folder,meta,r,b):
    """Exact result IDs plus independent node/cylinder gap and vector screens.

STAT MAX is retained as an unverified element-table diagnostic. It is never
used to override the independently computed geometric/RF opening criterion.
"""
    if any(number(t.get(k)) is None for t in meta["tools"].values() for k in ("initial_x_mm","initial_y_mm","radius_mm","pilot_node")):
        raise ValueError("Contact tool geometry/pilot has missing, boolean or nonfinite metadata")
    identities,bytool=r._contact_identities(folder,meta)
    expected_pilots={t["pilot_node"] for t in meta["tools"].values()}
    x,y,z=map(np.asarray,(meta["x_mm"],meta["y_mm"],meta["z_mm"]))
    xyz0=np.stack(np.meshgrid(x,y,z,indexing="ij"),axis=-1).reshape(-1,3)
    expected_points={(eid,node,0) for eid,(_,nodes) in identities.items() for node in nodes}
    checks=[];states={}
    for state in STATES:
        table=r._load(folder/f"state_{state}_contact_elements.txt",4,len(identities))
        vectors=r._load(folder/f"state_{state}_tool_vectors.txt",8,4)
        eid=table[:,0];pilot=vectors[:,0]
        eid_ok=bool(np.equal(eid,np.round(eid)).all() and len(set(eid))==len(eid) and set(eid)==set(identities))
        pilot_ok=bool(np.equal(pilot,np.round(pilot)).all() and len(set(pilot))==len(pilot) and set(pilot)==expected_pilots)
        checks.extend([truth_gate(f"{state}_contact_result_exact_integer_EID",eid_ok),truth_gate(f"{state}_tool_vector_exact_integer_pilot_identity",pilot_ok)])
        pen=r._presol_records(folder/f"state_{state}_penetration.txt",("PENE",))
        pressure=r._presol_records(folder/f"state_{state}_pressure.txt",("PRES",))
        checks.append(truth_gate(f"{state}_available_local_contact_identity",set(pen).issubset(expected_points) and pen.keys()==pressure.keys(),detail="This verifies reported records only, not the omitted far field"))
        u=r._load(folder/f"state_{state}_nodes.txt",3,len(xyz0));xyz=xyz0+u
        log=folder/f"state_{state}_contact_table_log.txt"
        available=bool(log.read_text(encoding="ascii",errors="replace").strip() and r._listing_available(log))
        state_tools={}
        if not(eid_ok and pilot_ok):
            states[state]={"identity_valid":False,"tools":{},"all_tools_open":None};continue
        for name,t in meta["tools"].items():
            vector=vectors[pilot==t["pilot_node"]][0]
            center_y=t["initial_y_mm"]+vector[1]
            nodes=sorted({n for ce in bytool[name] for n in identities[ce][1]})
            pts=xyz[np.asarray(nodes)-1]
            gaps=np.hypot(pts[:,0]-t["initial_x_mm"],pts[:,1]-center_y)-t["radius_mm"]
            force=4*float(np.linalg.norm(vector[2:5]))
            part=table[np.isin(eid,bytool[name])]
            valid=bool(available and np.all(abs(part[:,1:])<1e20))
            min_gap=float(gaps.min())
            axial_extent_ok=bool(pts[:,2].min()>=-5.-1e-8 and pts[:,2].max()<=meta["config"]["b_mm"]/2+5.+1e-8)
            state_tools[name]={"contact_elements_n":len(part),"unique_contact_nodes_n":len(nodes),"all_nodes_within_cylinder_axis_extent":axial_extent_ok,"min_radial_gap_mm":min_gap,"opening_method_epsilon_mm":OPEN_GAP_EPS_MM,"quarter_RF_xyz_N":vector[2:5].tolist(),"quarter_RF_mxyz_Nmm":vector[5:8].tolist(),"four_times_quarter_RF_norm_bound_N":force,"element_table_available":valid,"reported_element_STAT_quantity":float(part[:,1].max()) if valid else None,"max_element_mean_PENE_mm":float(part[:,2].max()) if valid else None,"max_element_mean_PRES_MPa":float(part[:,3].max()) if valid else None,"independently_open":bool(axial_extent_ok and min_gap>OPEN_GAP_EPS_MM and force<=b["unloaded_tools"]["maximum_full_model_absolute_reaction_N"])}
            checks.append(truth_gate(f"{state}_{name}_analytic_cylinder_axis_extent",axial_extent_ok))
            if valid:
                checks.append(finite_gate(f"{state}_{name}_available_element_mean_PENE_screen",float(part[:,2].max()),b["loaded_contact"]["maximum_penetration_mm"],detail="A mean below the limit is not proof of a local maximum below it"))
            if state in ("B","D"):
                checks.extend([finite_gate(f"{state}_{name}_full_tool_RF_vector_bound_N",force,b["unloaded_tools"]["maximum_full_model_absolute_reaction_N"]),lower_gate(f"{state}_{name}_all_contact_nodes_radial_gap_mm",min_gap,OPEN_GAP_EPS_MM,detail="Declared RECT3D003 method epsilon, separate from the penetration budget; specific to CONTA174 KEYOPT(4)=2 and fixed analytic cylinders")])
        states[state]={"identity_valid":True,"tools":state_tools,"all_tools_open":all(t["independently_open"] for t in state_tools.values())}
        if state in ("B","D"):
            checks.append(truth_gate(f"{state}_all_four_tools_open_by_geometry_and_RF",states[state]["all_tools_open"],detail="No absent PENE/PRES field is filled with zero"))
    checks.append(truth_gate("CONT_STAT_MAX_option_semantics_verified",None,detail="CONT ETABLE MIN/MAX support and pointwise highest-status semantics were not independently established. Reported STAT quantity is diagnostic only."))
    return checks,states


def audit_case(record_or_folder,protocol=PROTOCOL,budgets=BUDGETS):
    p,b,checks=settings(protocol,budgets)
    result={"schema_version":"RECT_NUMERICAL_REVIEW_V001","generated_utc":datetime.now(timezone.utc).isoformat(),"protocol":source(protocol),"budgets":source(budgets),"audit_source":source(__file__),"checks":checks,"formal_generation_unlocked":False,"label_qualification_granted":False,"Ansys_invocations":0,"five_state_material_and_zero_history_field_status":"inconclusive","scope":"Offline pilot screening/diagnostics; complete saved files do not override failed solver status"}
    try:
        record,folder,label,search=resolve_record(record_or_folder)
        result.update(directory=str(folder),case_id=record.get("case_id"),search_label=label)
        meta=load(folder/"model_metadata.json");local_status=load(folder/"solver_status.json") if (folder/"solver_status.json").exists() else None
        numeric_keys=("b_mm","h_mm","length_mm","support_span_mm","punch_radius_mm","support_radius_mm","prebend_tool_stroke_mm","stroke_mm","weak_spring_N_per_mm","FKN_factor","FTOLN_factor","max_tool_increment_mm")
        bad_numeric=[k for k in numeric_keys if number(meta["config"].get(k)) is None]
        checks.append(truth_gate("metadata_numeric_input_values_finite",True if not bad_numeric else None,detail=bad_numeric))
        if bad_numeric:raise ValueError("Missing/boolean/nonfinite config values: "+", ".join(bad_numeric))
        physical_folder=Path(meta["physical_source_folder"]).resolve() if meta.get("recovery_mode") and meta.get("physical_source_folder") else folder
        if not physical_folder.is_relative_to(ROOT/"runs"):raise ValueError("Physical source must remain in this study's preserved runs")
        recovered=physical_folder!=folder
        status=load(physical_folder/"solver_status.json") if (physical_folder/"solver_status.json").is_file() else None
        result["record_type"]="separate_POST_recovered_diagnostic_evidence" if recovered else "physical_full_history_attempt"
        result["physical_source_directory"]=str(physical_folder)
        result["metadata_source"]=source(folder/"model_metadata.json")
        material_path=Path(meta["material_file"])
        result["material_card_source"]=source(material_path)
        checks.append(truth_gate("material_card_bytes_match_saved_metadata",sha(material_path)==meta.get("material_sha256") if material_path.is_file() else None))
        result["solver_status_source"]=source(physical_folder/"solver_status.json")
        result["solver_status"]=status
        if recovered:
            result["POST_recovery_status"]=local_status;result["POST_recovery_status_source"]=source(folder/"solver_status.json")
            recovery_path=folder/"recovery_result.json"
            recovery=load(recovery_path) if recovery_path.is_file() else None
            result["recovery_receipt_source"]=source(recovery_path)
            recovery_gates=[truth_gate("actual_POST_status_accepted",local_status.get("accepted_exit") if local_status else None),truth_gate("actual_POST_zero_returncode_and_errors",local_status.get("returncode")==0 and local_status.get("error_count")==0 if local_status else None),truth_gate("separate_POST_recovery_accepted",recovery.get("accepted_post_recovery") if recovery else None),truth_gate("separate_POST_recovery_parsed",recovery.get("parsed") if recovery else None),truth_gate("separate_POST_no_formal_or_physical_acceptance_claim",recovery.get("accepted_solver") is False and recovery.get("qualified_for_formal_dataset") is False if recovery else None)]
            post_err=folder/"solve.err"
            if post_err.is_file():
                post_errors=len(re.findall(r"^\s*\*\*\* ERROR \*\*\*",post_err.read_text(encoding="ascii",errors="replace"),re.M))
                recovery_gates.append(truth_gate("POST_error_log_has_no_explicit_ERROR",post_errors==0))
                result["POST_error_log_source"]=source(post_err)
            unchanged=recovery.get("original_source_files_unchanged",{}) if recovery else {}
            recovery_gates.append(truth_gate("recovery_original_source_hash_receipt_passed",unchanged.get("passed"),detail="Uses the separately executed recovery's RST/RDB verification receipt; this offline audit does not rehash large RST/RDB"))
            original_text=(physical_folder/"input.inp").read_text(encoding="ascii").replace("\r\n","\n")
            result["physical_input_sha256_text_ascii_lf"]=hashlib.sha256(original_text.encode("ascii")).hexdigest()
            new_text,_=model().build(meta["config"])
            boundary="\nfinish\n/post1\n"
            prefix_same=original_text.count(boundary)==1 and new_text.count(boundary)==1 and original_text.split(boundary)[0]==new_text.split(boundary)[0]
            recovery_gates.append(truth_gate("recovery_physical_prefix_independently_identical",prefix_same))
            result["recovery_provenance_checks"]=recovery_gates;checks.extend(recovery_gates)
            result["recovered_POST_provenance_status"]=aggregate(recovery_gates)
            result["recovered_POST_evidence_status"]="inconclusive"
            result["recovery_interpretation"]="Accepted POST-only evidence may support numerical history diagnostics. Original physical-run rc/error acceptance remains unchanged; an ETABLE extraction failure is not automatically a constitutive-history failure."
        err_path=physical_folder/"solve.err"
        if err_path.is_file():
            err=err_path.read_text(encoding="ascii",errors="replace")
            explicit_errors=len(re.findall(r"^\s*\*\*\* ERROR \*\*\*",err,re.M))
            result["physical_error_log_source"]=source(err_path);result["physical_error_log_explicit_error_markers_n"]=explicit_errors
            checks.append(truth_gate("physical_error_log_has_no_explicit_ERROR",explicit_errors==0))
            result["failure_diagnostic_note"]="Observed POST ETABLE CSTAT unknown-label error; this does not by itself diagnose material-state loss or nonconverged physical loading." if re.search(r"Unknown label[^\n]*CSTAT",err,re.I) else ("Observed SOLID turning-inside-out error; solver receipt remains rejected even if later bisection converged." if "turning inside out" in err.lower() else "No specific failure mechanism inferred from return code alone.")
        checks.append(truth_gate("solver_accepted_exit",status.get("accepted_exit") if status else None,detail="A diagnostic parse cannot promote returncode/error failure to acceptance"))
        if status:
            checks.append(truth_gate("solver_zero_errors_and_returncode",status.get("returncode")==0 and status.get("error_count")==0,{"returncode":status.get("returncode"),"error_count":status.get("error_count"),"warning_count":status.get("warning_count")}))
            normalized=(folder/"input.inp").read_text(encoding="ascii").replace("\r\n","\n")
            signature=hashlib.sha256(normalized.encode("ascii")).hexdigest()
            result["input_sha256_text_ascii_lf"]=signature
            if not recovered:result["physical_input_sha256_text_ascii_lf"]=signature
            checks.append(truth_gate("input_signature_matches_status",signature==(local_status if recovered else status).get("input_sha256") if (local_status if recovered else status) else None))
        r=model(); model_before=sha(r.__file__)
        result["postprocessor_source"]=source(r.__file__)
        software=load(CORE_CHECKS) if CORE_CHECKS.exists() else None
        result["software_checks_source"]=source(CORE_CHECKS)
        checks.append(truth_gate("software_checks_match_current_parser",bool(software and software.get("passed") is True and software.get("model_source_sha256")==model_before),missing=software is None))
        required=[folder/f"state_{s}_{suffix}.txt" for s in STATES for suffix in ("nodes","element_extrema","scalars","p","ex","sx","penetration","pressure")]+[folder/"history.txt",folder/"touch_geometry.txt",folder/"complete.txt"]
        if meta["model_version"] in CONTACT_MODEL_VERSIONS:
            required+=[folder/"contact_identity.txt"]+[folder/f"state_{s}_{suffix}.txt" for s in STATES for suffix in ("contact_elements","contact_table_log","tool_vectors")]
        if meta["config"].get("save_full_strain_trajectory"):
            required+=[folder/"strain_history.txt",folder/"strain_history_log.txt"]
        missing=[str(x) for x in required if not x.is_file() or x.stat().st_size==0]
        result["missing_files"]=missing
        checks.append(truth_gate("five_state_exports_present",True if not missing else None,missing=bool(missing),detail=missing))
        if missing:
            result["overall_status"]=aggregate(checks);return result
        result["raw_file_sources"]=[source(x) for x in required]
        result["solver_log_source"]=source(folder/"solve.out")
        history=r._load(folder/"history.txt",8)
        stages=meta["state_stages"]
        checks.append(truth_gate("five_stage_mapping_present",set(stages)==set(STATES) and list(stages.values())==sorted(stages.values())))
        checks.append(truth_gate("saved_substep_history_identity_and_order",bool(np.array_equal(history[:,0],np.arange(1,len(history)+1)) and np.array_equal(history[:,1],history[:,1].astype(int)) and set(history[:,1])==set(range(1,max(stages.values())+1)) and np.all(np.diff(history[:,2])>0))))
        metrics=r.parse(folder,meta)
        result["independently_parsed_metrics"]=metrics
        fields,axes,state_reviews=_raw_arrays(folder,meta,r)
        result["state_reviews"]=state_reviews
        contact_reviews={}
        if meta["model_version"] in CONTACT_MODEL_VERSIONS:
            contact_checks,contact_reviews=_contact003_review(folder,meta,r,b)
            checks.extend(contact_checks);result["independent_contact_reviews"]=contact_reviews
        for state,v in state_reviews.items():
            for quantity in ("p","SX","EX"):
                checks.append(truth_gate(f"{state}_{quantity}_exact_element_node_identity",v[f"{quantity}_identity_complete"]))
                checks.append(truth_gate(f"{state}_{quantity}_PRESOL_stage_identity",v["material_listing_load_steps"][quantity]==[v["expected_load_step"]]))
            checks.append(finite_gate(f"{state}_every_element_ETABLE_vs_PRESOL",v["per_element_extrema_max_difference"],1e-10,detail="Extraction precision crosscheck already used by rect_model, not a material validity budget"))
            checks.append(finite_gate(f"{state}_material_EPEQ_screen",v["raw_max_EPEQ"],b["material_domain"]["maximum_accumulated_plastic_strain"]))
            checks.append(finite_gate(f"{state}_material_axial_EX_screen",v["raw_max_abs_EX"],b["material_domain"]["maximum_absolute_axial_total_strain"]))
            checks.append(truth_gate(f"{state}_nonnegative_EPEQ",v["raw_min_EPEQ"]>=0 if v["raw_min_EPEQ"] is not None else None))
            if v["contact_available_PENE_n"]:
                checks.append(finite_gate(f"{state}_available_contact_penetration_screen",v["available_contact_max_PENE_mm"],b["loaded_contact"]["maximum_penetration_mm"]))
            else:
                checks.append(truth_gate(f"{state}_available_contact_penetration_screen",None,detail="No raw contact values; do not fill zeros"))
        checks.append(truth_gate("B_nonzero_retained_plastic_state",state_reviews["B"]["raw_max_EPEQ"]>0))
        checks.append(truth_gate("B_nonzero_retained_residual_axial_stress",state_reviews["B"]["raw_max_abs_SX_MPa"]>0))
        refs=np.asarray(meta["x_mm"]);inside=refs<=130.+1e-9
        stroke=number(meta["config"].get("stroke_mm"));pairs=[("B","C0")]+([("B","D"),("C0","D")] if stroke==0 else [])
        zero=[]
        for a,c in pairs:
            key=a+"_"+c
            distance=float(np.linalg.norm(axes[a][inside]-axes[c][inside],axis=1).max())
            dp=r._difference(fields[a]["p"],fields[c]["p"]);ds=r._difference(fields[a]["sx"],fields[c]["sx"])
            zero.append({"pair":key,"axis_max_Euclidean_distance_fixed_260_mm":distance,"EPEQ_max_abs_difference":dp,"SX_max_abs_difference_MPa":ds,"identity_match":fields[a]["p"].keys()==fields[c]["p"].keys() and fields[a]["sx"].keys()==fields[c]["sx"].keys()})
            checks.extend([finite_gate(key+"_fixed_axis_preservation",distance,b["zero_history"]["axis_max_distance_mm"]),finite_gate(key+"_EPEQ_preservation",dp,b["zero_history"]["accumulated_plastic_strain_max_difference"]),finite_gate(key+"_SX_preservation",ds,b["zero_history"]["residual_axial_stress_max_difference_MPa"])])
        result["initial_zero_history_reviews"]=zero
        result["zero_stroke_D_equivalence_applicable"]=stroke==0
        for state in ("B","D"):
            v=metrics["states"][state]
            for key in TOOL_FIELDS:
                checks.append(finite_gate(f"{state}_withdrawn_{key}",abs(v[key]),b["unloaded_tools"]["maximum_full_model_absolute_reaction_N"],detail="Individual tool-pair RFY screen; full-model multiplier four"))
            checks.append(finite_gate(f"{state}_weak_spring_force_screen",abs(v["weak_spring_force_N"]),b["weak_spring"]["maximum_full_model_unloaded_force_N"]))
            result.setdefault("unloaded_contact_diagnostics",{})[state]={"available_PENE_max_mm":state_reviews[state]["available_contact_max_PENE_mm"],"available_PRES_max_MPa":state_reviews[state]["available_contact_max_PRES_MPa"],"PENE_budget_mm":b["unloaded_tools"]["maximum_penetration_mm"],"PRES_budget_MPa":b["unloaded_tools"]["maximum_contact_pressure_MPa"],"four_tool_RFY_N":{key:v[key] for key in TOOL_FIELDS},"weak_spring_force_N":v["weak_spring_force_N"],"weak_spring_energy_Nmm":v["weak_spring_energy_Nmm"],"body_strain_energy_Nmm":v["body_strain_energy_Nmm"]}
            if state_reviews[state]["contact_available_PENE_n"]:
                checks.append(finite_gate(f"{state}_available_withdrawn_PENE",state_reviews[state]["available_contact_max_PENE_mm"],b["unloaded_tools"]["maximum_penetration_mm"]))
            if state_reviews[state]["contact_available_PRES_n"]:
                checks.append(finite_gate(f"{state}_available_withdrawn_PRES",state_reviews[state]["available_contact_max_PRES_MPa"],b["unloaded_tools"]["maximum_contact_pressure_MPa"]))
            tools=v.get("tools")
            if meta["model_version"] in CONTACT_MODEL_VERSIONS and tools:
                checks.append(truth_gate(f"{state}_complete_four_tool_identity",set(tools)=={"prehead","prebase","support","punch"} and v.get("contact_identity_verified") is True))
                result["unloaded_contact_diagnostics"][state]["tools"]=contact_reviews[state]["tools"]
            else:
                checks.append(truth_gate(f"{state}_all_four_tools_open",None,detail="Legacy output has no complete REAL/tool/element/connectivity/STAT identity. Empty active PRESOL cannot prove all tool pairs open."))
        peak=metrics.get("peak_prebend_force_N")
        spring_fraction=metrics.get("weak_spring_max_force_N")/peak if number(peak) and peak>0 else None
        checks.append(finite_gate("weak_spring_peak_force_fraction_screen",spring_fraction,b["weak_spring"]["maximum_peak_force_fraction"],detail="Uses maximum prebend force, not near-zero zero-stroke corrective force"))
        if meta["model_version"] in CONTACT_MODEL_VERSIONS:
            checks.append(truth_gate("complete_contact_mesh_identity",metrics.get("contact_identity_verified")))
            result["contact_element_tables"]={s:metrics["states"][s].get("tools") for s in STATES}
        else:
            checks.append(truth_gate("complete_contact_mesh_identity",None,detail="No complete contact identity exported in legacy model"))
        # Element averages are retained independently from available raw points.
        full_contact=metrics.get("raw_contact_coverage_complete")
        checks.append(truth_gate("complete_local_contact_result_coverage",True if full_contact is True else None,detail="Partial/far-field-omitted PRESOL remains inconclusive. Element mean PENE/PRES cannot replace point maxima."))
        trajectory=metrics.get("strain_trajectory",{})
        result["strain_trajectory_review"]=trajectory
        if trajectory.get("requested") is True:
            trajectory_log=folder/"strain_history_log.txt"
            log_valid=bool(trajectory_log.read_text(encoding="ascii",errors="replace").strip() and r._listing_available(trajectory_log))
            checks.append(truth_gate("all_converged_SET_strain_ETABLE_extraction_screen",log_valid and trajectory.get("field_availability_log_passed") is True and trajectory.get("checkpoint_extrema_verified") is True and trajectory.get("converged_substeps")==len(history),detail="Every saved SET/time and full workel MAX/MIN; five checkpoints independently match copied-IP raw extrema"))
            checks.append(finite_gate("all_converged_SET_axial_EX_ETABLE_domain_screen",trajectory.get("max_abs_axial_total_strain"),b["material_domain"]["maximum_absolute_axial_total_strain"]))
            checks.append(truth_gate("intermediate_SET_copied_IP_identity_coverage",None,detail="Intermediate per-point raw text is not exported. All-SET ETABLE is a conditional path screen; five-state identity proof must not be relabeled full raw path coverage."))
        else:
            checks.append(truth_gate("all_substep_axial_EX_domain",None,detail="Only A/B/C0/C/D full material fields saved. Stage maxima are screens, not path-extrema proof"))
        checks.extend([truth_gate("actual_weak_spring_influence_comparison",None,detail="Requires a second actual FE record; small spring reaction alone is not influence proof"),truth_gate("actual_mesh_time_contact_and_label_sensitivity",None,detail="Use compare_records on distinct actual records and resolved actual labels")])
        checks.append(truth_gate("postprocessor_unchanged_during_review",sha(r.__file__)==model_before))
        result["material_p_path_note"]="Same-identity accumulated EPEQ is monotonic in the constitutive history; a final full-coverage D maximum can bound converged accumulated p under that model assumption. Five saved EX states do not bound intermediate path EX. This run's solver failure remains disqualifying."
        result["internal_state_limit"]="Pointwise EPEQ and residual SX preservation are observed proxies. Complete three-backstress/isotropic-variable fields are not exported, so they alone do not prove all internal variables identical. Continuous cold-history input and source identity are recorded separately."
        field_checks=[c for c in checks if any(term in c["check"] for term in ("exact_element_node_identity","PRESOL_stage_identity","every_element_ETABLE","material_EPEQ_screen","material_axial_EX_screen","nonnegative_EPEQ","retained_plastic","retained_residual","fixed_axis_preservation","EPEQ_preservation","SX_preservation"))]
        result["five_state_material_and_zero_history_field_status"]=aggregate(field_checks)
        if recovered:
            raw_checks=[c for c in checks if c["check"] in ("five_state_exports_present","software_checks_match_current_parser","saved_substep_history_identity_and_order","postprocessor_unchanged_during_review","complete_contact_mesh_identity") or any(term in c["check"] for term in ("contact_result_exact_integer_EID","tool_vector_exact_integer_pilot_identity","available_local_contact_identity","all_converged_SET_"))]
            result["recovered_POST_evidence_status"]=aggregate(recovery_gates+field_checks+raw_checks)
            result["recovered_POST_evidence_scope"]="Accepted separate POST receipt plus independently re-read five-state identities/extrema/zero history and available trajectory screens. Full-local contact and intermediate per-point coverage remain separately pending. Physical solver acceptance stays rejected."
        result["contact_reference"]={"url":OFFICIAL_CONTACT_REFERENCE,"STAT_meaning":{"0":"open far-field","1":"open near-field","2":"closed sliding","3":"closed sticking"},"warning":"ETABLE CONT quantities can be element quantities; do not silently replace point extrema with element averages."}
    except Exception as error:
        checks.append(truth_gate("saved_output_review",None,detail=repr(error)))
        result["inspection_error"]=repr(error)
    result["overall_status"]=aggregate(checks)
    result["pass_n"]=sum(c["status"]=="pass" for c in checks)
    result["fail_n"]=sum(c["status"]=="fail" for c in checks)
    result["inconclusive_n"]=sum(c["status"]=="inconclusive" for c in checks)
    return result


def compare_records(left,right,kind="mesh",protocol=PROTOCOL,budgets=BUDGETS):
    """Compare actual fixed-stroke records or resolved search winners.

Unresolved/missing labels never borrow prescribed trial strokes. Two rejected
solver records may supply diagnostics but cannot pass sensitivity acceptance.
Time sensitivity may jointly refine loading and unloading displacement
increments; this is a numerical increment comparison, not physical time/rate.
"""
    p,b,checks=settings(protocol,budgets)
    result={"schema_version":"RECT_NUMERICAL_COMPARISON_V001","kind":kind,"protocol":source(protocol),"budgets":source(budgets),"formal_generation_unlocked":False,"label_qualification_granted":False,"Ansys_invocations":0,"checks":checks}
    try:
        records=[resolve_record(x) for x in (left,right)]
        reviews=[audit_case(x[1],protocol,budgets) for x in records]
        metrics=[v.get("independently_parsed_metrics",{}) for v in reviews]
        metas=[load(x[1]/"model_metadata.json") for x in records]
        configs=[m["config"] for m in metas]
        allowed={"mesh":{"ny","nz","dx_mm"},"time":{"max_tool_increment_mm","unload_increment_mm"},"contact":{"FKN_factor","FTOLN_factor"},"weak_spring":{"weak_spring_N_per_mm"},"candidate_history":{"stroke_mm"}}
        if kind not in allowed:raise ValueError("Unknown comparison kind")
        have_labels=all(x[2] is not None for x in records)
        ignored={"case_id","protocol_version"}|allowed[kind]|({"stroke_mm"} if have_labels else set())
        changed={k:[configs[0].get(k),configs[1].get(k)] for k in set(configs[0])|set(configs[1]) if configs[0].get(k)!=configs[1].get(k)}
        checks.append(truth_gate("same_physical_inputs_except_declared_comparison",not(set(changed)-ignored),changed))
        checks.append(truth_gate("actual_comparison_setting_changed",bool(set(changed)&allowed[kind]),detail="Same record/settings are not sensitivity evidence"))
        checks.append(truth_gate("same_material_bytes",metas[0]["material_sha256"]==metas[1]["material_sha256"]))
        result["directories"]=[str(x[1]) for x in records]
        result["input_signatures"]=[v.get("input_sha256_text_ascii_lf") for v in reviews]
        for i,v in enumerate(reviews):
            checks.append(truth_gate(f"record_{i+1}_solver_accepted",(v.get("solver_status") or {}).get("accepted_exit")))
            checks.append(truth_gate(f"record_{i+1}_material_fields_reparsed",bool(v.get("state_reviews")),missing=not v.get("state_reviews")))
            checks.append(truth_gate(f"record_{i+1}_no_saved_numerical_failure",not any(c["status"]=="fail" for c in v["checks"])))
        j=[number(m.get("final_error_mm")) for m in metrics]
        force=[number(m.get("peak_press_force_N")) for m in metrics]
        dj=abs(j[1]-j[0]) if None not in j else None
        df=abs(force[1]-force[0])/abs(force[0]) if None not in force and abs(force[0])>b["unloaded_tools"]["maximum_full_model_absolute_reaction_N"] else None
        target=b["weak_spring"]["sensitivity_objective_change_mm"] if kind=="weak_spring" else b["mesh_time_contact_sensitivity"]["objective_change_mm"]
        if kind!="candidate_history":checks.append(finite_gate("residual_objective_change_mm",dj,target))
        if kind not in ("weak_spring","candidate_history"):checks.append(finite_gate("peak_corrective_force_relative_change",df,b["mesh_time_contact_sensitivity"]["peak_force_relative_change"],detail="Reference denominator abs(left F); a reference peak no greater than the declared unloaded reaction screen is not loaded-force sensitivity evidence"))
        strokes=[];search_receipts=[]
        for record,folder,label,search in records:
            value=number(label.get("best_sampled_stroke_mm",label.get("best_stroke_mm"))) if label else None
            receipt=audit_search(search,protocol,budgets) if search else None
            search_receipts.append({"receipt_path":receipt.get("receipt_path"),"search_reconstruction_status":receipt.get("search_reconstruction_status"),"overall_status":receipt.get("overall_status")} if receipt else None)
            resolved=bool(receipt and receipt.get("search_reconstruction_status")=="pass" and label.get("search_boundary") is False and value==number(record.get("stroke_mm")))
            strokes.append(value if resolved else None)
        result["independent_search_receipts"]=search_receipts
        if kind not in ("weak_spring","candidate_history"):
            checks.append(finite_gate("resolved_actual_label_stroke_change_mm",abs(strokes[1]-strokes[0]) if None not in strokes else None,b["mesh_time_contact_sensitivity"]["label_stroke_change_mm"],detail="Requires independent audit_search reconstruction, not saved resolved booleans. This budget result alone does not grant the winner's missing numerical qualification."))
        if kind=="candidate_history":
            r=model(); raw=[_raw_arrays(x[1],m,r) for x,m in zip(records,metas)]
            same_mesh=metas[0]["x_mm"]==metas[1]["x_mm"] and metas[0]["y_mm"]==metas[1]["y_mm"] and metas[0]["z_mm"]==metas[1]["z_mm"]
            checks.append(truth_gate("same_mesh_for_pointwise_history_identity",same_mesh))
            if same_mesh:
                physical_folders=[Path(v.get("physical_source_directory",str(x[1]))) for x,v in zip(records,reviews)]
                texts=[(folder/"input.inp").read_text(encoding="ascii") for folder in physical_folders]
                markers=["time,"+str(meta["state_stages"]["C"]) for meta in metas]
                prefix=[t.split(marker,1)[0] if marker in t else None for t,marker in zip(texts,markers)]
                checks.append(truth_gate("candidate_pre_stage5_input_identity",prefix[0] is not None and prefix[0]==prefix[1]))
                inside=np.asarray(metas[0]["x_mm"])<=130.+1e-9
                for state in ("B","C0"):
                    checks.extend([finite_gate(state+"_between_candidates_axis",float(np.linalg.norm(raw[0][1][state][inside]-raw[1][1][state][inside],axis=1).max()),b["zero_history"]["axis_max_distance_mm"]),finite_gate(state+"_between_candidates_EPEQ",r._difference(raw[0][0][state]["p"],raw[1][0][state]["p"]),b["zero_history"]["accumulated_plastic_strain_max_difference"]),finite_gate(state+"_between_candidates_SX",r._difference(raw[0][0][state]["sx"],raw[1][0][state]["sx"]),b["zero_history"]["residual_axial_stress_max_difference_MPa"])])
        result["observed"]={"objective_values_mm":j,"objective_change_mm":dj,"peak_press_force_values_N":force,"peak_force_relative_change":df,"resolved_actual_label_strokes_mm":strokes,"changed_settings":changed}
        result["scope"]="Comparison budgets only. This does not override individual solver/domain/contact/history failures or unlock formal generation."
    except Exception as error:
        checks.append(truth_gate("actual_record_comparison",None,detail=repr(error)))
    result["overall_status"]=aggregate(checks)
    return result


def _initial_candidate(folder,meta,r):
    raw={};axes={};sources=[];checks=[]
    for state in ("B","C0"):
        raw[state]={}
        for quantity,suffix,column in (("p","p",("EPEQ",)),("sx","sx",("SX",))):
            path=folder/f"state_{state}_{suffix}.txt"
            values=r._presol_records(path,column);raw[state][quantity]=values;sources.append(source(path))
            steps=sorted(set(int(v) for v in re.findall(r"LOAD\s+STEP\s*=\s*(\d+)",path.read_text(encoding="ascii",errors="replace"),re.I)))
            checks.extend([truth_gate(f"{state}_{quantity}_initial_exact_copied_IP_identity",r._ip_coverage(values,meta)),truth_gate(f"{state}_{quantity}_initial_load_step_identity",steps==[meta["state_stages"][state]])])
        path=folder/f"state_{state}_nodes.txt";sources.append(source(path))
        u=r._load(path,3,meta["mesh_count"]["work_nodes"]);axes[state],_=r._centroid_axis(u,meta)
    return raw,axes,sources,checks


def _sample_screen(record,b):
    """Conservative saved-metric screen for reconstructing the search curve.

It does not confer material/contact approval; winner audit remains separate.
"""
    m=record.get("metrics",{})
    stroke=number(record.get("stroke_mm"));error=number(m.get("final_error_mm"))
    initial=number(m.get("initial_error_mm"));p=number(m.get("max_ip_accumulated_plastic_strain"));ex=number(m.get("max_abs_ip_axial_total_strain"))
    values=(stroke,error,initial,p,ex)
    basic=bool(record.get("accepted_solver") is True and record.get("parsed") is True and None not in values and min(values)>=0 and p<=b["material_domain"]["maximum_accumulated_plastic_strain"]+1e-8 and ex<=b["material_domain"]["maximum_absolute_axial_total_strain"]+1e-8 and m.get("raw_IP_coverage_complete") is True and m.get("raw_extrema_crosscheck_passed") is True)
    if not basic:return False
    for state in ("B","D"):
        s=m.get("states",{}).get(state,{})
        for key in TOOL_FIELDS:
            value=number(s.get(key))
            if value is None or abs(value)>b["unloaded_tools"]["maximum_full_model_absolute_reaction_N"]:return False
        weak=number(s.get("weak_spring_force_N"))
        if weak is None or abs(weak)>b["weak_spring"]["maximum_full_model_unloaded_force_N"]:return False
    if m.get("model_version") in CONTACT_MODEL_VERSIONS and (m.get("initial_all_tools_open") is not True or m.get("final_all_tools_open") is not True):return False
    penetration=number(m.get("max_contact_penetration_mm"))
    if penetration is None or penetration>b["loaded_contact"]["maximum_penetration_mm"]:return False
    return True


def audit_search(search_record,protocol=PROTOCOL,budgets=BUDGETS,receipt_path=None):
    """Read all actual candidates and save a separate search/history receipt.

No solver/search module is imported. Failed candidates are retained/excluded;
the winner and neighbors cannot be supplied by interpolated or missing data.
This receipt never writes a formal qualification flag into a case or label.
"""
    p,b,checks=settings(protocol,budgets)
    result={"schema_version":"RECT_SEARCH_NUMERICAL_REVIEW_V001","generated_utc":datetime.now(timezone.utc).isoformat(),"protocol":source(protocol),"budgets":source(budgets),"audit_source":source(__file__),"Ansys_invocations":0,"formal_generation_unlocked":False,"label_qualification_granted":False,"checks":checks,"candidate_history_checks":[],"candidates":[],"preserved_excluded_candidates":[]}
    history_checks=result["candidate_history_checks"]
    search_path=None;search_sha=None;usable=[];reference=None
    try:
        if isinstance(search_record,(str,Path)):
            search_path=Path(search_record)
            if not search_path.is_absolute():search_path=ROOT/search_path
            search=load(search_path);search_sha=sha(search_path);result["search_source"]=source(search_path)
        else:search=dict(search_record)
        result["search_record_sha256_canonical"]=canonical_json_sha(search)
        result["case_id"]=search.get("case_id")
        trials=search.get("trials",[]);label=search.get("label")
        result["actual_trial_n"]=len(trials);result["label"]=label
        for key in ("complete","search_acceptance_passed","bracket_resolution_met","all_identified_valleys_resolved"):
            checks.append(truth_gate("search_declared_"+key,search.get(key)))
        checks.append(truth_gate("search_interior_declared",search.get("search_boundary") is False and bool(label and label.get("search_boundary") is False)))
        checks.append(truth_gate("nonempty_actual_candidate_list",bool(trials)))
        strokes=[number(t.get("stroke_mm")) for t in trials]
        checks.append(truth_gate("unique_finite_candidate_strokes",None not in strokes and len(set(strokes))==len(strokes)))
        settings_s=search.get("search_settings",{})
        settings_digest=search.get("search_settings_sha256")
        checks.append(truth_gate("frozen_search_settings_SHA_matches",canonical_json_sha(settings_s)==settings_digest if settings_digest is not None else None))
        upper=number(settings_s.get("upper_mm"));screen_n=number(settings_s.get("screening_n"));resolution=number(search.get("resolution_mm",settings_s.get("resolution_mm")))
        valid_grid=bool(upper is not None and upper>0 and screen_n is not None and screen_n==int(screen_n) and screen_n>=7)
        coarse=search.get("coarse_screening_strokes_mm")
        expected_coarse=np.round(np.linspace(0,upper,int(screen_n)),6).tolist() if valid_grid else None
        coarse_numbers=[number(v) for v in coarse] if isinstance(coarse,list) else None
        checks.append(truth_gate("frozen_expected_coarse_grid",coarse_numbers==expected_coarse if coarse_numbers is not None and expected_coarse is not None else None,detail={"expected_mm":expected_coarse,"recorded_mm":coarse_numbers}))
        checks.append(truth_gate("coarse_grid_strictly_increasing",all(a<c for a,c in zip(coarse_numbers,coarse_numbers[1:])) if coarse_numbers and None not in coarse_numbers else None))
        coarse_attempts=[next((t for t in trials if number(t.get("stroke_mm"))==s),None) for s in coarse_numbers] if coarse_numbers and None not in coarse_numbers else []
        checks.append(truth_gate("all_frozen_coarse_candidates_have_preserved_attempt_records",True if coarse_attempts and all(t is not None for t in coarse_attempts) else None,detail="Failed attempts remain documented. A missing coarse attempt is not silently filtered from the design."))
        result["coarse_attempts"]=[{"stroke_mm":s,"exists":t is not None,"accepted_solver":t.get("accepted_solver") if t else None,"parsed":t.get("parsed") if t else None,"input_sha256":t.get("input_sha256") if t else None} for s,t in zip(coarse_numbers or [],coarse_attempts)]
        r=model();parser_sha=sha(r.__file__);result["postprocessor_source"]=source(r.__file__)
        for i,item in enumerate(trials):
            entry={"index":i,"stroke_mm":item.get("stroke_mm"),"directory":item.get("directory"),"input_sha256":item.get("input_sha256"),"solver_claimed_accepted":item.get("accepted_solver"),"parsed_claim":item.get("parsed")}
            if item.get("accepted_solver") is not True or item.get("parsed") is not True:
                entry["exclusion_reason"]=item.get("parse_error") or item.get("exception") or "solver/parse not accepted; preserved without re-solving"
                result["preserved_excluded_candidates"].append(entry);continue
            try:
                actual,folder,_,_=resolve_record(item)
                meta=load(folder/"model_metadata.json");status=load(folder/"solver_status.json")
                text=(folder/"input.inp").read_text(encoding="ascii").replace("\r\n","\n")
                input_sha=hashlib.sha256(text.encode("ascii")).hexdigest()
                model_sha=item.get("model_source_sha256");search_model_sha=search.get("model_source_sha256")
                local=[truth_gate("actual_solver_accepted",status.get("accepted_exit")),truth_gate("zero_solver_errors",status.get("returncode")==0 and status.get("error_count")==0),truth_gate("actual_input_SHA_matches_search_and_solver",valid_sha(item.get("input_sha256")) and input_sha==item.get("input_sha256")==status.get("input_sha256") if item.get("input_sha256") and status.get("input_sha256") else None),truth_gate("actual_model_source_matches_search",valid_sha(model_sha) and valid_sha(search_model_sha) and model_sha==search_model_sha if model_sha and search_model_sha else None),truth_gate("actual_stroke_matches_metadata",number(item.get("stroke_mm"))==number(meta["config"].get("stroke_mm")) if number(item.get("stroke_mm")) is not None and number(meta["config"].get("stroke_mm")) is not None else None)]
                trial_path=folder/"trial_result.json"
                if trial_path.is_file():
                    trial_receipt=load(trial_path)
                    local.append(truth_gate("preserved_trial_source_and_input_match_search",trial_receipt.get("input_sha256")==input_sha and trial_receipt.get("model_source_sha256")==model_sha and trial_receipt.get("implementation_source_hashes",{}).get("rect_model.py")==model_sha))
                    entry["actual_trial_receipt_source"]=source(trial_path)
                else:
                    local.append(truth_gate("preserved_trial_source_and_input_match_search",None,detail="Actual trial_result.json/source chain is missing"))
                raw,axes,field_sources,local_initial=_initial_candidate(folder,meta,r);local+=local_initial
                dnodes=folder/"state_D_nodes.txt"
                du=r._load(dnodes,3,meta["mesh_count"]["work_nodes"]);daxis,_=r._centroid_axis(du,meta)
                final_J=r._chord_error(daxis,np.asarray(meta["x_mm"]),130.)
                initial_J=r._chord_error(axes["B"],np.asarray(meta["x_mm"]),130.)
                saved_J=number((item.get("metrics") or {}).get("final_error_mm"));saved_initial=number((item.get("metrics") or {}).get("initial_error_mm"))
                local.extend([finite_gate("candidate_final_J_matches_independent_D_nodes",abs(final_J-saved_J) if saved_J is not None else None,1e-10),finite_gate("candidate_initial_J_matches_independent_B_nodes",abs(initial_J-saved_initial) if saved_initial is not None else None,1e-10)])
                field_sources.append(source(dnodes))
                curve_record={**item,"metrics":{**item.get("metrics",{}),"initial_error_mm":initial_J,"final_error_mm":final_J}}
                local.extend([truth_gate("candidate_B_retained_nonzero_EPEQ",max(raw["B"]["p"].values())>0 if raw["B"]["p"] else None),truth_gate("candidate_B_retained_nonzero_SX",max(abs(v) for v in raw["B"]["sx"].values())>0 if raw["B"]["sx"] else None)])
                inside=np.asarray(meta["x_mm"])<=130.+1e-9
                marker="time,"+str(meta["state_stages"]["C"])
                prefix=text.split(marker,1)[0] if marker in text else None
                local.append(truth_gate("initial_input_prefix_before_corrective_load_present",prefix is not None))
                local.extend([finite_gate("candidate_B_C0_axis",float(np.linalg.norm(axes["B"][inside]-axes["C0"][inside],axis=1).max()),b["zero_history"]["axis_max_distance_mm"]),finite_gate("candidate_B_C0_EPEQ",r._difference(raw["B"]["p"],raw["C0"]["p"]),b["zero_history"]["accumulated_plastic_strain_max_difference"]),finite_gate("candidate_B_C0_SX",r._difference(raw["B"]["sx"],raw["C0"]["sx"]),b["zero_history"]["residual_axial_stress_max_difference_MPa"])])
                if reference is None:
                    reference={"meta":meta,"raw":raw,"axes":axes,"prefix":prefix,"directory":str(folder)}
                else:
                    rm=reference["meta"]
                    same_mesh=all(meta[k]==rm[k] for k in ("x_mm","y_mm","z_mm"))
                    same_config={k:v for k,v in meta["config"].items() if k!="stroke_mm"}=={k:v for k,v in rm["config"].items() if k!="stroke_mm"}
                    local.extend([truth_gate("candidate_same_mesh",same_mesh),truth_gate("candidate_same_physical_config_except_stroke",same_config),truth_gate("candidate_same_material_SHA",meta["material_sha256"]==rm["material_sha256"]),truth_gate("candidate_identical_pre_corrective_input",prefix is not None and prefix==reference["prefix"])])
                    if same_mesh:
                        for state in ("B","C0"):
                            local.extend([finite_gate(state+"_between_candidates_axis",float(np.linalg.norm(axes[state][inside]-reference["axes"][state][inside],axis=1).max()),b["zero_history"]["axis_max_distance_mm"]),finite_gate(state+"_between_candidates_EPEQ",r._difference(raw[state]["p"],reference["raw"][state]["p"]),b["zero_history"]["accumulated_plastic_strain_max_difference"]),finite_gate(state+"_between_candidates_SX",r._difference(raw[state]["sx"],reference["raw"][state]["sx"]),b["zero_history"]["residual_axial_stress_max_difference_MPa"])])
                entry.update(directory=str(folder),metadata_source=source(folder/"model_metadata.json"),solver_status_source=source(folder/"solver_status.json"),initial_field_sources=field_sources,checks=local,status=aggregate(local),independent_objective_mm=final_J,independent_initial_error_mm=initial_J,saved_objective_mm=(item.get("metrics") or {}).get("final_error_mm"),saved_metric_curve_screen=_sample_screen(curve_record,b))
                history_checks.extend([{**c,"candidate_index":i,"stroke_mm":item.get("stroke_mm")} for c in local])
                if entry["status"]=="pass" and _sample_screen(curve_record,b):usable.append(curve_record)
            except Exception as error:
                entry.update(status="inconclusive",error=repr(error));history_checks.append(truth_gate(f"candidate_{i}_actual_initial_history",None,detail=repr(error)))
            result["candidates"].append(entry)
        history_checks.append(truth_gate("at_least_two_actual_candidate_initial_histories",True if len(result["candidates"])>=2 else None,detail="A single solver record does not demonstrate between-candidate history independence"))
        result["reference_initial_directory"]=reference["directory"] if reference else None
        result["candidate_history_status"]=aggregate(history_checks)
        result["curve_screen_usable_n"]=len(usable)
        selected_hits=[t for t in usable if label and t.get("input_sha256")==label.get("best_input_sha256")]
        checks.append(truth_gate("selected_label_maps_to_unique_actual_accepted_candidate",len(selected_hits)==1))
        if len(selected_hits)==1:
            selected=selected_hits[0];winner=audit_case(selected,protocol,budgets);result["winner_numerical_review"]=winner
            selected_stroke=number(selected.get("stroke_mm"));label_stroke=number(label.get("best_sampled_stroke_mm",label.get("best_stroke_mm")))
            checks.append(truth_gate("label_stroke_is_actual_FE_point",selected_stroke==label_stroke and selected_stroke is not None))
            label_J=number(label.get("final_error_mm",label.get("best_residual_error_mm")))
            checks.append(finite_gate("label_objective_matches_independently_parsed_winner",abs(label_J-winner["independently_parsed_metrics"]["final_error_mm"]) if label_J is not None and "independently_parsed_metrics" in winner else None,1e-10,detail="Export precision crosscheck, not the process tolerance"))
            checks.append(truth_gate("winner_has_no_solver_or_saved_numerical_failure",not any(c["status"]=="fail" for c in winner["checks"])))
            checks.append(truth_gate("winner_complete_numerical_evidence",True if winner["overall_status"]=="pass" else None,detail="Individual pending contact/path/sensitivity evidence is retained; this cannot override a global gate"))
            checks.append(finite_gate("declared_search_resolution_mm",resolution,b["mesh_time_contact_sensitivity"]["label_stroke_change_mm"]))
            ordered=sorted(usable,key=lambda t:t["stroke_mm"])
            raw_best=min(usable,key=lambda t:(t["metrics"]["final_error_mm"],t["stroke_mm"]))
            tie=number(settings_s.get("tie_error_mm"));tie=0. if tie is None else tie
            tied=[t for t in usable if t["metrics"]["final_error_mm"]<=raw_best["metrics"]["final_error_mm"]+tie+1e-12]
            checks.append(truth_gate("tie_selected_smallest_actual_stroke",selected["input_sha256"]==min(tied,key=lambda t:t["stroke_mm"])["input_sha256"]))
            neighborhoods={}
            for role,item in (("selected",selected),("raw_best",raw_best)):
                index=next(i for i,t in enumerate(ordered) if t["input_sha256"]==item["input_sha256"])
                left=ordered[index-1] if index else None;right=ordered[index+1] if index+1<len(ordered) else None
                width=right["stroke_mm"]-left["stroke_mm"] if left and right else None
                neighborhoods[role]={"stroke_mm":item["stroke_mm"],"left_mm":left["stroke_mm"] if left else None,"right_mm":right["stroke_mm"] if right else None,"actual_bracket_width_mm":width}
                checks.append(bracket_gate(role+"_actual_two_sided_bracket_width_mm",width,resolution))
            result["independent_actual_neighborhoods"]=neighborhoods
            coarse_records=[next((t for t in usable if number(t["stroke_mm"])==number(s)),None) for s in (coarse or [])]
            coarse_records=[t for t in coarse_records if t];noise=number(settings_s.get("screening_noise_mm"));noise=0. if noise is None else noise
            valleys=[]
            for i in range(1,len(coarse_records)-1):
                a,c,d=coarse_records[i-1:i+2];ea,ec,ed=[t["metrics"]["final_error_mm"] for t in (a,c,d)]
                if ec<=ea+noise and ec<=ed+noise and ec<max(ea,ed)-noise:
                    valleys.append((a["stroke_mm"],d["stroke_mm"],c["stroke_mm"]))
            declared={(v.get("low_mm"),v.get("high_mm"),v.get("screening_stroke_mm")) for v in search.get("identified_screening_valleys",[])}
            checks.append(truth_gate("all_coarse_screening_valleys_independently_accounted",bool(valleys) and set(valleys)==declared))
            result["independent_valleys"]=[]
            for low,high,screening in valleys:
                local=[t for t in ordered if low-1e-9<=t["stroke_mm"]<=high+1e-9]
                best=min(local,key=lambda t:(t["metrics"]["final_error_mm"],t["stroke_mm"]))
                idx=local.index(best);width=local[idx+1]["stroke_mm"]-local[idx-1]["stroke_mm"] if 0<idx<len(local)-1 else None
                result["independent_valleys"].append({"low_mm":low,"high_mm":high,"screening_stroke_mm":screening,"actual_best_mm":best["stroke_mm"],"actual_bracket_width_mm":width})
                checks.append(bracket_gate(f"valley_{screening}_actual_resolved_bracket",width,resolution))
        checks.append(truth_gate("candidate_history_independence",True if result["candidate_history_status"]=="pass" else (False if result["candidate_history_status"]=="fail" else None)))
        checks.append(truth_gate("postprocessor_unchanged_during_search_review",sha(r.__file__)==parser_sha))
        if search_path:checks.append(truth_gate("search_receipt_source_unchanged_during_review",sha(search_path)==search_sha))
    except Exception as error:
        checks.append(truth_gate("actual_search_review",None,detail=repr(error)));result["inspection_error"]=repr(error)
    result["search_reconstruction_status"]=aggregate([c for c in checks if c["check"]!="winner_complete_numerical_evidence"])
    result["overall_status"]=aggregate(checks)
    result["scope"]="Initial-history and actual sampled search reconstruction; saved metric curve screens do not substitute full per-candidate material/contact qualification. No continuous global optimum or formal generation approval."
    case_id=re.sub(r"[^A-Za-z0-9_-]","_",str(result.get("case_id") or "missing"))[:80]
    identity=result.get("search_record_sha256_canonical","missing")[:12]
    destination=Path(receipt_path) if receipt_path else OUTPUT/(case_id+"_"+identity+"_search_receipt.json")
    result["receipt_path"]=str(destination.resolve());save(result,destination)
    return result


def save(value,path):
    path=Path(path).resolve()
    if not path.is_relative_to(OUTPUT.resolve()):raise ValueError("Audit output must stay in new report/numerical_acceptance, never solver/raw/protocol folders")
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+"\n",encoding="utf-8")


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--folder",type=Path);parser.add_argument("--record",type=Path)
    parser.add_argument("--search",type=Path,help="Offline search/history receipt from an actual search_result.json")
    parser.add_argument("--compare",nargs=2);parser.add_argument("--kind",default="mesh",choices=("mesh","time","contact","weak_spring","candidate_history"))
    parser.add_argument("--protocol",type=Path,default=PROTOCOL);parser.add_argument("--budgets",type=Path,default=BUDGETS)
    parser.add_argument("--output",type=Path);parser.add_argument("--validate-only",action="store_true")
    args=parser.parse_args()
    if args.validate_only or not(args.folder or args.record or args.compare or args.search):
        _,_,checks=settings(args.protocol,args.budgets)
        checks.extend([truth_gate("missing_is_inconclusive",finite_gate("x",None,1)["status"]=="inconclusive"),truth_gate("boolean_not_numeric_pass",finite_gate("x",True,1)["status"]=="inconclusive"),truth_gate("nonfinite_not_pass",finite_gate("x",float("nan"),1)["status"]=="inconclusive"),truth_gate("over_budget_fails",finite_gate("x",2,1)["status"]=="fail"),truth_gate("zero_gap_does_not_open",lower_gate("x",0,OPEN_GAP_EPS_MM)["status"]=="fail"),truth_gate("missing_gap_is_inconclusive",lower_gate("x",None,OPEN_GAP_EPS_MM)["status"]=="inconclusive")])
        result={"mode":"validate_only","schema_version":"RECT_NUMERICAL_REVIEW_V001","checks":checks,"overall_status":aggregate(checks),"Ansys_invocations":0,"actual_case_approved":False,"audit_source":source(__file__)}
        destination=args.output or OUTPUT/"validation.json"
    elif args.search:
        result=audit_search(args.search,protocol=args.protocol,budgets=args.budgets,receipt_path=args.output)
        destination=Path(result["receipt_path"])
    elif args.compare:
        result=compare_records(*args.compare,kind=args.kind,protocol=args.protocol,budgets=args.budgets)
        destination=args.output or OUTPUT/(args.kind+"_comparison.json")
    else:
        result=audit_case(args.folder or args.record,args.protocol,args.budgets)
        signature=result.get("input_sha256_text_ascii_lf","missing")[:12]
        destination=args.output or OUTPUT/(signature+"_audit.json")
    save(result,destination)
    print(json.dumps({"output":str(destination),"status":result["overall_status"],"Ansys_invocations":0,"formal_generation_unlocked":False},ensure_ascii=False),flush=True)
    return 0 if result["overall_status"]=="pass" else (2 if result["overall_status"]=="inconclusive" else 1)


if __name__=="__main__":raise SystemExit(main())
