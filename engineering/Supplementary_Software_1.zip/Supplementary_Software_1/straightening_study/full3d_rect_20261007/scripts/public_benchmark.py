"""Public 0007 four-point benchmark using the RECT3D004 shared implementation.

Default CLI action only prepares input and provenance. Ansys is launched only
by the explicit ``run`` action, through this project's solver_runner. No legacy
read_experiment/run_mapdl is called; no old project files are written.
"""
from pathlib import Path
import argparse
import csv
import hashlib
import json
import math
import re

import numpy as np
import rect_model
from solver_runner import ROOT, run_solver, write_json

VERSION = 'PUBLIC_RECT_CORE004_V002'
MODEL_SOURCE_PATH=Path(rect_model.__file__)
IMPORTED_CORE_SOURCE_SHA=hashlib.sha256(MODEL_SOURCE_PATH.read_bytes()).hexdigest()
SOURCE_ROOT = ROOT.parent.parent / 'dataset'
OLD = ROOT.parent / 'auto_run_20261001'
RAW = SOURCE_ROOT / 'Part_1_bending' / 'initial_bending' / 'specimen_0007'
MACHINE = RAW / 'common.csv'
DIC_FILES = {'FORCE_PEAK':RAW/'trueStrain_inc-0439.csv',
             'TOOL_PEAK':RAW/'trueStrain_inc-0447.csv',
             'RECORDED_FINAL':RAW/'trueStrain_inc-0696.csv'}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _number(value):
    return format(float(value),'.16g')


def read_machine():
    """Read original OPARA channels without producing a legacy processed copy."""
    rows,physical_lines=[],[]
    with MACHINE.open(encoding='utf-8-sig',newline='') as stream:
        reader=csv.reader(stream,delimiter=';')
        for row in reader:
            rows.append(row)
            physical_lines.append(reader.line_num)
    times=np.array([float(value.strip().removesuffix(' s')) for value in rows[0][4:]])
    channels={row[0]:(row,no+1,physical_lines[no]) for no,row in enumerate(rows[1:],1)}
    values=[]
    details={}
    for name in ('Weg.DIM','Kraft.DIM','Durchbiegung'):
        row,csv_record,physical_line=channels[name]
        channel=-np.array([float(value) for value in row[4:]])
        if len(channel)!=len(times) or not np.isfinite(channel).all():
            raise ValueError('Incomplete/nonfinite public channel '+name)
        values.append(channel)
        details[name]={'csv_record_1based':csv_record,'physical_line_1based':physical_line,'transform':'negate original numeric channel','unit':'N' if name=='Kraft.DIM' else 'mm'}
    data=np.column_stack((times,*values))
    if not np.isfinite(data).all() or np.any(np.diff(times)<=0):
        raise ValueError('Public machine times are not finite and strictly increasing.')
    legacy=OLD/'processed/bending_0007_machine.csv'
    reference=np.loadtxt(legacy,delimiter=',',skiprows=1)
    if reference.shape!=data.shape or not np.allclose(reference,data,rtol=0,atol=1e-8):
        raise ValueError('Original raw channels do not reproduce the existing processed machine table.')
    provenance={'original_file':str(MACHINE),'sha256':sha(MACHINE),'time_physical_line_1based':physical_lines[0],
                'sample_count':len(data),'sample_source_column_rule_1based':'source sample i (zero based) is column i+5 on the time/channel physical lines',
                'channels':details,'tool_displacement_channel':'-Weg.DIM, not -Durchbiegung',
                'existing_processed_reference':str(legacy),'existing_processed_sha256':sha(legacy),
                'raw_to_existing_processed_verified':True}
    return data,provenance


def read_dic(path):
    """Original layer labels and epsilon_x, preserving physical layer spacing."""
    layers={}
    current=None
    time_value=None
    with Path(path).open(encoding='utf-8-sig') as stream:
        for line_no,line in enumerate(stream,1):
            if line.startswith('"Stufe'):
                time_value=float(next(csv.reader([line],delimiter=';'))[2])
            elif line.startswith('# Name'):
                current=float(re.search(r'Y\s+(-?\d+\.\d+)',line)[1])
                layers[current]={'header_line_1based':line_no,'points':[],'lines':[]}
            elif current is not None:
                fields=line.strip().split(';')
                if len(fields)==9 and re.fullmatch(r'\d+',fields[0]):
                    layers[current]['points'].append((float(fields[1]),float(fields[5])))
                    layers[current]['lines'].append(line_no)
    if not layers or time_value is None or any(not q['points'] for q in layers.values()):
        raise ValueError('Incomplete original DIC layers/time '+str(path))
    midpoint=(min(layers)+max(layers))/2
    profile=[]
    row_map=[]
    for label,item in sorted(layers.items()):
        points=np.asarray(item['points'])
        profile.append([label,label-midpoint,len(points),float(points[:,1].mean()),float(points[:,1].std(ddof=1)),float(points[:,0].min()),float(points[:,0].max())])
        row_map.append({'layer_label_mm':label,'centered_y_mm':label-midpoint,'name_header_line_1based':item['header_line_1based'],'point_physical_lines_1based':item['lines'],'point_count':len(points)})
    return np.asarray(profile),{'original_file':str(path),'sha256':sha(path),'actual_time_s':time_value,'epsilon_x_column_1based':6,
                              'strain_unit':'dimensionless true strain','layer_mapping':'original Ebene Y label minus midpoint of minimum/maximum label; no thickness rescaling',
                              'layer_midpoint_original_mm':midpoint,'layer_rows':row_map}


def _selection(data,stride,dic):
    if int(stride)!=stride or stride<1:
        raise ValueError('stride must be a positive integer; 1 retains every source sample.')
    displacement=data[:,1]
    changes=np.diff(displacement)
    # Preserve every observed change of direction, including the two ends of
    # zero-increment plateaus. No denoising rule is fitted to the experiment.
    turns=[i for i in range(1,len(data)-1) if changes[i-1]*changes[i]<0
           or ((changes[i-1]==0)!=(changes[i]==0))]
    required={0,len(data)-1,int(np.argmax(data[:,1])),int(np.argmax(data[:,2])),*turns}
    frame_indices={label:int(np.argmin(abs(data[:,0]-record['actual_time_s']))) for label,record in dic.items()}
    required.update(frame_indices.values())
    kept=sorted(required.union(range(0,len(data),int(stride))))
    approximation=np.interp(data[:,0],data[kept,0],data[kept,1])
    return kept,frame_indices,{'stride':int(stride),'first_last_peaks_and_all_observed_displacement_turns_retained':True,
                              'turn_source_indices_0based':turns,'mandatory_source_indices_0based':sorted(required),
                              'kept_source_indices_0based':kept,'full_count':len(data),'selected_count':len(kept),
                              'tool_path_max_abs_difference_at_original_samples_mm':float(np.max(abs(approximation-data[:,1]))),
                              'tool_path_rmse_at_original_samples_mm':float(np.sqrt(np.mean((approximation-data[:,1])**2))),
                              'full_trajectory_available_with_stride_1':True}


def build(config=None,stride=1):
    data,machine_source=read_machine()
    dic={label:read_dic(path)[1] for label,path in DIC_FILES.items()}
    kept,frame_indices,selection=_selection(data,stride,dic)
    cfg={'b_mm':35.,'h_mm':8.,'length_mm':270.,'support_span_mm':260.,'punch_radius_mm':10.,'support_radius_mm':10.,
         'prebend_outer_span_mm':260.,'prebend_inner_span_mm':100.,'prebend_radius_mm':10.,'prebend_tool_stroke_mm':float(data[:,1].max()),
         'stroke_mm':0.,'material_version':'v002','save_full_strain_trajectory':True,**(config or {})}
    for name,expected in (('b_mm',35.),('h_mm',8.),('length_mm',270.),('support_span_mm',260.),
                          ('punch_radius_mm',10.),('support_radius_mm',10.),('prebend_outer_span_mm',260.),
                          ('prebend_inner_span_mm',100.),('prebend_radius_mm',10.),
                          ('prebend_tool_stroke_mm',float(data[:,1].max())),('stroke_mm',0.)):
        if not np.isclose(float(cfg[name]),expected,rtol=0,atol=1e-12):
            raise ValueError('This nominal public benchmark fixes '+name)
    if cfg['material_version']!='v002' or cfg['save_full_strain_trajectory'] is not True:
        raise ValueError('Public benchmark fixes V002 material and full strain-trajectory output.')
    if sha(MODEL_SOURCE_PATH)!=IMPORTED_CORE_SOURCE_SHA:
        raise ValueError('Imported core source changed; reload this preparation process.')
    common,core=rect_model.build(cfg)
    if sha(MODEL_SOURCE_PATH)!=IMPORTED_CORE_SOURCE_SHA:
        raise ValueError('Core source changed during preparation; no frozen benchmark was generated.')
    if core['model_version']!='RECT3D004':
        raise ValueError('Benchmark source was reviewed against RECT3D004; review a new version before using it.')
    marker='time,1\n'
    if common.count(marker)!=1:
        raise ValueError('Cannot uniquely identify the common first solution stage.')
    prefix=common.split(marker,1)[0]
    nn=core['mesh_count']['work_nodes']
    ne=core['mesh_count']['solid_elements']
    a_marker=f"set,{core['state_stages']['A']},last\nallsel,all\n*dim,UA,array,{nn},3\n"
    b_marker=f"set,{core['state_stages']['B']},last\nallsel,all\n*dim,UB,array,{nn},3\n"
    first=common.index(a_marker)
    second=common.index(b_marker,first+len(a_marker))
    state_template=common[first:second]
    post_start=common.index('finish\n/post1\n')
    history_start=common.index('*cfopen,history,txt\n',post_start)
    history_end=common.index('*cfclos\n',history_start)+len('*cfclos\n')
    shared_post_header=common[post_start:history_start]
    shared_strain_post=common[history_end:first]
    if '*cfopen,strain_history,txt' not in shared_strain_post:
        raise ValueError('Common full-path strain output was not found; no silent substitute is allowed.')
    lines=[prefix.rstrip()]
    ph=core['tools']['prehead']['pilot_node']
    pb=core['tools']['prebase']['pilot_node']
    gauge=core['weak_spring']['node']
    ny,nz=core['config']['ny'],core['config']['nz']
    center=1+(ny//2)*(nz+1)
    step_map=[]
    time_offset=1e-6
    previous_disp=0.
    increment=core['config']['max_tool_increment_mm']
    unloading_increment=core['config']['unload_increment_mm']
    for step,index in enumerate(kept,1):
        time_s,displacement,force,deflection=map(float,data[index])
        solver_time=time_s-float(data[0,0])+time_offset
        active_increment=unloading_increment if displacement<previous_disp else increment
        sub=max(2,math.ceil(abs(displacement-previous_disp)/active_increment))
        lines.extend([f'time,{_number(solver_time)}',f'd,{ph},uy,{_number(-displacement)}',f'nsubst,{sub},{max(500,sub*10)},{sub}','solve'])
        step_map.append({'load_step':step,'original_sample_index_0based':index,'original_sample_column_1based':index+5,
                         'experiment_time_s':time_s,'solver_time':solver_time,'tool_displacement_mm':displacement,
                         'measured_force_N':force,'reported_deflection_mm_diagnostic':deflection,'initial_substeps':sub})
        previous_disp=displacement
    recorded_final_step=len(kept)
    release=core['config']['tool_release_gap_mm']
    fine=core['config']['fine_withdrawal_clearance_mm']
    last_time=float(data[-1,0]-data[0,0]+time_offset)
    withdrawals=[(f'd,{ph},uy,0',abs(previous_disp),unloading_increment),
                 (f'd,{ph},uy,{_number(release)}',release,release),
                 (f'd,{pb},uy,{_number(-fine)}',fine,unloading_increment),
                 (f'd,{pb},uy,{_number(-release)}',release-fine,release)]
    for offset,(command,travel,inc) in enumerate(withdrawals,1):
        sub=max(2,math.ceil(travel/inc))
        lines.extend([f'time,{_number(last_time+offset)}',command,f'nsubst,{sub},{max(500,sub*10)},{sub}','solve'])
    state_steps={label:next(row['load_step'] for row in step_map if row['original_sample_index_0based']==index) for label,index in frame_indices.items()}
    state_steps['FREE']=recorded_final_step+len(withdrawals)
    lines.extend([shared_post_header.rstrip(),'*cfopen,history,txt','*do,iset,1,ntset','allsel,all','set,,,,,,,iset',
                  '*get,lstep,active,0,set,lstp','*get,rtime,active,0,set,time',f'*get,phuy,node,{ph},u,y',f'*get,phfy,node,{ph},rf,fy',
                  f'*get,pbfy,node,{pb},rf,fy',f'*get,swuy,node,{gauge},u,y',f'*get,ccuy,node,{center},u,y',
                  '*vwrite,iset,lstep,rtime,phuy,phfy,pbfy,swuy,ccuy','(8(E24.16,1X))','*enddo','*cfclos',shared_strain_post.rstrip()])
    for label,step in state_steps.items():
        block=state_template.replace(a_marker,f'set,{step},last\nallsel,all\n*dim,U{label},array,{nn},3\n',1)
        block=block.replace('state_A_',f'state_{label}_')
        block=re.sub(r'\bUA\b','U'+label,block)
        block=re.sub(r'\bEA\b','E'+label,block)
        lines.append(block.rstrip())
    lines.extend(['*cfopen,complete,txt','*vwrite,1','(F8.0)','*cfclos','finish','save,model,db','/exit,nosave'])
    text='\n'.join(lines)+'\n'
    expected=['complete.txt','solve.rst','history.txt','contact_identity.txt','strain_history.txt','strain_history_log.txt']
    for label in state_steps:
        expected.extend(name.replace('state_A_',f'state_{label}_') for name in core['expected_files'] if name.startswith('state_A_'))
    for label,record in dic.items():
        index=frame_indices[label]
        record.update(machine_source_index_0based=index,machine_time_s=float(data[index,0]),time_difference_s=float(data[index,0]-record['actual_time_s']),load_step=state_steps[label])
    sources={str(MACHINE):sha(MACHINE),str(MODEL_SOURCE_PATH):sha(MODEL_SOURCE_PATH),str(Path(__file__)):sha(__file__),
             str(OLD/'scripts/benchmark_3d.py'):sha(OLD/'scripts/benchmark_3d.py'),str(OLD/'scripts/benchmark.py'):sha(OLD/'scripts/benchmark.py'),
             str(ROOT/'provenance/source_manifest.json'):sha(ROOT/'provenance/source_manifest.json'),
             str(ROOT/'provenance/data_usage.json'):sha(ROOT/'provenance/data_usage.json'),
             core['material_file']:core['material_sha256']}
    sources.update({record['original_file']:record['sha256'] for record in dic.values()})
    metadata={'benchmark_version':VERSION,'input_sha256':hashlib.sha256(text.encode('ascii')).hexdigest(),'core_metadata':core,
              'core_model_source_sha256':sha(MODEL_SOURCE_PATH),'benchmark_source_sha256':sha(__file__),'source_file_sha256':sources,
              'machine_source':machine_source,'selection':selection,'source_to_solver_steps':step_map,'state_steps':state_steps,
              'dic_sources':dic,'expected_files':expected,'recorded_final_load_step':recorded_final_step,
              'time_mapping':{'solver_time_equals':'experiment_time - first_experiment_time + 0.000001','initial_time_offset':time_offset,'first_experiment_time_s':float(data[0,0]),'synthetic_withdrawal_steps_excluded_from_experimental_rmse':True},
              'apdl_modification':{'shared_prefix_ends_before':'time,1','shared_prefix_sha256':hashlib.sha256(prefix.encode('ascii')).hexdigest(),
                  'shared_post_field_template':'Core state A block reused with label/SET renaming only','shared_post_template_sha256':hashlib.sha256(state_template.encode('ascii')).hexdigest(),
                  'replacement':'Public measured relative-tool trajectory replaces the synthetic pre-bend/correction solution stages; core full-path strain and state export blocks reused',
                  'extra_corrective_tools':'retained at their original remote positions, never moved or used for this benchmark','free_withdrawal':'core004 approach: small-step head return to zero, air retreat, small-step support clearance, air retreat',
                  '004_change_basis':'Core maintainer confirmed 004 differs from 003 only in guarded POST contact-ETABLE column retrieval; 11-stage physical path and first-SOLVE API are unchanged.'},
              'geometry_basis':'nominal 35 x 8 x 270 mm; individual 0007 dimension measurements not traced to an original source',
              'fixture_scope':'fixed-pose ideal rigid cylinders; no claim to reproduce measured elastic mounting rotations',
              'limitations':['Public machine displacement has defined channel transformation; reported deflection is only diagnostic.',
                  'Sampled tool trace approximation is explicitly recorded; stride=1 reproduces every recorded displacement point.',
                  'The rate-independent static time parameter maps recorded times but does not reproduce machine dynamics.',
                  'DIC derivative/filter support is unpublished; fixed 6 mm geometric gauge and 2 mm sensitivity are numerical comparison definitions, not matched instrument settings.',
                  'DIC final frame is compared to recorded-final FE state, not silently to the extra fully free withdrawal state.',
                  'No paired complete residual centroid centerline is provided; FE centerline files cannot be called experimental shape validation.',
                  'Reverse three-point straightening is outside this public four-point comparison.'],
              'solver_started':False,'formal_qualification_granted':False}
    return text,metadata,data


def _write_csv(path,headers,rows):
    with Path(path).open('w',encoding='utf-8-sig',newline='') as stream:
        writer=csv.writer(stream)
        writer.writerow(headers)
        writer.writerows(rows)


def prepare(name='PUBLIC0007_CORE004_NOMINAL_V002',config=None,stride=1):
    if not re.fullmatch(r'[A-Za-z0-9_-]{1,100}',name):
        raise ValueError('Invalid benchmark folder name.')
    text,metadata,data=build(config,stride)
    folder=ROOT/'benchmark'/name
    if folder.exists():
        raise FileExistsError('Original benchmark preparation/results are preserved; use a new benchmark name.')
    folder.mkdir(parents=True)
    (folder/'input.inp').write_bytes(text.encode('ascii'))
    write_json(folder/'benchmark_metadata.json',metadata)
    headers=['load_step','original_sample_index_0based','original_sample_column_1based','experiment_time_s','solver_time','tool_displacement_mm','measured_force_N','reported_deflection_mm_diagnostic','initial_substeps']
    _write_csv(folder/'source_step_mapping.csv',headers,[[row[h] for h in headers] for row in metadata['source_to_solver_steps']])
    return folder,metadata


def _kinematic_profile(u,core,gauge=6.):
    x=np.asarray(core['x_mm']); y=np.asarray(core['y_mm']); z=np.asarray(core['z_mm'])
    field=u.reshape(len(x),len(y),len(z),3)
    mids=x[(x>=5)&(x<=40)]
    result=[]
    for j,yy in enumerate(y):
        stretch=[]
        for mid in mids:
            a,b=mid-gauge/2,mid+gauge/2
            if a<x[0] or b>x[-1]:
                continue
            delta=np.array([gauge,0.,0.])+np.array([np.interp(b,x,field[:,j,-1,k])-np.interp(a,x,field[:,j,-1,k]) for k in range(3)])
            stretch.append(math.log(float(np.linalg.norm(delta))/gauge))
        if not stretch:
            raise ValueError('No geometric DIC gauges inside the declared axial domain.')
        result.append([float(yy),float(np.mean(stretch)),float(np.std(stretch,ddof=1)),len(stretch)])
    return np.asarray(result)


def parse(folder,reanalysis=False,analysis_name=None):
    folder=Path(folder).resolve()
    if not folder.is_relative_to(ROOT.resolve()):
        raise ValueError('Benchmark output folder must lie inside the new project.')
    meta=json.loads((folder/'benchmark_metadata.json').read_text(encoding='utf-8'))
    if sha(folder/'input.inp')!=meta['input_sha256']:
        raise ValueError('Saved benchmark input SHA differs from its metadata.')
    current_core_sha=sha(MODEL_SOURCE_PATH)
    current_benchmark_sha=sha(__file__)
    changed=current_core_sha!=meta['core_model_source_sha256'] or current_benchmark_sha!=meta['benchmark_source_sha256']
    if changed and not reanalysis:
        raise ValueError('Postprocessor source changed. Use explicit --reanalysis and --analysis-name to create an independent receipt; existing metrics are preserved.')
    if rect_model.VERSION!=meta['core_metadata']['model_version']:
        raise ValueError('A different core model version needs an explicit benchmark compatibility review.')
    status=json.loads((folder/'solver_status.json').read_text(encoding='utf-8'))
    if status.get('accepted_exit') is not True:
        raise RuntimeError('Benchmark solver did not complete successfully; preserve it as a failed diagnostic.')
    if status.get('input_sha256')!=meta['input_sha256']:
        raise ValueError('Solver receipt SHA does not match this benchmark input.')
    output=folder
    if reanalysis:
        if analysis_name is None or not re.fullmatch(r'[A-Za-z0-9_-]{1,100}',analysis_name):
            raise ValueError('Explicit reanalysis requires a valid new analysis_name.')
        output=folder/'reanalysis'/analysis_name
        if output.exists():
            raise FileExistsError('Prior analysis is preserved; choose a new analysis_name.')
        output.mkdir(parents=True)
    data,source=read_machine()
    if source['sha256']!=meta['machine_source']['sha256']:
        raise ValueError('Original experimental machine source changed.')
    history=rect_model._load(folder/'history.txt',8)
    public=history[history[:,1]<=meta['recorded_final_load_step']]
    t=public[:,2]-meta['time_mapping']['initial_time_offset']+meta['time_mapping']['first_experiment_time_s']
    if t.min()>data[0,0]+1e-8 or t.max()<data[-1,0]-1e-8 or np.any(np.diff(t)<=0):
        raise ValueError('Computed force history does not cover the full public recorded time interval.')
    force=-4*public[:,4]
    predicted=np.interp(data[:,0],t,force)
    difference=predicted-data[:,2]
    metrics={'benchmark_version':meta['benchmark_version'],'accepted_solver':True,'force_comparison_sample_count':len(data),
             'force_comparison':'Computed reaction at every converged substep, interpolated to each original recorded time; synthetic withdrawal excluded',
             'force_rmse_N':float(np.sqrt(np.mean(difference**2))),'force_nrmse_peak':float(np.sqrt(np.mean(difference**2))/max(abs(data[:,2]))),
             'force_mae_N':float(np.mean(abs(difference))),'force_max_abs_error_N':float(np.max(abs(difference))),
             'computed_peak_force_N':float(np.max(force)),'experimental_peak_force_N':float(np.max(data[:,2])),
             'experimental_tool_peak_mm':float(data[:,1].max()),'geometry_basis':meta['geometry_basis'],
             'full_centerline_experimental_comparison_available':False,'full_centerline_limitation':meta['limitations'][5],
             'state_quality':{},'dic_comparison':{},'limitations':meta['limitations'],'formal_qualification_granted':False}
    _write_csv(output/'force_at_original_times.csv',['original_sample_index_0based','original_sample_column_1based','experiment_time_s','tool_displacement_mm','experimental_force_N','computed_force_N','computed_minus_experiment_N'],[[i,i+5,*data[i,:3],predicted[i],difference[i]] for i in range(len(data))])
    _write_csv(output/'computed_force_substeps.csv',['set_number','load_step','experiment_time_s','tool_displacement_mm','computed_total_force_N','weak_spring_UY_mm'],[[*row[:2],time_s,-row[3],full_force,row[6]] for row,time_s,full_force in zip(public,t,force)])
    core=meta['core_metadata']
    nn=core['mesh_count']['work_nodes']; ne=core['mesh_count']['solid_elements']
    identities,bytool=rect_model._contact_identities(folder,core)
    metrics['contact_identity_verified']=True
    for label in meta['state_steps']:
        u=rect_model._load(folder/f'state_{label}_nodes.txt',3,nn)
        elem=rect_model._load(folder/f'state_{label}_element_extrema.txt',4,ne)
        scalars=rect_model._load(folder/f'state_{label}_scalars.txt',6,1)[0]
        axis,areas=rect_model._centroid_axis(u,core)
        _write_csv(output/f'centroid_centerline_{label}.csv',['reference_x_mm','deformed_x_mm','deformed_y_mm','deformed_z_mm','full_section_area_mm2'],np.column_stack((core['x_mm'],axis,areas)))
        p=rect_model._presol_records(folder/f'state_{label}_p.txt',('EPEQ',))
        ex=rect_model._presol_records(folder/f'state_{label}_ex.txt',('EX','EPTOX'))
        covered=rect_model._ip_coverage(p,core) and rect_model._ip_coverage(ex,core)
        crosscheck=covered and max(abs(max(p.values())-elem[:,0].max()),abs(min(p.values())-elem[:,1].min()),abs(max(ex.values())-elem[:,2].max()),abs(min(ex.values())-elem[:,3].min()))<=1e-10
        penetration=rect_model._presol_records(folder/f'state_{label}_penetration.txt',('PENE','PENETRATION'))
        pressure=rect_model._presol_records(folder/f'state_{label}_pressure.txt',('PRES','PRESSURE'))
        contact,raw_contact_complete=rect_model._contact_state(folder,label,core,u,identities,bytool,penetration,pressure)
        metrics['state_quality'][label]={'raw_ip_coverage':bool(covered),'raw_extrema_crosscheck':bool(crosscheck),
            'contact_by_tool':contact,'raw_contact_coverage_complete':raw_contact_complete,
            'max_copied_ip_accumulated_plastic_strain':max(p.values()) if p else None,
            'max_abs_copied_ip_axial_total_strain':max(abs(v) for v in ex.values()) if ex else None,
            'tool_signed_forces_N':{'corrective_punch':float(4*scalars[2]),'corrective_supports':float(4*scalars[3]),'prebend_heads':float(4*scalars[4]),'prebend_supports':float(4*scalars[5])},
            'fixed_260_centroid_chord_deviation_mm':rect_model._chord_error(axis,np.asarray(core['x_mm']),130.)}
        if label in meta['dic_sources']:
            dic,original=read_dic(meta['dic_sources'][label]['original_file'])
            if original['sha256']!=meta['dic_sources'][label]['sha256']:
                raise ValueError('Original DIC source changed.')
            profile6=_kinematic_profile(u,core,6.)
            profile2=_kinematic_profile(u,core,2.)
            if dic[:,1].min()<profile6[:,0].min()-1e-9 or dic[:,1].max()>profile6[:,0].max()+1e-9:
                raise ValueError('DIC layer lies outside nominal thickness; no strain extrapolation performed.')
            pred6=np.interp(dic[:,1],profile6[:,0],profile6[:,1]); pred2=np.interp(dic[:,1],profile2[:,0],profile2[:,1])
            error=pred6-dic[:,3]
            _write_csv(output/f'DIC_{label}_comparison.csv',['layer_label_mm','centered_y_mm','DIC_point_count','DIC_mean_true_strain','DIC_spatial_std','DIC_min_x_mm','DIC_max_x_mm','FE_6mm_geometric_true_strain','FE_minus_DIC','FE_2mm_geometric_true_strain'],np.column_stack((dic,pred6,error,pred2)))
            _write_csv(output/f'FE_{label}_geometric_profile.csv',['y_mm','mean_6mm_log_stretch','axial_spatial_std','gauge_count'],profile6)
            metrics['dic_comparison'][label]={'rmse_strain':float(np.sqrt(np.mean(error**2))),'max_abs_error_strain':float(np.max(abs(error))),
                'gauge_6mm_vs_2mm_rmse':float(np.sqrt(np.mean((pred6-pred2)**2))),'dic_actual_time_s':original['actual_time_s'],
                'compared_machine_time_s':meta['dic_sources'][label]['machine_time_s'],'time_difference_s':meta['dic_sources'][label]['time_difference_s'],
                'strain_method':'ln(3D displaced initial axial 6 mm line length / 6 mm), free width face, midpoint x=5..40 mm; same initial layer labels, no parameter fitting'}
    strain=rect_model._load(folder/'strain_history.txt',5,len(history))
    if not np.allclose(strain[:,:3],history[:,:3],rtol=0,atol=1e-10):
        raise ValueError('Full-path strain SET/time coverage does not match every converged substep.')
    metrics['full_path_strain_output_available']=bool(rect_model._listing_available(folder/'strain_history_log.txt'))
    metrics['full_path_strain_coverage_verified']=True
    metrics['full_path_max_abs_axial_total_strain']=float(np.max(abs(strain[:,3:5])))
    metrics['max_full_domain_weak_spring_force_N']=float(4*core['weak_spring']['stiffness_N_per_mm']*np.max(abs(history[:,6])))
    metrics['input_sha256']=meta['input_sha256']
    metrics['input_generation_core_source_sha256']=meta['core_model_source_sha256']
    metrics['input_generation_benchmark_source_sha256']=meta['benchmark_source_sha256']
    metrics['postprocessor_core_source_sha256']=current_core_sha
    metrics['postprocessor_benchmark_source_sha256']=current_benchmark_sha
    metrics['extra_free_state_all_tools_open']=all(tool['independently_open_by_geometry_and_RF'] for tool in metrics['state_quality']['FREE']['contact_by_tool'].values())
    metrics['output_folder']=str(output)
    write_json(output/'benchmark_metrics.json',metrics)
    if reanalysis:
        write_json(output/'reanalysis_receipt.json',{'explicit_reanalysis':True,'input_sha256':meta['input_sha256'],
            'input_generation_core_source_sha256':meta['core_model_source_sha256'],
            'input_generation_benchmark_source_sha256':meta['benchmark_source_sha256'],
            'postprocessor_core_source_sha256':current_core_sha,'postprocessor_benchmark_source_sha256':current_benchmark_sha,
            'source_changed':changed,'original_metadata_sha256':sha(folder/'benchmark_metadata.json'),
            'solver_status_sha256':sha(folder/'solver_status.json'),'reused_raw_outputs_without_new_FE':True,
            'raw_result_sha256':{name:sha(folder/name) for name in meta['expected_files']},'output_folder':str(output)})
    return metrics


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action',nargs='?',choices=('prepare','run','parse'),default='prepare')
    parser.add_argument('--name',default='PUBLIC0007_CORE004_NOMINAL_V002')
    parser.add_argument('--folder',type=Path)
    parser.add_argument('--stride',type=int,default=1)
    parser.add_argument('--config',type=Path)
    parser.add_argument('--timeout',type=float,default=7200)
    parser.add_argument('--reanalysis',action='store_true')
    parser.add_argument('--analysis-name')
    args=parser.parse_args()
    if (args.reanalysis or args.analysis_name) and args.action!='parse':
        parser.error('--reanalysis/--analysis-name are only for explicit parsing of original raw outputs')
    if args.action=='parse':
        if args.folder is None:
            parser.error('parse requires --folder')
        print(json.dumps(parse(args.folder,args.reanalysis,args.analysis_name),ensure_ascii=False,indent=2))
        return
    configuration=json.loads(args.config.read_text(encoding='utf-8-sig')) if args.config else None
    if args.folder is None:
        folder,meta=prepare(args.name,configuration,args.stride)
    else:
        folder=args.folder.resolve()
        if not folder.is_relative_to(ROOT.resolve()):
            raise ValueError('Folder must lie inside the new study.')
        meta=json.loads((folder/'benchmark_metadata.json').read_text(encoding='utf-8'))
    if args.action=='run':
        if sha(folder/'input.inp')!=meta['input_sha256'] or sha(MODEL_SOURCE_PATH)!=meta['core_model_source_sha256'] or sha(__file__)!=meta['benchmark_source_sha256']:
            raise ValueError('Prepared input/core/benchmark source changed; prepare a new explicitly reviewed benchmark version.')
        status=run_solver(folder,(folder/'input.inp').read_text(encoding='ascii'),meta['expected_files'],timeout=args.timeout)
        print(json.dumps(parse(folder) if status['accepted_exit'] else {'accepted_solver':False,'status':status},ensure_ascii=False,indent=2))
    else:
        print(json.dumps({'action':'prepared_only','folder':str(folder),'input_sha256':meta['input_sha256'],'public_samples':meta['selection']['full_count'],
                          'retained_load_samples':meta['selection']['selected_count'],'tool_trace_max_difference_mm':meta['selection']['tool_path_max_abs_difference_at_original_samples_mm'],
                          'solver_started':False,'formal_qualification_granted':False},ensure_ascii=False,indent=2))


if __name__=='__main__':
    main()
