"""An actual independent full-history candidate. No label interpolation."""
from pathlib import Path
from datetime import datetime,timezone,timedelta
import argparse, hashlib, json, math
from solver_runner import ROOT, run_solver, write_json

BASE={'case_id':'BASE','b_mm':35.0,'h_mm':8.0,'length_mm':270.0,
      'support_span_mm':260.0,'punch_radius_mm':10.0,'support_radius_mm':10.0,
      'prebend_tool_stroke_mm':15.6934,'prebend_outer_span_mm':260.0,
      'prebend_inner_span_mm':100.0,'prebend_radius_mm':10.0,
      'friction':0.15,'material_version':'v002','ny':8,'nz':4,'dx_mm':2.0}

def run_trial(config,stroke_mm,timeout=2400):
    from rect_model import build,parse
    config={**BASE,**config,'stroke_mm':float(stroke_mm)}
    model_source_sha=hashlib.sha256((ROOT/'scripts'/'rect_model.py').read_bytes()).hexdigest()
    source_hashes={name:hashlib.sha256((ROOT/'scripts'/name).read_bytes()).hexdigest()
                   for name in ('rect_model.py','trial.py','solver_runner.py')}
    if not math.isfinite(stroke_mm) or stroke_mm<0: raise ValueError('Stroke must be finite and nonnegative.')
    text,metadata=build(config)
    signature=hashlib.sha256(text.encode('ascii')).hexdigest()
    case_id=str(config['case_id'])
    if not case_id.replace('_','').replace('-','').isalnum(): raise ValueError('Invalid case ID.')
    folder=ROOT/'runs'/case_id/f'S{stroke_mm:.6f}_{signature[:12]}'
    folder.mkdir(parents=True,exist_ok=True)
    write_json(folder/'config.json',config)
    write_json(folder/'model_metadata.json',metadata)
    expected=metadata.get('expected_files',['complete.txt','solve.rst'])
    status=run_solver(folder,text,expected,timeout=timeout)
    record={'case_id':case_id,'stroke_mm':float(stroke_mm),'directory':str(folder.relative_to(ROOT)),
            'input_sha256':signature,'model_source_sha256':model_source_sha,
            'implementation_source_hashes':source_hashes,
            'provenance_manifest_sha256':hashlib.sha256((ROOT/'provenance'/'source_manifest.json').read_bytes()).hexdigest(),
            'solver_status':status,'recorded_time_China':datetime.now(timezone(timedelta(hours=8))).isoformat(),
            'accepted_solver':status['accepted_exit']}
    if status['accepted_exit']:
        try:
            if any(hashlib.sha256((ROOT/'scripts'/name).read_bytes()).hexdigest()!=digest
                   for name,digest in source_hashes.items()):
                raise RuntimeError('Implementation changed during this solve; preserve raw output and perform explicit separate reanalysis.')
            record['metrics']=parse(folder,metadata)
            record['parsed']=True
        except Exception as error:
            record['parsed']=False; record['parse_error']=repr(error)
    else: record['parsed']=False
    write_json(folder/'trial_result.json',record)
    return record

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--config');parser.add_argument('--case-id',default='BASE');parser.add_argument('--stroke',type=float,default=0.0)
    parser.add_argument('--ny',type=int,default=8);parser.add_argument('--nz',type=int,default=4);parser.add_argument('--dx',type=float,default=2.0);parser.add_argument('--timeout',type=float,default=2400)
    args=parser.parse_args()
    config=json.loads(Path(args.config).read_text(encoding='utf-8-sig')) if args.config else BASE.copy()
    config.update(case_id=args.case_id,ny=args.ny,nz=args.nz,dx_mm=args.dx)
    result=run_trial(config,args.stroke,args.timeout)
    print(json.dumps(result,ensure_ascii=False,indent=2),flush=True)
    raise SystemExit(0 if result['accepted_solver'] and result.get('parsed') else 1)
