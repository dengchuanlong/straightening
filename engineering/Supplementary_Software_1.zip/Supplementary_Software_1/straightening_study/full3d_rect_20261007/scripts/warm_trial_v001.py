"""Explicit actual warm candidate records; never masquerade as cold trials.

Import and plan/parse are read-only. Only explicit prepare/run functions create
NEW targets or launch the unchanged, serial Student solver. This scaffold does
not enable production, qualify labels, train, release scratch or alter old data.
"""
from pathlib import Path
from datetime import datetime, timezone, timedelta
import hashlib
import json
import math
import traceback
import numpy as np
import rect_model
import warm_restart
import warm_version_guard_adapter_v001 as adapter
from solver_runner import ROOT, EXE, run_solver
from search_cases import admissibility

VERSION = 'ACTUAL_WARM_TRIAL001'
FEATURES = ('b_mm', 'h_mm', 'support_span_mm', 'punch_radius_mm',
            'support_radius_mm', 'prebend_tool_stroke_mm')
PIN_NAMES = ('rect_model.py', 'solver_runner.py', 'warm_restart.py',
             'warm_version_guard_adapter_v001.py', 'warm_trial_v001.py', 'search_cases.py')
BASE_PARENT = ROOT / 'warm_production/bases'
BRANCH_PARENT = ROOT / 'warm_production/branches'
SCHEMA = 'RECT_WARM_CANDIDATE_V001'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'),
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError('Nonfinite JSON: ' + value)))


def sha(path):
    return warm_restart.sha(path)


def canonical_sha(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
                                     allow_nan=False).encode('utf-8')).hexdigest()


def write_new(path, value):
    payload = json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n'
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(payload)


def now():
    return datetime.now(timezone(timedelta(hours=8))).isoformat()


def pins():
    return {name: sha(ROOT / 'scripts' / name) for name in PIN_NAMES}


def verify_pins(expected):
    if pins() != expected:
        raise RuntimeError('Warm producer/parser sources changed; preserve attempt and reanalyse explicitly.')


def source(path, role):
    path = Path(path).resolve()
    before = path.stat()
    digest = sha(path)
    after = path.stat()
    if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
        raise RuntimeError('Source changed during provenance SHA read: ' + str(path))
    return {'path': str(path), 'sha256': digest, 'bytes': after.st_size,
            'mtime_ns': after.st_mtime_ns, 'role': role}


def stroke(value):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value < 0:
        raise ValueError('Stroke must be an actual finite nonnegative number.')
    return float(value)


def bounded_timeout(value):
    if type(value) not in (int, float) or not math.isfinite(value) or not 0 < value <= 32400:
        raise ValueError('Timeout must be a finite positive actual number at most 32400 seconds.')
    return float(value)


def _verify_branch_inputs(base, folder, metadata):
    # Repeat the frozen prototype's pre-SOLVE source/copy guards. Writable
    # computational copies may change during SOLVE, never before this call.
    warm_restart._verify_hashes(base, metadata['source_base_snapshot'])
    for copied in metadata['computational_copies']:
        if sha(folder / copied['filename']) != copied['destination_initial_sha256']:
            raise ValueError('A prepared branch computational input changed before its first solve.')


def actual_status(folder, metadata):
    # Correct release/build recognition is in the separately reviewed adapter.
    status = adapter.strict_solver_complete(folder, metadata)
    if not (type(status.get('returncode')) is int and status['returncode'] == 0
            and type(status.get('error_count')) is int and status['error_count'] == 0
            and status.get('timed_out') is False and status.get('exception') is None
            and status.get('process_tree', {}).get('tree_exit_confirmed') is True):
        raise RuntimeError('Actual solver error/timeout/process-tree exit evidence failed.')
    tree = status['process_tree']
    if tree.get('live_identities') != [] or tree.get('identity_errors') != [] or not launch_evidence(status)['actual_launch_verified']:
        raise RuntimeError('Actual owned tree identities are missing, invalid or still live.')
    return status


def launch_evidence(status):
    identities = (status or {}).get('process_tree', {}).get('identities', [])
    valid = bool(not (status or {}).get('software_mock') and identities and
                 all(type(v.get('pid')) is int and v['pid'] > 0
                     and type(v.get('create_time')) in (int, float)
                     and math.isfinite(v['create_time']) and v['create_time'] > 0 for v in identities))
    success = bool(valid and status.get('accepted_exit') is True
                   and type(status.get('returncode')) is int and status['returncode'] == 0
                   and type(status.get('error_count')) is int and status['error_count'] == 0
                   and status.get('process_tree', {}).get('tree_exit_confirmed') is True)
    return {'actual_launch_verified': valid, 'actual_solver_success_verified': success,
            'owned_process_identities': identities}


def inspect_base(folder):
    """Read actual checkpoint evidence without publishing or changing receipts."""
    folder, meta = warm_restart._read_preparation(folder)
    if meta.get('mode') != 'base' or meta.get('software_mock'):
        raise ValueError('Expected an actual same-case C0 base.')
    status = actual_status(folder, meta)
    receipt = adapter.parse_base_recovered(folder)
    if receipt.get('actual_FE') is not True or not (folder / 'base_restart_receipt.json').is_file():
        raise ValueError('A first-issued accepted canonical base receipt is required before any candidate.')
    if receipt['input_sha256'] != status['input_sha256']:
        raise ValueError('Actual C0 receipt/input identity differs.')
    if receipt['actual_C0_SET']['load_step'] != 6 or receipt['actual_C0_SET']['time'] != 6.:
        raise ValueError('Actual C0 restart is not the core LS6 endpoint.')
    return folder, meta, receipt, status


def expected_branch_input(full, core, receipt):
    """Pure reconstruction of the frozen prototype's exact branch text.

    The actual prepare_branch output must equal this plan byte-for-byte before
    the first API. This is expected executed input, not execution evidence.
    """
    _, continuation, post_header, blocks, footer = warm_restart._parts(full, core)
    frame = receipt['actual_C0_SET']
    supuy, punuy = receipt['touch_parameters_original'][2:4]
    restored = '\n'.join(['/batch', '/filname,solve', '/solu',
        f"antype,,restart,{frame['load_step']},{frame['substep']},continue", 'parres,new,c0_parameters,parm',
        'wrsold=supuy', 'wrpold=punuy', f'supuy={warm_restart._number(supuy)}',
        f'punuy={warm_restart._number(punuy)}', '*cfopen,restored_parameters,txt',
        '*vwrite,wrsold,wrpold,supuy,punuy', '(4(E24.16,1X))', '*cfclos',
        'autots,on', 'nropt,unsym', 'neqit,75', 'cnvtol,f,,0.001,2,1',
        'cnvtol,m,,0.001,2,1', 'kbc,0', 'outres,all,last', 'outres,nsol,all',
        'outres,rsol,all', 'outres,epel,all,workel', 'outres,eppl,all,workel']) + '\n'
    return restored + continuation + post_header + warm_restart._set_identities() + ''.join(blocks.values()) + footer


def plan_candidate(config, stroke_mm, base_folder):
    """Only a normalized FULL COLD PLAN, never an asserted cold execution."""
    s = stroke(stroke_mm)
    folder, meta, receipt, _ = inspect_base(base_folder)
    full, core = rect_model.build({**config, 'stroke_mm': s, 'save_full_strain_trajectory': True})
    base_config = meta['core_metadata']['config']
    if {k: v for k, v in core['config'].items() if k != 'stroke_mm'} != {
            k: v for k, v in base_config.items() if k != 'stroke_mm'}:
        raise ValueError('Candidate is not the same case/numerical/material design as this C0.')
    if core['material_sha256'] != meta['core_metadata']['material_sha256']:
        raise ValueError('Actual base material differs from the candidate plan.')
    physical = warm_restart._parts(full, core)[0]
    prefix = hashlib.sha256(physical.encode('ascii')).hexdigest()
    if prefix != meta['physical_prefix_sha256']:
        raise ValueError('Candidate plan changes the actual pre-corrective history.')
    physical_key = {name: core['config'][name] for name in FEATURES}
    # The six-feature condition remains separate from the stronger checkpoint
    # key, which also binds numerical/fixed physics/material/source identities.
    checkpoint_key = {'config_except_stroke_and_case_id': {k: v for k, v in base_config.items()
                        if k not in ('stroke_mm', 'case_id')},
                      'material_sha256': core['material_sha256'], 'core_source_sha256': sha(rect_model.__file__),
                      'pre_corrective_physical_prefix_sha256': prefix}
    branch_text = expected_branch_input(full, core, receipt)
    return {'mode': 'warm_multiframe_continuation', 'execution_mode': 'warm_multiframe_continuation',
            'case_id': core['config']['case_id'], 'stroke_mm': s, 'config': core['config'],
            'executed_input_sha256': hashlib.sha256(branch_text.encode('ascii')).hexdigest(),
            'executed_input_SHA_role': 'expected_actual_branch_input_before_execution',
            'physical_condition_sha256': canonical_sha(physical_key), 'six_features': physical_key,
            'checkpoint_key_sha256': canonical_sha(checkpoint_key),
            'base_folder': str(folder), 'base_executed_input_sha256': receipt['input_sha256'],
            'normalized_full_cold_plan_sha256': hashlib.sha256(full.encode('ascii')).hexdigest(),
            'normalized_full_cold_plan_is_execution_evidence': False,
            'full_cold_plan_executed': False, 'pre_corrective_physical_prefix_sha256': prefix,
            'actual_restart_identity': receipt['actual_C0_SET'], 'core_metadata': core,
            'source_pins': pins(), 'solver_started': False, 'qualified_for_formal_dataset': False}


def prepare_base(config, name, output_parent=None):
    """Future explicit preparation; this module never calls it on import."""
    return warm_restart.prepare_base(name, config, output_parent or BASE_PARENT)


def run_base(folder, timeout=7200):
    """One NEW actual base execution; no cache reuse or original overwrite."""
    timeout = bounded_timeout(timeout)
    folder, meta = warm_restart._read_preparation(folder)
    if meta.get('mode') != 'base' or meta.get('software_mock'):
        raise ValueError('Only a new physical base may launch the actual solver.')
    for name in ('solver_status.json', 'command.json', 'base_restart_receipt.json', 'warm_base_result.json'):
        if (folder / name).exists():
            raise FileExistsError('Prior base attempt is preserved; prepare a reviewed new target.')
    frozen = pins()
    write_new(folder / 'warm_API_attempt.json', {'version': VERSION, 'kind': 'base',
              'API_attempted_at_China': now(), 'expected_input_sha256': meta['input_sha256'],
              'source_pins': frozen, 'maximum_API_calls': 1, 'formal': False})
    result = {'schema_version': 'RECT_WARM_BASE_RESULT001', 'mode': 'C0_base', 'actual_API_calls': 1,
              'directory': str(folder.relative_to(ROOT)), 'input_sha256': meta['input_sha256'],
              'accepted_solver': False, 'parsed': False, 'qualified_for_formal_dataset': False,
              'formal_restart_enabled': False, 'source_pins': frozen}
    try:
        status = run_solver(folder, (folder / 'input.inp').read_text(encoding='ascii'),
                            meta['expected_files'], timeout=timeout, cores=meta['solver_cores'])
        result['solver_status'] = status
        result['accepted_solver'] = status.get('accepted_exit') is True
        actual_status(folder, meta)
        verify_pins(frozen)
        receipt = adapter.parse_base_recovered(folder)
        # This is a new, successful base first publication, not a rewrite of any
        # original failed/cached prototype receipt or a cold qualification.
        write_new(folder / 'base_restart_receipt.json', receipt)
        result.update(accepted_solver=True, parsed=True, actual_C0_SET=receipt['actual_C0_SET'],
                      actual_FILE_SUMMARY_frame=receipt['actual_FILE_SUMMARY_frame'],
                      base_receipt_source=source(folder / 'base_restart_receipt.json', 'actual C0 checkpoint receipt'))
    except Exception as error:
        result.update(error=repr(error), traceback=traceback.format_exc())
        if (folder / 'solver_status.json').is_file():
            result['solver_status'] = read(folder / 'solver_status.json')
    result.update(launch_evidence(result.get('solver_status')))
    write_new(folder / 'warm_base_result.json', result)
    return result


def _history_provenance(base, branch, core):
    bt, _, bs = warm_restart._identities(base, 6)
    table, _, strain = warm_restart._identities(branch, 11)
    initial = table[:, 1] <= 6
    if not np.array_equal(table[initial], bt) or not np.allclose(strain[initial], bs, rtol=0, atol=1e-10):
        raise ValueError('Combined RST SETs/strain path do not preserve actual C0 source.')
    endpoints = {}
    for state, step in core['state_stages'].items():
        row = table[table[:, 1] == step][-1]
        endpoints[state] = {'source_role': 'base' if step <= 6 else 'branch',
                            'combined_SET': int(row[0]), 'LS': int(row[1]),
                            'SBST': int(row[2]), 'time': float(row[3])}
    return {'combined_SET_count': len(table), 'base_SET_count': len(bt),
            'branch_new_SET_count': int((~initial).sum()), 'all_11_LS_covered': True,
            'initial_SETs_exactly_equal_base': True, 'states': endpoints,
            'all_path_max_abs_global_EPTOX': float(np.max(abs(strain[:, 3:]))),
            'base_path_max_abs_global_EPTOX': float(np.max(abs(bs[:, 3:]))),
            'branch_new_path_max_abs_global_EPTOX': float(np.max(abs(strain[~initial, 3:]))),
            'source_tables': [source(base / 'set_identity.txt', 'actual base SET identity'),
                              source(branch / 'set_identity.txt', 'actual combined SET identity'),
                              source(base / 'strain_history.txt', 'actual base all-SET extrema'),
                              source(branch / 'strain_history.txt', 'actual combined all-SET extrema')],
            'p_path_method': 'Accumulated NL EPEQ; five-state copied values bound monotonic accumulated p. No every-SET full p tensor claim.'}


def _preservation(metrics, core, s):
    budgets = read(ROOT / 'protocol/pilot_acceptance_budgets_v001.json')['zero_history']
    inside = np.asarray(core['x_mm']) <= 130. + 1e-9
    pairs = [('B', 'C0')] + ([('B', 'D'), ('C0', 'D')] if s == 0. else [])
    actual = {}
    for a, b in pairs:
        aa = np.asarray(metrics['states'][a]['axis_xyz_mm'])[inside]
        bb = np.asarray(metrics['states'][b]['axis_xyz_mm'])[inside]
        values = {'axis_max_distance_mm': float(np.linalg.norm(aa - bb, axis=1).max()),
                  'accumulated_plastic_strain_max_difference': metrics['zero_stroke_checks'][f'{a}_{b}_p_max_abs_difference'],
                  'residual_axial_stress_max_difference_MPa': metrics['zero_stroke_checks'][f'{a}_{b}_SX_max_abs_difference_MPa']}
        for name, value in values.items():
            if isinstance(value, bool) or value is None or not math.isfinite(value) or value > budgets[name]:
                raise ValueError('Actual warm initial/zero preservation failed: ' + a + '/' + b + '/' + name)
        actual[a + '_' + b] = values
    return {'observed': actual, 'budgets': budgets, 'passed': True,
            's0_D_equal_initial_required_and_verified': s == 0.}


def parse_candidate(branch_folder, plan):
    """Pure actual composite record; no prepare/solve/receipt publication."""
    verify_pins(plan['source_pins'])
    branch, meta = warm_restart._read_preparation(branch_folder)
    if meta.get('mode') != 'branch' or meta.get('software_mock'):
        raise ValueError('Only saved actual independent restart branches are candidates.')
    base, base_meta, base_receipt, base_status = inspect_base(plan['base_folder'])
    if Path(meta['base_folder']).resolve() != base or meta['base_input_sha256'] != plan['base_executed_input_sha256']:
        raise ValueError('Branch restored another actual initial checkpoint.')
    if meta['core_metadata']['config'] != plan['config'] or meta['actual_restart_identity'] != plan['actual_restart_identity']:
        raise ValueError('Actual candidate configuration/restart identity differs from plan.')
    branch_status = actual_status(branch, meta)
    receipt = adapter.parse_branch_recovered(branch)
    if receipt.get('actual_FE') is not True or receipt.get('actual_combined_SET_coverage_verified') is not True:
        raise ValueError('Actual full-history continuation evidence is unavailable.')
    metrics = receipt['metrics']
    history = _history_provenance(base, branch, meta['core_metadata'])
    if abs(metrics['max_abs_ip_axial_total_strain'] - history['all_path_max_abs_global_EPTOX']) > 1e-10:
        raise ValueError('Material domain metric omits part of the actual base/branch path.')
    preservation = _preservation(metrics, meta['core_metadata'], plan['config']['stroke_mm'])
    stages = {}
    for state, identity in history['states'].items():
        origin = base if identity['source_role'] == 'base' else branch
        names = ['nodes', 'p', 'sx', 'ex', 'element_extrema', 'scalars', 'tool_vectors',
                 'contact_elements', 'contact_table_log', 'penetration', 'pressure']
        # Actual filenames, including contact availability, are not fabricated.
        files = [origin / f'state_{state}_{suffix}.txt' for suffix in names
                 if (origin / f'state_{state}_{suffix}.txt').is_file()]
        stages[state] = {**identity, 'source_directory': str(origin),
                         'raw_sources': [source(p, 'actual ' + state + ' exported field') for p in files]}
    valid, reason = admissibility({'accepted_solver': True, 'parsed': True, 'metrics': metrics})
    if meta['input_sha256'] != plan['executed_input_sha256']:
        raise ValueError('Actual branch input differs from its planned executed bytes.')
    result = {'schema_version': SCHEMA, 'producer_version': VERSION, 'mode': 'warm_multiframe_continuation',
              'execution_mode': 'warm_multiframe_continuation',
              'case_id': plan['config']['case_id'], 'stroke_mm': plan['config']['stroke_mm'],
              'directory': str(branch.relative_to(ROOT)), 'input_sha256': meta['input_sha256'],
              'executed_input_sha256': meta['input_sha256'],
              'base_executed_input_sha256': base_receipt['input_sha256'],
              'normalized_full_cold_plan_sha256': plan['normalized_full_cold_plan_sha256'],
              'full_cold_plan_executed': False, 'physical_condition_sha256': plan['physical_condition_sha256'],
              'normalized_full_cold_plan_is_execution_evidence': False,
              'checkpoint_key_sha256': plan['checkpoint_key_sha256'], 'normalized_config': plan['config'],
              'model_source_sha256': plan['source_pins']['rect_model.py'],
              'implementation_source_hashes': plan['source_pins'],
              'provenance_manifest_sha256': sha(ROOT / 'provenance/source_manifest.json'),
              'recorded_time_China': now(), 'solver_status': branch_status, 'base_solver_status': base_status,
              'accepted_solver': True, 'base_accepted_solver': True, 'parsed': True,
              'admissible': valid, 'admissibility_reason': reason, 'metrics': metrics,
              'history_provenance': history, 'state_source_map': stages,
              'initial_history_preservation': preservation,
              'actual_initial_fields_verified': receipt['actual_initial_fields_verified'],
              'actual_base_unchanged_after_branch': receipt['source_base_unchanged_after_branch'],
              'actual_source_receipts': [source(branch / 'input.inp', 'executed branch input'),
                  source(branch / 'warm_metadata.json', 'actual branch generator metadata'),
                  source(branch / 'solver_status.json', 'actual branch execution'),
                  source(base / 'input.inp', 'executed base input'),
                  source(base / 'base_restart_receipt.json', 'immutable actual C0 receipt'),
                  source(base / 'warm_metadata.json', 'actual base generator metadata'),
                  source(base / 'solver_status.json', 'actual base execution')],
              'checkpoint_provenance': {'actual_C0_SET': base_receipt['actual_C0_SET'],
                  'actual_FILE_SUMMARY_frame': base_receipt['actual_FILE_SUMMARY_frame'],
                  'full_internal_history_basis': base_receipt['full_internal_history_basis'],
                  'actual_restart_input_names': base_receipt['restart_input_names'],
                  'immutable_source_manifest': meta['source_base_snapshot'],
                  'writable_computational_copy_manifest': meta['computational_copies']},
              'storage': {'policy': 'native_and_original_text_retained_scaffold',
                          'typed_permanent_manifest': None, 'scratch_release_allowed': False,
                          'future_narrow_quantities': ['EPEQ', 'SX', 'EPTOX'],
                          'shared_A_B_C0_are_actual_sources_not_hash_only': True},
              'base_solve_reused_not_recounted_as_candidate_FE': True,
              'qualified_for_formal_dataset': False, 'formal_generation_unlocked': False,
              'formal_restart_enabled': False, 'resolved_optimal_label_validated': False,
              'Ansys_invocations_in_parse': 0, 'POST_invocations_in_parse': 0}
    verify_pins(plan['source_pins'])
    return result


def run_trial(config, stroke_mm, timeout=7200, *, base_folder, branch_name=None):
    """Future explicit one-branch API. Never invoked on import or by checks."""
    timeout = bounded_timeout(timeout)
    plan = plan_candidate(config, stroke_mm, base_folder)
    name = branch_name or f'S{plan["config"]["stroke_mm"]:.6f}_{plan["executed_input_sha256"][:12]}'
    parent = BRANCH_PARENT / warm_restart._name(str(plan['config']['case_id']))
    target = parent / warm_restart._name(name)
    if target.exists():
        raise FileExistsError('Existing candidate preserved; no automatic reuse/retry/overwrite.')
    base, meta, receipt, _ = inspect_base(base_folder)
    # Existing immutable receipt makes the original base parser's cached path
    # usable. Do NOT call original warm_restart.run(), whose old header guard
    # would reject actual 2026 R1 after a successful physical solve.
    folder, branch_meta = warm_restart.prepare_branch(base, plan['config']['stroke_mm'], name, parent)
    if (folder != target or branch_meta['core_metadata']['config'] != plan['config']
            or branch_meta['input_sha256'] != plan['executed_input_sha256']):
        raise RuntimeError('Fresh branch preparation did not match its declared plan.')
    verify_pins(plan['source_pins'])
    write_new(folder / 'warm_API_attempt.json', {'schema_version': SCHEMA, 'API_attempted_at_China': now(),
              'maximum_API_calls': 1, 'API_call_started': False, 'expected_branch_input_sha256': branch_meta['input_sha256'],
              'full_cold_plan_executed': False, 'plan': plan, 'qualified_for_formal_dataset': False})
    result = {'schema_version': SCHEMA, 'producer_version': VERSION, 'mode': 'warm_multiframe_continuation',
              'execution_mode': 'warm_multiframe_continuation',
              'case_id': plan['config']['case_id'], 'stroke_mm': plan['config']['stroke_mm'],
              'directory': str(folder.relative_to(ROOT)), 'input_sha256': branch_meta['input_sha256'],
              'executed_input_sha256': branch_meta['input_sha256'],
              'base_executed_input_sha256': plan['base_executed_input_sha256'],
              'normalized_full_cold_plan_sha256': plan['normalized_full_cold_plan_sha256'],
              'full_cold_plan_executed': False, 'accepted_solver': False, 'parsed': False,
              'normalized_full_cold_plan_is_execution_evidence': False,
              'model_source_sha256': plan['source_pins']['rect_model.py'],
              'actual_API_calls': 0, 'implementation_source_hashes': plan['source_pins'],
              'qualified_for_formal_dataset': False, 'formal_generation_unlocked': False}
    try:
        _verify_branch_inputs(base, folder, branch_meta)
        verify_pins(plan['source_pins'])
        result['actual_API_calls'] = 1
        status = run_solver(folder, (folder / 'input.inp').read_text(encoding='ascii'),
                            branch_meta['expected_files'], timeout=timeout, cores=branch_meta['solver_cores'])
        result['solver_status'] = status
        result['accepted_solver'] = status.get('accepted_exit') is True
        verify_pins(plan['source_pins'])
        actual = parse_candidate(folder, plan)
        result.update(actual)
    except Exception as error:
        result.update(parse_error=repr(error), traceback=traceback.format_exc())
        if (folder / 'solver_status.json').is_file():
            status = read(folder / 'solver_status.json')
            result['solver_status'] = status
            result['accepted_solver'] = status.get('accepted_exit') is True
    finally:
        try:
            warm_restart._verify_hashes(base, branch_meta['source_base_snapshot'])
        except Exception as error:
            result.update(parsed=False, base_source_integrity_error=repr(error))
        result.update(launch_evidence(result.get('solver_status')))
        result['unresolved_launch_evidence'] = bool(not result['actual_launch_verified'] and (folder / 'command.json').exists())
        write_new(folder / 'warm_trial_result.json', result)
    return result
