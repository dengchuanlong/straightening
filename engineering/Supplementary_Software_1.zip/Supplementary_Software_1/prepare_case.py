"""Prepare a complete RECT3D004 cold-core input; never launch a solver."""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
PACKAGE = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def checked_file(relative, manifest):
    path = (PACKAGE / relative).resolve()
    if not path.is_relative_to(PACKAGE) or not path.is_file():
        raise ValueError(f"Missing or invalid package file: {relative}")
    record = next((r for r in manifest["files"] if r["package_path"] == relative), None)
    if record is None or sha(path) != record["sha256"]:
        raise ValueError(f"Package SHA-256 check failed: {relative}")
    return path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case", required=True, choices=("B0001", "P0008", "R0004"))
    parser.add_argument("--output", required=True, type=Path,
                        help="New or empty directory outside this package; never overwritten.")
    args = parser.parse_args()
    output = args.output.expanduser().resolve()
    if output.is_relative_to(PACKAGE):
        parser.error("Output must be outside the immutable review package.")
    if output.exists() and (not output.is_dir() or any(output.iterdir())):
        parser.error("Output already exists and is not an empty directory; nothing was written.")

    manifest = read(PACKAGE / "MANIFEST.json")
    index = read(checked_file("cases_index.json", manifest))
    record = index["cases"][args.case]
    config_path = checked_file(record["config_path"], manifest)
    source_path = checked_file("straightening_study/full3d_rect_20261007/scripts/rect_model.py", manifest)
    material_path = checked_file("straightening_study/auto_run_20261001/material/v002/candidate_material.inp", manifest)
    material_json = checked_file("straightening_study/auto_run_20261001/material/v002/candidate_material.json", manifest)
    config = read(config_path)
    config["stroke_mm"] = record["selected_stroke_mm"]

    spec = importlib.util.spec_from_file_location("packaged_rect_model_prepare_only", source_path)
    if spec is None or spec.loader is None:
        raise RuntimeError("Cannot load the packaged original model source.")
    core = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(core)
    core.MATERIAL = material_path  # In-memory path binding only; source bytes unchanged.
    text, metadata = core.build(config)
    if metadata["model_version"] != "RECT3D004":
        raise ValueError("Unexpected model version.")
    input_bytes = text.encode("ascii")
    if metadata["config"]["stroke_mm"] != record["selected_stroke_mm"]:
        raise ValueError("Selected stroke was not preserved.")
    if sha(source_path) != next(r["sha256"] for r in manifest["files"]
                               if r["package_path"].endswith("/scripts/rect_model.py")):
        raise RuntimeError("Original model source changed during preparation.")

    json_bytes = lambda obj: (json.dumps(obj, indent=2, ensure_ascii=False, allow_nan=False) + "\n").encode("utf-8")
    payloads = {"input.inp": input_bytes,
                "model_metadata.json": json_bytes(metadata),
                "config.json": json_bytes(metadata["config"])}
    receipt = {
        "schema": "SUPPLEMENTARY_COLD_CORE_PREPARATION_V1",
        "status": "PREPARED_ONLY_NOT_SOLVED",
        "case_id": record["case_id"],
        "selected_stroke_mm": record["selected_stroke_mm"],
        "preparation_model_version": core.VERSION,
        "source_case_config_sha256": sha(config_path),
        "model_source_sha256": sha(source_path),
        "material_card_sha256": sha(material_path),
        "material_parameter_sha256": sha(material_json),
        "input_sha256": hashlib.sha256(input_bytes).hexdigest(),
        "source_config_pointer": record["source_config_pointer"],
        "reference_search_result": record["search_result_path"],
        "historical_reference_execution_mode": "warm_multiframe_continuation",
        "historical_reference_numerical_variant": "RESTART_AUTOREF_SUPPORT_PRECISION_V003",
        "historical_reference_input_sha256": record["historical_warm_input_sha256"],
        "new_input_kind": "complete_cold_core_history_from_original_rect_model_build",
        "not_the_historical_warm_input": True,
        "warm_reference_result_reproduced": False,
        "native_restart_dependencies_included": False,
        "solver_started": False,
        "solver_results_generated": False,
        "qualified_for_formal_dataset": False,
        "formal_generation_unlocked": False,
        "source_files_modified": False,
        "numpy_version": core.np.__version__,
        "python_version": sys.version.split()[0],
        "mesh_count": metadata["mesh_count"],
        "outputs": {name: {"sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)}
                    for name, data in payloads.items()},
        "interpretation": "Preparation only. No FE result, convergence, optimized label or equivalence to the saved V003 warm result is established."
    }
    payloads["preparation_receipt.json"] = json_bytes(receipt)
    output.mkdir(parents=True, exist_ok=True)
    for name, data in payloads.items():
        with (output / name).open("xb") as stream:
            stream.write(data)
    print(json.dumps({"status": receipt["status"], "case": args.case,
                      "output": str(output), "input_sha256": receipt["input_sha256"],
                      "solver_started": False, "formal_generation_unlocked": False}, indent=2))


if __name__ == "__main__":
    main()
