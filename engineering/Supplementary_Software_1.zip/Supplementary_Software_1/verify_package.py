"""Verify the packaged file manifest without running model or solver code."""
import hashlib
import json
from pathlib import Path


def main():
    root = Path(__file__).resolve().parent
    manifest = json.loads((root / "MANIFEST.json").read_text(encoding="utf-8"))
    failures = []
    for item in manifest["files"]:
        path = (root / item["package_path"]).resolve()
        if not path.is_relative_to(root) or not path.is_file():
            failures.append({"path": item["package_path"], "problem": "missing or outside package"})
            continue
        blob = path.read_bytes()
        if len(blob) != item["bytes"] or hashlib.sha256(blob).hexdigest() != item["sha256"]:
            failures.append({"path": item["package_path"], "problem": "size/hash mismatch"})
    print(json.dumps({"checked_files": len(manifest["files"]), "failures": failures,
                      "passed": not failures, "solver_started": False}, indent=2))
    raise SystemExit(1 if failures else 0)


if __name__ == "__main__":
    main()
